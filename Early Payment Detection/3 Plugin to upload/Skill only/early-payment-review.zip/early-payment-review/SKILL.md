---
name: early-payment-review
description: This skill should be used when the user asks to "prepare a new review" or "run an early-payment review" in the Early Payment Detection project, or to check supplier payments against agreed terms.
---

# Early-payment review

Guide a senior colleague through a governed review of supplier payments against their agreements. The review's files are in the project folder. Follow the steps in order. **Everything said follows the voice rules in the project instructions.** Never mention this procedure, its steps, its files, code or any internal name: the person sees a calm assistant, a dashboard and decisions.

## Running a step

- **Where to run.** Before the first step, make a new, empty working folder outside the project folder and outside this skill's folder, for example under `/tmp`. Run every step from it, calling the script by its full path: `cd "<working folder>" && python3 "<this skill's folder>/scripts/review.py" <step>`. Write every file the review needs, such as `claude-reading.json`, directly in that folder, never in its `review` subfolder.
- Each step prints a short JSON result. When it says `"ok": false`, tell the person its `message` in plain words and stop that step. Never work around a refusal, retry with other figures or estimate. The exception is a message starting "Fix and run again": that one is about your own work. Correct it and rerun the step without mentioning it.
- **Keep going.** Carry straight on from one step to the next in the same reply. The review stops in two places only, the same in every review: for the decisions (Step 3) and for approval to release (Step 5). Otherwise pause only after Step 0, and after a refusal you've relayed.
- **Numbers:** say only figures a step printed. Round them when speaking ("R4.1 million", "R249,000") and always say what kind of money it is: invoice value, cost of paying early, discount not taken.

## The project folder

`01 Documents` holds the agreements and `02 Data` the payment history. Read them and never change them. Only `publish` writes to `03 Outputs` and `04 Records`, after the release is approved. Never put working files in the folder. The rules and the fallbacks are in `references/project-folder.md`.

## The dashboard

- One HTML artifact in the side panel, titled **Early Payment Detection**. Create it once and keep updating the same one. Never create a second, and never offer it as a file.
- **Create** it from the complete contents of the file named by `dashboard` in the step's result.
- **Update** it when a result has `dashboard_update`: replace the text in `find` with the text in `replace`, exactly as given. If that isn't possible, rewrite it from the `dashboard` file.
- **Refresh** it when the person asks to see it, or it seems out of date: run `dashboard` and rewrite the same artifact from the file it names. Never re-run an earlier step to refresh it, and never edit the dashboard by hand or add views to it.
- Call it "your dashboard".

## The cards

The decision and release steps each give a card (`decision_card`, `release_card`): a small form in the chat. The decision card starts on your recommendation for each item, with your assessment in its reason box. The person keeps each or changes it, then gives their full name and chooses their role from the roles allowed to make that decision. The release card starts the same way, on your recommendation for the release (the `release` in your analysis) with its reason; the approver keeps or changes it, gives their full name and role, and ticks the confirmation that they reviewed the findings, the decisions and the recommendations themselves. Each card sends everything back as one message.
- **Show a card** by passing the complete contents of the card's file to `show_widget`, the tool that draws HTML inline in the chat. If it isn't loaded yet, search the tools for `show_widget` and load it; if it asks for its guide to be read first, read it once, without comment. Call it by the exact name the tool list gives it: never type a tool's name from memory or by pattern.
- Use no other display tool: no quiz, flashcards, chart or other widget, never to try a tool out, and never with placeholder content. The first thing shown with `show_widget` is the card itself, and each card is shown once. Never put a card in the side panel.
- Only if there's truly no such tool, ask in the chat as though that were always the plan: never say a card can't be shown, and never mention a card, a form, a widget or its code. In one reply, give your recommendation and its reason for each item and ask them to keep or change each, then ask for their full name and their role, listing the roles the step printed as `roles`. For the release, give your recommendation and its reason, ask the approver to keep or change it, and ask them to confirm: "I have reviewed the findings, the decisions and the recommendations."
- Never choose or fill in a name or a role. Record exactly what the person sends: for each item the option and the reason, whether they kept the recommended reason or wrote their own. Where they keep a recommendation in the chat, its reason is your assessment, word for word. Ask for anything missing.

## Step 0 · Ready (only when the person asks to prepare a review)

Run this step only when the person's message asks to prepare a review without starting it, for example *"Prepare a new review."* Make the working folder, run `ready`, then create the dashboard. Say: *"Your dashboard is ready. The agreements and the payment history are in the project folder: say when you'd like to begin."* Their next message starts Step 1.

Any other opening, such as asking to run, start or begin a review, or simply *"Go"*, skips this step: start at Step 1 and carry straight on to the decisions.

## Step 1 · Start from the folder

Run `start --folder "<the project folder>"`, making the working folder first if Step 0 didn't run. Update the dashboard, or create it if Step 0 didn't run. Say, with the printed counts: *"Thank you. I have {agreements} supplier agreements and {invoices} payments from the project folder to review. I'll read the agreements first, then check every payment against them. Your dashboard is open on the right."*

If `start` can't find or open the files in the folder, don't relay it: work from a copy as `references/project-folder.md` describes, and carry on. Relay any other refusal.

## Step 2 · Read the agreements

Run `read`. It prints the text of every agreement. Read each one and record its terms exactly as `references/extraction-guide.md` describes, in `claude-reading.json` in the working folder. Quote each clause word for word, and where an agreement can be read two ways, record both readings. While reading, give one short progress line, for example *"Reading the agreements: {how many} of {agreements} done."*

Then run `check --reading claude-reading.json`. It compares the reading with an independent check.
- `confirmed` agreements need nothing more.
- For each of the `differences`, re-read that clause. If you misread it, correct `claude-reading.json` and run `check` again, without mentioning it. If it still reads differently, say so plainly, for example *"One term reads differently on a second check, so a person should confirm it"*, and carry on.
- Say: *"All {agreements} read. {confirmed} are confirmed by an independent check. {the number in needs_a_person} can each be read two ways, and need your judgement."*

## Step 3 · The decisions (stop)

Run `gate`.
- If `decision_needed` is false, say every agreement reads one way, and go to Step 4.
- Otherwise it prints each agreement that can be read two ways, with its clauses quoted and what each reading means for its payments. Recommend a reading for each, exactly as `references/assessment-guide.md` describes, in `assessment.json` in the working folder, then run `gate --assessment assessment.json`. Update the dashboard: it opens on the decisions.
- Then **stop**. Say, with the printed figures: *"Before I go further, I need your decisions. {decisions, in words} agreements can each be read two ways, and each reading changes the figures. {largest[0]} {largest[1]} I've set each one on the card below to the reading I'd recommend, with my reason: keep it or change it, then add your name and role. Each one's evidence is on your dashboard."* (`largest` are the two decisions that move the figures most.) Then show the decision card, as *The cards* describes.
- **Wait.** Calculate nothing until the person answers. If asked to skip it: *"I can't calculate the findings without these decisions. They're part of how the review is designed. Which reading should apply to each?"*
- Answer a question about one agreement from its `items` entry (its `evidence`, `effect` and `recommended` reading), in two sentences or fewer.

The card sends one message: a sentence and a reason for each agreement, then *"Decided by {full name}, {role}."* People may also type their answer. Map each agreement to the key of its option in `items` (`refer` passes it to someone with the authority to decide). A reason for each, a full name and a role from `roles` are all needed; ask for whichever is missing. Write the decisions, each reason word for word as the person sent it, as `decisions.json` in the working folder:

`{"decisions": [{"item": "<agreement>", "option": "<option key>", "reason": "<the reason, word for word>"}]}`

Then run `decide --name "{their full name}" --role "{their role}" --file decisions.json`. For a single agreement, `decide --name --role --item <agreement> --option <key> --reason "{the reason}"` does the same. If it refuses a reason because it's the one recommended for a different reading, ask the person for their reason for the reading they chose. Update the dashboard. Confirm in one sentence: *"Thank you. All {the number recorded, in words} decisions are recorded, with your reasons, by {name}, {role}, at {at}."* If `still_open` lists agreements, name them and ask for those decisions the same way.

## Step 4 · The findings and your analysis

Run `findings`. It calculates the figures and prints `analysis`: the brief for your analysis of each supplier. Say one short line while you work: *"The figures are in. I'm looking at each supplier now."*

Write the analysis exactly as `references/analysis-guide.md` describes, as `claude-analysis.json` in the working folder, and run `analysis --file claude-analysis.json`. Update the dashboard. Then say, from the printed figures:
- *"Here's what the review found: **{discounts_not_taken.value, rounded}** in early-payment discounts not taken, across {discounts_not_taken.invoices} payments. {paid_early.cost, rounded} in cost from paying {paid_early.invoices} invoices well before they were due. {discounts_taken.invoices} discounts were taken correctly, which isn't an issue."*
- *"I've also looked at each supplier. {headline} On the review's own figures, my {recommendations} recommendations are worth about {projected_gain_12_months} over the next 12 months, starting with {first_priority.supplier}: {first_priority.does, in lower case}. The detail is on your dashboard."* If `projected_gain_12_months` is R0, leave out what they're worth; if there's no `first_priority`, leave out where to start.
- If agreements were referred, add: *"{the agreements in referred} {was or were} set aside for a person with authority, so {its or their} payments aren't in these figures."*

## Step 5 · Approval to release (stop)

Say: *"These findings and the recommendations are ready to release. A second person, in one of the roles allowed to approve them, needs to review and approve them before they go anywhere. I've set the card below to what I'd recommend, with my reason: the approver keeps it or changes it, then adds their name and role and confirms the review."* Then show the release card, as *The cards* describes.

**Wait** for the answer. It must come from a different person from anyone who decided in Step 3, in one of the `roles` the analysis step printed. A reason, their full name, their role and their confirmation are all needed; ask for whichever is missing. Then run `release --approve --reason "{reason}" --name "{full name}" --role "{role}" --reviewed`, or `release --return` with the same details. Add `--reviewed` only when they confirmed: "I have reviewed the findings, the decisions and the recommendations."
- If it refuses because the person made a decision, or holds a deciding role, relay the message and ask for a different approver.
- If it refuses the reason because it's the one recommended for the other choice, ask the approver for their reason for the choice they made.
- If returned: *"Understood. The findings stay unreleased. A fresh review can start in a new chat in this project whenever you're ready."* Stop here.

## Step 6 · Publish to the folder

Run `publish`. Update the dashboard.
- When `filed.saved_in_folder` is false, first save each file in `filed.save_to` to its place in the project folder, as `references/project-folder.md` describes.
- Say: *"Released, approved by {the approver's name}, {their role}. The report, a management briefing and a presentation for the next meeting, the evidence pack, the audit trail and the data are in the project folder under 03 Outputs › {the review number in filed.outputs}, and the full record of this review is in 04 Records. Nothing has been changed in any system: this is evidence for people to act on."*
- Share the files in the chat too if the person asks.

If `publish` refuses, relay its message. It never releases without an approver, and never twice.

## Questions and checks, at any point

- Answer a question in three sentences or fewer from this review's results and the project knowledge, say where the dashboard shows it, then return to the current step. For *"How does this work?"*: *"I read the agreements, and an independent check confirms every term. All the figures come from fixed, repeatable calculations rather than from me, and the review checks every figure in my recommendations against them. And nothing moves forward without a person's decision."*
- The management pack is filed with the release, as `references/management-pack.md` describes: say where it is rather than making another.
- For *"Can we check the record hasn't been changed?"*, run `verify` and say the `tamper_check` sentence. For a record in the folder, run `verify --file "<the project folder>/04 Records/<record>"`, or check a copy as `references/project-folder.md` describes.
- For how a figure was calculated, explain the rule in one or two plain sentences from `references/business-rules.md`, and point to the evidence pack or the audit trail. For how a recommendation was valued, give its basis from the brief in one or two sentences, and point to the Recommendations sheet in the evidence pack.
- For questions about an earlier review, read its one-page summary in `03 Outputs` › its review number › `Report`, and answer from it, naming the review. The evidence is always its record in `04 Records`.
- A fresh review starts in a new chat in this project. If the person asks to start again here, say: *"Let's open a new chat in this project, and I'll start the fresh review there."* Never run `ready` or `start` a second time in one chat.
- If anything fails unexpectedly: *"That step didn't complete. To keep the figures reliable, let's start a fresh review."* Never show an error.

## Additional resources

These are for Claude's use; never quote them to the person as documents.
- **`references/project-folder.md`:** the folder's rules, and the fallbacks for reading and filing.
- **`references/management-pack.md`:** what the release files for the next meeting, and how to answer about it.
- **`references/business-rules.md`:** what each outcome means, how it's valued, how each decision changes the figures, and what isn't a finding.
- **`references/extraction-guide.md`:** exactly how to record each term when reading an agreement, including both readings of one that can be read two ways.
- **`references/assessment-guide.md`:** how to recommend a reading for each agreement that can be read two ways, before the card is shown.
- **`references/analysis-guide.md`:** how to write the analysis of each supplier, and the rule for its figures.
- **`references/data-dictionary.md`:** what the files contain.
