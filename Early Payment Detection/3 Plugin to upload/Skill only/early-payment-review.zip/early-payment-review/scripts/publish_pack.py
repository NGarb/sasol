"""The files publishing writes before the release completes: the evidence pack (Excel), the one-page summary (PDF) and a copy
of the record. Only ever called through Review.publish(), which refuses unless the release was approved."""
from __future__ import annotations

import datetime as dt
import shutil
from pathlib import Path

import audit
import logic
import ooxml
import pdf
import skillkit as kit

HEAD = ["Invoice", "Supplier", "Agreement", "Site", "Invoice date", "Paid date", "Days to pay", "Due (days after the invoice)", "Invoice value"]
MONEY = {"Invoice value", "Cost of paying early", "Discount value"}


def sast(at: str, seconds: bool = False) -> str:
    """A recorded time in South African time, as people read it: 26 Sep 2026 10:42."""
    t = dt.datetime.fromisoformat(at).astimezone(kit.SAST)
    return f"{t.day} " + t.strftime("%b %Y %H:%M:%S" if seconds else "%b %Y %H:%M")


def _invoice_rows(payments: list[dict], agreements: dict, decisions: dict) -> tuple[list, list, list, list]:
    """The payments behind each finding, each against the terms that govern it."""
    gov = logic.all_governing(agreements, decisions)
    early, missed, taken, late = [], [], [], []
    for r in payments:
        a, t = agreements.get(r["Contract Reference"]), gov.get(r["Contract Reference"])
        if not a or t is None:
            continue
        x = logic.assess(r, t)
        base = [r["Invoice ID"], a["supplier"], a["ref"], r["Site"], r["Invoice Date"], r["Paid Date"], r["days"], x["due"], r["amount"]]
        terms = f"{x['disc'][0]:g}% within {x['disc'][1]} days" if x["disc"] else ""
        if x["took"]:
            taken.append(base + [terms, x["discount"]])
        if x["early"]:
            early.append(base + [x["due"] - r["days"], x["cost"]])
        if x["missed"]:
            missed.append(base + [terms, x["discount"]])
        if x["late"]:
            late.append(base + [r["days"] - x["due"]])
    return early, missed, taken, late


def write(out: Path, review, f: dict, agreements: dict, comparison: list, payments: list, gates: list,
          advice: list[list] | None = None, gain: float = 0.0, labels: dict | None = None) -> list[str]:
    st = review.state
    decisions = {k.split(":", 1)[1]: v["option"] for k, v in st["decisions"].items()}
    early, missed, taken, late = _invoice_rows(payments, agreements, decisions)
    tol = logic.TOLERANCE
    summary_rows = [["Review", st["review_id"]], ["Agreements read", len(agreements)], ["Payments reviewed", f["invoices_considered"]],
                    ["Paid early: payments", f["early"]["invoices"]], ["Paid early: cost of paying early (R)", f["early"]["cost"]],
                    ["Discounts not taken: payments", f["missed"]["invoices"]], ["Discounts not taken: value (R)", f["missed"]["value"]],
                    ["Discounts taken correctly: payments", f["taken"]["invoices"]], ["Discounts taken correctly: value (R)", f["taken"]["value"]],
                    ["Paid late: payments", f["late"]["invoices"]], ["On time: payments", f["on_time"]["invoices"]],
                    ["Referred to a person with authority", ", ".join(f["referred"]) or "None"],
                    ["Rate used to value paying early", f"{logic.FUNDING_RATE:.1%}, the Treasury's short-term funding rate"],
                    ["On time", f"Within {tol} days either side of the due date"],
                    ["Days counted from", "The invoice date in the payment history"],
                    ["Every payment's outcome", "In the Data workbook, sheet Payments assessed"]]
    gate = {g["ref"]: g for g in gates}
    terms = logic.term_rows(comparison, agreements)
    decs = [[k.split(":", 1)[1], gate.get(k.split(":", 1)[1], {}).get("question", ""), v["label"], v["reason"], v["name"], v["role"], sast(v["at"]), v["shown"][:16],
             audit.followed(v)] for k, v in st["decisions"].items()]
    rel = st.get("release") or {}
    if rel:
        decs.append(["Release", "Release these findings and recommendations?", f"Release {rel['status']}", rel.get("reason", ""), rel.get("name", ""),
                     rel.get("role", ""), sast(rel["at"]) if rel.get("at") else "", rel["figures"][:16], ""])
    record = [[e["seq"], sast(e["at"], True), kit.event_label(e, labels), kit.who(e).split(" · ")[0], (e.get("data") or {}).get("role", "") if e["actor"] != "system" else "",
               e["fingerprint"][:16], e["hash"][:16]] for e in review.entries()]
    xlsx = out / f"Evidence pack {st['review_id']}.xlsx"
    ooxml.write_xlsx(xlsx, [
        {"name": "Summary", "headers": ["Item", "Value"], "rows": summary_rows, "widths": [40, 60]},
        {"name": "Paid early", "headers": HEAD + ["Days early", "Cost of paying early"], "rows": early, "money": MONEY},
        {"name": "Discounts not taken", "headers": HEAD + ["Discount terms", "Discount value"], "rows": missed, "money": MONEY},
        {"name": "Discounts taken", "headers": HEAD + ["Discount terms", "Discount value"], "rows": taken, "money": MONEY},
        {"name": "Paid late", "headers": HEAD + ["Days late"], "rows": late, "money": MONEY},
        {"name": "Recommendations", "headers": ["Agreement", "Supplier", "Recommended action", "Owner", "Kind", "Projected gain, 12 months",
                                                "At stake", "How the rules value it", "Analysis of the supplier"],
         "rows": advice or [], "money": {"Projected gain, 12 months", "At stake"}, "widths": [12, 30, 50, 20, 11, 16, 12, 70, 90]},
        {"name": "Agreement terms", "headers": ["Agreement", "Supplier", "Term", "Read as", "Independent check", "Result", "Clause", "Quoted from the agreement"],
         "rows": terms, "widths": [12, 30, 28, 14, 16, 30, 12, 90]},
        {"name": "Decisions", "headers": ["Agreement", "Question", "Decision", "Reason", "Name", "Role", "When (SAST)", "Fingerprint of the figures shown",
                                           "Followed the recommendation"], "rows": decs, "widths": [11, 60, 34, 50, 22, 22, 18, 20, 34]},
        {"name": "Record", "headers": ["#", "When (SAST)", "Step", "By", "Role", "Fingerprint", "Entry hash"], "rows": record,
         "widths": [5, 22, 30, 24, 22, 20, 20]},
    ])
    summary_pdf = out / f"One-page summary {st['review_id']}.pdf"
    _summary(summary_pdf, st, f, agreements, gate, advice or [], gain)
    rec = out / f"Record of the review {st['review_id']}.jsonl"
    shutil.copyfile(review.record, rec)
    return [xlsx.name, summary_pdf.name, rec.name]


def _summary(path: Path, st: dict, f: dict, agreements: dict, gate: dict, advice: list[list], gain: float) -> None:
    """The review on one page: the four figures, what was found, the decisions, the largest amounts and the top actions."""
    d, tol, R = pdf.Pdf(), logic.TOLERANCE, kit.rand
    d.rect(0, 0, pdf.PAGE_W, 104, fill=pdf.NAVY)
    d.rect(0, 104, pdf.PAGE_W, 3, fill=pdf.CYAN)
    d.text(40, 44, "Early payment review", 22, True, pdf.WHITE)
    d.text(40, 72, f"One-page summary · review {st['review_id']}", 11, False, (0.89, 0.92, 0.95))
    tiles = [("Discounts not taken", R(f["missed"]["value"]), f"{f['missed']['invoices']} payments"),
             ("Cost of paying early", R(f["early"]["cost"]), f"{f['early']['invoices']} payments"),
             ("Paid late", f"{f['late']['invoices']}", f"payments, over {tol} days late"),
             ("Discounts taken", R(f["taken"]["value"]), f"{f['taken']['invoices']} payments, correct")]
    x = 40
    for label, value, sub in tiles:
        d.rect(x, 124, 122, 74, fill=pdf.PALE, stroke=pdf.LINE)
        d.text(x + 10, 142, label.upper(), 7.5, True, pdf.MUTE)
        d.text(x + 10, 166, value, 13, True, pdf.CORP)
        d.text(x + 10, 184, sub, 8.5, False, pdf.MUTE)
        x += 130
    y = 226
    d.text(40, y, "What the review found", 12.5, True, pdf.CORP)
    y += 18
    s = st["summary"]
    for ln in [f"{len(agreements)} agreements and {f['invoices_considered']} payments were reviewed, worth R{s['value']:,.2f} in total.",
               f"{R(f['missed']['value'])} in early-payment discounts was not taken, across {f['missed']['invoices']} payments.",
               f"{f['early']['invoices']} payments were made more than {tol} days before they were due, costing {R(f['early']['cost'])} in cash released early.",
               f"{f['late']['invoices']} payments were made more than {tol} days late; {f['taken']['invoices']} discounts were taken correctly and "
               f"{f['on_time']['invoices']} payments were on time."]:
        y = d.paragraph(52, y, "• " + ln, 500, 10)
    y += 8
    d.text(40, y, "Decisions", 12.5, True, pdf.CORP)
    y += 16
    for k, v in st["decisions"].items():
        ref = k.split(":", 1)[1]
        y = d.paragraph(52, y, f"• {ref} ({gate.get(ref, {}).get('sup', '')}): {v['label']}. {v['name']}, {v['role']}, {sast(v['at'])[-5:]}.", 500, 8.8)
    rel = st.get("release") or {}
    if rel:
        y = d.paragraph(52, y, f"• Release {rel['status']} by {rel.get('name')}, {rel.get('role')}, a different person in a release role, "
                               f"{sast(rel['at'])[-5:]} SAST.", 500, 8.8)
    y = d.paragraph(52, y + 2, "Each reason, in the person's own words, is in the evidence pack and the audit trail.", 500, 8, color=pdf.MUTE)
    y += 12
    d.text(40, y, "Largest amounts by supplier", 12.5, True, pdf.CORP)
    y += 14
    d.rect(40, y, 515, 17, fill=pdf.NAVY)
    for tx, label, al in ((48, "Supplier", "left"), (330, "Cost of paying early", "right"), (445, "Discounts not taken", "right"), (547, "Total", "right")):
        d.text(tx, y + 12, label, 8.5, True, pdf.WHITE, al)
    y += 17
    top = sorted((row for row in f["by_supplier"] if row[2] + row[3]), key=lambda row: -(row[2] + row[3]))[:5]
    for i, (sup, _ref, cost, miss, *_) in enumerate(top):
        if i % 2:
            d.rect(40, y, 515, 16, fill=pdf.PALE)
        d.text(48, y + 11.5, sup, 8.8)
        d.text(330, y + 11.5, R(cost), 8.8, align="right")
        d.text(445, y + 11.5, R(miss), 8.8, align="right")
        d.text(547, y + 11.5, R(cost + miss), 8.8, True, align="right")
        y += 16
    if advice:
        y += 18
        shown = advice[:5]
        d.text(40, y, f"The top {len(shown)} of {len(advice)} recommended actions" if len(advice) > len(shown) else "Recommended actions", 12.5, True, pdf.CORP)
        d.text(555, y, f"All {len(advice)}: R{gain:,.2f} over the next 12 months", 9.5, True, pdf.CORP, "right")
        y += 16
        for ref, name, action, owner, kind, g, risk, *_ in shown:
            label = action if name.split()[0].lower() in action.lower() else f"{name}: {action}"
            value = R(g) if g else f"{R(risk)} at stake" if risk else "protects supply"
            y = d.paragraph(52, y, f"• {label} · {owner} · {value}", 500, 9.2)
        d.paragraph(52, y + 2, "Recommended in the analysis and approved with the findings. Each value comes from the review's own rules: the next "
                               "12 months at the pace of the period reviewed, each change phased in over three months.", 500, 8, color=pdf.MUTE)
    d.line(40, 800, 555, 800)
    d.text(40, 816, "Nothing was changed in any system. The full record is in the evidence pack and the audit trail.", 8.5, False, pdf.MUTE)
    d.save(path)
