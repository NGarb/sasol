"""Early-payment review rules. Every figure the review reports comes from here.

The terms that govern a payment (see references/business-rules.md):
  due date             the payment period in clause 3.1, in days from the invoice date, or from the last day of the
                       invoice's month where the agreement counts from the month-end statement. Where an agreement can be
                       read two ways, a person decides which reading governs; an annexure or a side letter applies from
                       its effective date, and the terms for after an agreement ends from the day after it ends
Each payment has one outcome for its timing, and may also have missed a discount:
  discount taken       paid inside a discount window. Correct behaviour, never a finding
  paid early           outside a discount window, and paid more than TOLERANCE days before the due date. Valued as the
                       cost of the cash released early: amount x days early / 365 x FUNDING_RATE
  on time              within TOLERANCE days either side of the due date
  paid late            more than TOLERANCE days after the due date. Counted, not valued
  discount not taken   a discount was on offer and the payment came after its window. Valued as amount x discount %
Days run from the invoice date in the payment history. The agreements count from receipt of a valid invoice, usually a
few days later, so the same tolerance applies either side of the due date.
Levers, for the analysis (valued per supplier, over the months the payment history covers):
  pay on the due date  the cost of paying early stops: its monthly run-rate
  take the discount    the discounts not taken, net of the cost of paying sooner (at the window instead of when each
                       was paid): amount x (discount % - days sooner / 365 x FUNDING_RATE), monthly
  pay on time          late payments, where they are material (LATE_MATERIAL): a risk to supply, not valued
"""
from __future__ import annotations

import datetime as dt
import re
import statistics
from pathlib import Path

import ooxml

FUNDING_RATE = 0.095            # the cost of short-term funding: the Treasury rate
TOLERANCE = 5                   # days either side of the due date that count as on time
LATE_MATERIAL = (5, 0.10)       # the on-time lever is offered from 5 late payments, or a tenth of a supplier's payments
NUMBER_WORDS = {"seven": 7, "ten": 10, "fourteen": 14, "fifteen": 15, "twenty": 20, "twenty one": 21, "thirty": 30,
                "forty five": 45, "sixty": 60, "ninety": 90}
PAYMENT_COLUMNS = ["Invoice ID", "Supplier", "Contract Reference", "Site", "Category", "Invoice Date", "Paid Date", "Amount Excl VAT"]
REFER = "Refer it on"
OUTCOMES = ("Discount taken", "Paid early", "On time", "Paid late")


def load_payments(path: Path) -> list[dict]:
    rows = ooxml.read_xlsx(path)
    missing = [c for c in PAYMENT_COLUMNS if rows and c not in rows[0]]
    if not rows or missing:
        raise ValueError("The payment history doesn't have the expected columns: " + ", ".join(missing or PAYMENT_COLUMNS))
    for r in rows:
        r["days"] = (r["Paid Date"] - r["Invoice Date"]).days
        r["amount"] = float(r["Amount Excl VAT"])
    return rows


def day(iso) -> str:
    """A date as people write it: 31 March 2026."""
    d = dt.date.fromisoformat(str(iso)[:10])
    return f"{d.day} {d:%B %Y}"


def _date(text: str) -> str:
    return dt.datetime.strptime(text, "%d %B %Y").date().isoformat()


# ------------------------------------------------------------------ the independent reading
def _find(paras: list[str], pattern: str):
    for p in paras:
        m = re.search(pattern, p)
        if m:
            return m, p
    return None, None


def _term(value, clause: str, quote: str) -> dict:
    return dict(value=value, clause=clause, quote=quote)


def read_agreement(path: Path) -> dict:
    """The rule-based reader: the independent check on Claude's reading. Each term is {value, clause, quote}, or None."""
    paras = [p for p in ooxml.read_docx_paragraphs(path) if p.strip()]
    at = lambda title: next((i for i, p in enumerate(paras) if p.startswith(title)), len(paras))
    body, annex, letter = paras[:min(at("ANNEXURE B"), at("SIDE LETTER"))], paras[at("ANNEXURE B"):at("SIDE LETTER")], paras[at("SIDE LETTER"):]
    field = lambda label: (_find(paras, rf"^{label}: (.+)$")[0] or [None, None])[1]
    out = dict(ref=field("Agreement reference"), supplier=field("Supplier"), category=field("Category"), site=field("Delivery site"),
               commencement=field("Commencement date"), file=path.name)
    m, p = _find(body, r"^3\.1 Payment shall be made by the Purchaser within (\d+) \(([a-z ]+)\) days (of receipt|from statement)")
    days, words = int(m.group(1)), NUMBER_WORDS.get(m.group(2))
    out["payment_days"] = _term(days, "3.1", p)
    out["payment_days_in_words"] = _term(words, "3.1", p) if words and words != days else None
    out["payment_from_statement"] = _term(True, "3.1", p) if m.group(3) == "from statement" else None
    m, p = _find(body, r"^3\.4 Periods for payment in this Agreement run from the date of receipt of a valid tax invoice")
    out["payment_from_invoice"] = _term(True, "3.4", p) if m else None
    m, p = _find(body, r"^3\.2 Should the Purchaser settle a valid invoice within (\d+) \(.*?settlement discount of ([\d.]+) per cent")
    out["discount"] = dict(days=int(m.group(1)), pct=float(m.group(2)), clause="3.2", quote=p) if m else None
    m, p = _find(body, r"^3\.4 .*?enterprise and supplier development.*?within (\d+) \(")
    out["enterprise_development_days"] = _term(int(m.group(1)), "3.4", p) if m else None
    m, p = _find(annex, r"payment period in clause 3\.1 of the Agreement is amended to (\d+) \(")
    out["annexure_payment_days"] = _term(int(m.group(1)), "Annexure B.1", p) if m else None
    signed, s = _find(annex, r"^Signed for the Purchaser( by|: _)")
    out["annexure_signed_by_purchaser"] = _term(signed.group(1) == " by", "Annexure B", s) if m and signed else None
    e, _ = _find(annex, r"(?:effective from|take effect from) (\d{1,2} [A-Z][a-z]+ \d{4})")
    out["annexure_effective"] = _date(e.group(1)) if m and e else None
    m, p = _find(letter, r"^Further to clause 3\.2 .*?with effect from (\d{1,2} [A-Z][a-z]+ \d{4}), .*?settlement discount of ([\d.]+) per cent .*?within (\d+) \(")
    out["side_letter"] = dict(pct=float(m.group(2)), days=int(m.group(3)), effective=_date(m.group(1)), clause="Side letter", quote=p) if m else None
    ack, a_p = _find(letter, r"^(Acknowledged|Signed) for the Purchaser")
    out["side_letter_purchaser"] = a_p if m and ack else None
    m, p = _find(body, r"^4\.1 .*?gives ([a-z ]+?) days written notice of termination")       # D6: termination, not rate notice
    out["termination_notice_days"] = _term(NUMBER_WORDS.get(m.group(1)), "4.1", p) if m else None
    m, p = _find(body, r"^4\.1 .*?ends on (\d{1,2} [A-Z][a-z]+ \d{4})")
    out["end_date"] = _term(_date(m.group(1)), "4.1", p) if m else None
    m, p = _find(body, r"^4\.2 .*?after this Agreement ends.*?within (\d+) \(")
    out["after_end_payment_days"] = _term(int(m.group(1)), "4.2", p) if m else None
    m, p = _find(body, r"^2\.3 The rates in the schedule shall be adjusted annually")
    out["escalation"] = _term(True, "2.3", p) if m else None
    m, p = _find(body, r"Where an Annexure conflicts with the body of this Agreement, the Annexure prevails")
    out["annexure_prevails"] = _term(True, "5.1", p) if m else None
    m, p = _find(body, r"^5\.2 No amendment of this Agreement has any effect unless it is in writing and signed by both parties")
    out["amendments_signed_by_both"] = _term(True, "5.2", p) if m else None
    return out


# Every term the reading records, as [key, what it is]: a term is {value, clause, quote}, or null where the agreement doesn't have it
TERMS = [("payment_days", "Payment period"), ("payment_days_in_words", "Payment period in words"),
         ("payment_from_statement", "Counted from the statement"), ("payment_from_invoice", "Counted from the invoice"),
         ("annexure_payment_days", "Amended payment period"), ("annexure_signed_by_purchaser", "Annexure signed by the purchaser"),
         ("discount_pct", "Settlement discount"), ("discount_days", "Discount window"),
         ("side_letter_discount_pct", "Side letter discount"), ("side_letter_discount_days", "Side letter discount window"),
         ("enterprise_development_days", "Enterprise development period"), ("end_date", "Agreement ends"),
         ("after_end_payment_days", "Payment period after it ends"), ("termination_notice_days", "Termination notice"),
         ("escalation", "Price adjustment")]


def rule_value(rule: dict, key: str):
    """The independent reading's value for one term."""
    for prefix, name in (("discount_", "discount"), ("side_letter_discount_", "side_letter")):
        if key.startswith(prefix) and key[len(prefix):] in ("pct", "days"):
            return (rule.get(name) or {}).get(key[len(prefix):])
    v = rule.get(key)
    return v["value"] if v else None


def rule_term(rule: dict, key: str) -> dict | None:
    """The independent reading's clause and quote for one term."""
    for prefix, name in (("discount_", "discount"), ("side_letter_discount_", "side_letter")):
        if key.startswith(prefix):
            return rule.get(name)
    return rule.get(key)


def _norm(v):
    """A value as the comparison sees it: numbers as numbers, dates as ISO dates, yes/no as true/false."""
    if v is None or isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    if s.lower() in ("true", "yes"):
        return True
    if s.lower() in ("false", "no"):
        return False
    try:
        return float(s)
    except ValueError:
        pass
    for f in ("%Y-%m-%d", "%d %B %Y", "%d %b %Y"):
        try:
            return dt.datetime.strptime(s, f).date().isoformat()
        except ValueError:
            pass
    return s.lower()


def compare(rule: dict, claude: dict) -> dict:
    """Claude's reading against the rule-based reading, term by term. An agreement that can be read two ways needs a person."""
    terms, status = [], "confirmed"
    for key, label in TERMS:
        mine = claude.get(key) or {}
        if not isinstance(mine, dict):
            raise TypeError(key)
        a, b = mine.get("value"), rule_value(rule, key)
        if a is None and b is None:
            s = "not found"
        elif _norm(a) == _norm(b):
            s = "confirmed"
        else:
            s, status = "differs", "check"
        terms.append(dict(key=key, label=label, claude=a, check=b, status=s, clause=mine.get("clause"), quote=mine.get("quote")))
    kind = exception(rule)
    return dict(ref=rule["ref"], supplier=rule["supplier"], status="needs a person" if kind else status, kind=kind, terms=terms)


# The terms as the dashboard and the files show them: [id, what it is, the reading's keys (TERMS)]
SHOW = [("pay", "Payment period", ("payment_days", "payment_from_statement")), ("words", "In words", ("payment_days_in_words",)),
        ("ann", "Annexure B", ("annexure_payment_days", "annexure_signed_by_purchaser")),
        ("disc", "Settlement discount", ("discount_pct", "discount_days")), ("side", "Side letter", ("side_letter_discount_pct", "side_letter_discount_days")),
        ("inv", "Counted from", ("payment_from_invoice",)), ("ed", "Enterprise development", ("enterprise_development_days",)),
        ("end", "Agreement ends", ("end_date",)), ("after", "After it ends", ("after_end_payment_days",)),
        ("notice", "Termination notice", ("termination_notice_days",)), ("esc", "Price adjustment", ("escalation",))]
# The terms each kind of exception reads two ways: never shown as confirmed, only as decided
CONFLICT = {"annexure": {"pay", "ann"}, "unsigned annexure": {"pay", "ann"}, "words": {"pay", "words"}, "side letter": {"disc", "side"},
            "statement": {"pay", "inv"}, "expired": {"end", "after"}, "enterprise development": {"pay", "ed"}}


def two_readings(kind: str | None, key: str) -> bool:
    """Whether a term is one of those an agreement's exception reads two ways."""
    return any(key in keys for sid, _, keys in SHOW if sid in CONFLICT.get(kind, ()))


def term_rows(comparison: list[dict], agreements: dict[str, dict]) -> list[list]:
    """Every term of every agreement, for the files: how it was read, the independent check, the result, and the clause."""
    out = []
    for c in comparison:
        for t in c["terms"]:
            if t["claude"] is None and t["check"] is None:
                continue
            rt = rule_term(agreements[c["ref"]], t["key"]) or {}
            result = ("Two readings: decided by a person" if two_readings(c.get("kind"), t["key"]) else
                      {"confirmed": "Confirmed", "differs": "Differs: a person confirms it"}.get(t["status"], t["status"]))
            out.append([c["ref"], c["supplier"], t["label"], t["claude"], t["check"], result, t["clause"] or rt.get("clause", ""), t["quote"] or rt.get("quote", "")])
    return out


# ------------------------------------------------------------------ agreements that can be read two ways
def exception(a: dict) -> str | None:
    """How an agreement's payment terms can be read two ways, if they can: the kind of exception a person decides."""
    ann, main = a.get("annexure_payment_days"), a["payment_days"]["value"]
    if ann and ann["value"] != main:
        return "annexure" if (a.get("annexure_signed_by_purchaser") or {}).get("value", True) else "unsigned annexure"
    if a.get("payment_days_in_words"):
        return "words"
    sl, disc = a.get("side_letter"), a.get("discount")
    if sl and disc and (sl["pct"], sl["days"]) != (disc["pct"], disc["days"]):
        return "side letter"
    if a.get("payment_from_statement") and a.get("payment_from_invoice"):
        return "statement"
    if a.get("end_date") and a.get("after_end_payment_days") and a["after_end_payment_days"]["value"] != main:
        return "expired"
    if a.get("enterprise_development_days"):
        return "enterprise development"
    return None


def _disc(d: dict | None):
    return (d["pct"], d["days"]) if d else None


def options(a: dict) -> dict[str, str]:
    """The readings a person chooses between, as the card offers them, always with "Refer it on"."""
    kind, main = exception(a), a["payment_days"]["value"]
    if kind in ("annexure", "unsigned annexure"):
        other = a["annexure_payment_days"]["value"]
        o = {"main": f"Main agreement · {main} days", "annexure": f"{'Annexure' if kind == 'annexure' else 'Unsigned annexure'} · {other} days"}
    elif kind == "words":
        o = {"figures": f"Figures · {main} days", "words": f"Words · {a['payment_days_in_words']['value']} days"}
    elif kind == "side letter":
        (p, d), (sp, sd) = _disc(a["discount"]), _disc(a["side_letter"])
        o = {"agreement": f"Agreement · {p:g}% in {d} days", "side_letter": f"Side letter · {sp:g}% in {sd} days"}
    elif kind == "statement":
        o = {"invoice": f"From the invoice · {main} days", "statement": f"From the statement · {main} days"}
    elif kind == "expired":
        o = {"keep": f"Keep the agreement's {main} days", "standard": f"Standard {a['after_end_payment_days']['value']} days after it ended"}
    elif kind == "enterprise development":
        o = {"by_design": "Paid early by design: not a finding", "count": f"Count its early payments ({main} days)"}
    else:
        return {}
    return {**o, "refer": REFER}


def question(a: dict) -> str:
    """The decision's question, as the record and the audit trail keep it."""
    kind, ref, sup = exception(a), a["ref"], a["supplier"]
    if kind == "side letter":
        return f"Which settlement discount applies to {ref} ({sup}): the agreement's, or the side letter's?"
    if kind == "statement":
        return f"Does {ref} ({sup}) count its {a['payment_days']['value']} days from the invoice, or from the month-end statement?"
    if kind == "expired":
        return f"Which payment period applies to {ref} ({sup}) invoices after the agreement ended on {day(a['end_date']['value'])}?"
    if kind == "enterprise development":
        return f"Are the early payments to {ref} ({sup}), a qualifying small enterprise, paid early by design, or findings?"
    return f"Which payment period applies to {ref} ({sup})?"


def against(a: dict) -> dict | None:
    """The option that would go against a clause of the agreement that settles which reading prevails, and that clause:
    the annexure precedence (5.1), the signatures an amendment needs (5.2), the terms after an agreement ends (4.2)."""
    kind = exception(a)
    if kind == "annexure" and a.get("annexure_prevails"):
        return dict(option="main", clause="5.1", says="the annexure prevails")
    if kind == "unsigned annexure" and a.get("amendments_signed_by_both"):
        return dict(option="annexure", clause="5.2", says="an amendment needs both parties' signatures")
    if kind == "expired":
        return dict(option="keep", clause="4.2", says=f"invoices after it ends are on {a['after_end_payment_days']['value']}-day terms")
    return None


def governing(a: dict, choice: str | None) -> dict | None:
    """The terms that govern an agreement's payments: its payment period, what it counts from and its discount, with the
    changes that apply from a date (an annexure's or side letter's effective date, the day after an agreement ends).
    None when the agreement was referred on. An agreement that can be read two ways needs its decision."""
    t = dict(days=a["payment_days"]["value"], statement=False, disc=_disc(a.get("discount")), since=[])
    kind = exception(a)
    if not kind:
        return t
    if choice not in options(a):
        raise ValueError(f"{a['ref']} needs a decision")
    if choice == "refer":
        return None
    if kind in ("annexure", "unsigned annexure") and choice == "annexure":
        t["since"].append((a.get("annexure_effective") or "0001-01-01", dict(days=a["annexure_payment_days"]["value"])))
    elif kind == "words" and choice == "words":
        t["days"] = a["payment_days_in_words"]["value"]
    elif kind == "side letter" and choice == "side_letter":
        t["since"].append((a["side_letter"]["effective"], dict(disc=_disc(a["side_letter"]))))
    elif kind == "statement":
        t["statement"] = choice == "statement"
    elif kind == "expired" and choice == "standard":
        after = dt.date.fromisoformat(a["end_date"]["value"]) + dt.timedelta(days=1)
        t["since"].append((after.isoformat(), dict(days=a["after_end_payment_days"]["value"])))
    elif kind == "enterprise development" and choice == "by_design":
        t["days"] = a["enterprise_development_days"]["value"]
    return t


def effective(t: dict, first: dt.date | None = None) -> tuple[int, tuple | None, list]:
    """The governing terms at the agreement's first invoice: its payment days and discount (a change that applies from on
    or before `first` simply sets them), and the later changes to its days, as [(from, days)]."""
    days, disc, later = t["days"], t["disc"], []
    for since, c in t["since"]:
        if first is None or since <= first.isoformat():
            days, disc = c.get("days", days), c.get("disc", disc)
        elif "days" in c:
            later.append((since, c["days"]))
    return days, disc, later


def terms_text(t: dict, first: dt.date | None = None) -> str:
    """The governing terms in words, for the analysis and the files."""
    days, disc, later = effective(t, first)
    text = f"{days}-day payment terms" + "".join(f", then {d} days for invoices from {day(since)}" for since, d in later)
    text += ", counted from the month-end statement" if t["statement"] else ""
    return text + (f", with a {disc[0]:g}% discount for paying within {disc[1]} days" if disc else ", with no settlement discount")


def month_end(d: dt.date) -> dt.date:
    return (d.replace(day=28) + dt.timedelta(days=4)).replace(day=1) - dt.timedelta(days=1)


def assess(r: dict, t: dict) -> dict:
    """One payment against the terms that govern it: its due date in days from the invoice, its discount terms, its outcome
    and what it's worth."""
    days, disc = t["days"], t["disc"]
    for since, change in t["since"]:
        if r["Invoice Date"].isoformat() >= since:
            days, disc = change.get("days", days), change.get("disc", disc)
    if t["statement"]:
        days += (month_end(r["Invoice Date"]) - r["Invoice Date"]).days
    d = r["days"]
    took = bool(disc) and d <= disc[1]
    early = not took and d < days - TOLERANCE
    late = d > days + TOLERANCE
    return dict(due=days, disc=disc, took=took, early=early, late=late, missed=bool(disc) and d > disc[1],
                outcome=OUTCOMES[0] if took else OUTCOMES[1] if early else OUTCOMES[3] if late else OUTCOMES[2],
                cost=round(r["amount"] * (days - d) / 365 * FUNDING_RATE, 2) if early else 0.0,
                discount=round(r["amount"] * disc[0] / 100, 2) if disc else 0.0)


def all_governing(agreements: dict[str, dict], decisions: dict[str, str]) -> dict[str, dict | None]:
    return {ref: governing(a, decisions.get(ref)) for ref, a in agreements.items()}


def effects(payments: list[dict], a: dict) -> dict:
    """What each reading of an agreement's exception means for its own payments: for each option, how many are paid early
    (and what that costs), paid late, miss a discount (and its value) and take one. `affected` are the payments the
    choice changes: those after an agreement ended, or all of them."""
    mine = [r for r in payments if r["Contract Reference"] == a["ref"]]
    after = a["end_date"]["value"] if exception(a) == "expired" else None
    hit = [r for r in mine if not after or r["Invoice Date"].isoformat() > after]
    out = dict(payments=len(mine), value=round(sum(r["amount"] for r in mine), 2),
               affected=len(hit), affected_value=round(sum(r["amount"] for r in hit), 2))
    for option in options(a):
        if option != "refer":
            xs = [assess(r, governing(a, option)) for r in mine]
            out[option] = dict(early=sum(x["early"] for x in xs), cost=round(sum(x["cost"] for x in xs), 2), late=sum(x["late"] for x in xs),
                               missed=sum(x["missed"] for x in xs), missed_value=round(sum(x["discount"] for x in xs if x["missed"]), 2),
                               taken=sum(x["took"] for x in xs))
    return out


# ------------------------------------------------------------------ the findings
TIMING = ["Discount taken", "More than 30 days early", "6 to 30 days early", "On time", "6 to 15 days late", "More than 15 days late"]
LATE_BINS = ["6 to 10 days", "11 to 15 days", "16 to 30 days", "Over 30 days"]


def _timing(x: dict, d: int) -> int:
    if x["took"]:
        return 0
    off = d - x["due"]
    return 1 if off < -30 else 2 if x["early"] else 4 if x["late"] and off <= 15 else 5 if x["late"] else 3


def findings(payments: list[dict], agreements: dict[str, dict], decisions: dict[str, str]) -> dict:
    """Every payment against the terms that govern it: the four outcomes (which account for every payment assessed), the
    discounts not taken, by supplier, and how early and how late."""
    gov = all_governing(agreements, decisions)
    f = dict(early=dict(invoices=0, invoice_value=0.0, cost=0.0), missed=dict(invoices=0, value=0.0), taken=dict(invoices=0, value=0.0),
             late=dict(invoices=0), on_time=dict(invoices=0), referred=sorted(ref for ref, t in gov.items() if t is None))
    sup, timing, late_bins, top = {}, {}, [0] * len(LATE_BINS), []
    considered = [r for r in payments if gov.get(r["Contract Reference"]) is not None]
    for r in considered:
        a = agreements[r["Contract Reference"]]
        x = assess(r, gov[a["ref"]])
        # [cost of paying early, discounts not taken, early, missed, late, on time, taken, payments]
        s = sup.setdefault(a["ref"], [0.0, 0.0, 0, 0, 0, 0, 0, 0])
        s[7] += 1
        timing.setdefault(a["ref"], [0] * len(TIMING))[_timing(x, r["days"])] += 1
        if x["took"]:
            f["taken"]["invoices"] += 1
            f["taken"]["value"] += x["discount"]
            s[6] += 1
        elif x["early"]:
            f["early"]["invoices"] += 1
            f["early"]["invoice_value"] += r["amount"]
            f["early"]["cost"] += x["cost"]
            s[0] += x["cost"]
            s[2] += 1
            top.append([r["Invoice ID"], a["supplier"], a["ref"], r["days"], x["due"], round(r["amount"], 2), x["cost"]])
        elif x["late"]:
            f["late"]["invoices"] += 1
            s[4] += 1
            off = r["days"] - x["due"]
            late_bins[0 if off <= 10 else 1 if off <= 15 else 2 if off <= 30 else 3] += 1
        else:
            f["on_time"]["invoices"] += 1
            s[5] += 1
        if x["missed"]:
            f["missed"]["invoices"] += 1
            f["missed"]["value"] += x["discount"]
            s[1] += x["discount"]
            s[3] += 1
    for k, m in (("early", "invoice_value"), ("early", "cost"), ("missed", "value"), ("taken", "value")):
        f[k][m] = round(f[k][m], 2)
    f["invoices_considered"] = len(considered)
    f["by_supplier"] = sorted(([agreements[ref]["supplier"], ref, round(v[0], 2), round(v[1], 2), *v[2:]] for ref, v in sup.items()),
                              key=lambda x: -(x[2] + x[3]))
    f["timing"], f["late_bins"] = timing, late_bins
    f["top_early"] = sorted(top, key=lambda x: -x[6])[:8]
    return f


def headline(f: dict) -> dict:
    """Only what's needed to fingerprint the release: the totals, and what was set aside."""
    return {k: f[k] for k in ("early", "missed", "taken", "late", "on_time", "referred")}


# ------------------------------------------------------------------ for the analysis
def period_months(payments: list[dict]) -> int:
    """How many calendar months the payment history covers, by invoice date."""
    first, last = min(r["Invoice Date"] for r in payments), max(r["Invoice Date"] for r in payments)
    return (last.year - first.year) * 12 + last.month - first.month + 1


def supplier_stats(payments: list[dict], agreements: dict[str, dict], decisions: dict[str, str]) -> dict[str, dict]:
    """Each agreement's payments against its governing terms: the same outcomes and values as findings()."""
    gov, out = all_governing(agreements, decisions), {}
    for r in payments:
        ref = r["Contract Reference"]
        if ref not in agreements or gov.get(ref) is None:
            continue
        t = gov[ref]
        s = out.setdefault(ref, dict(first=r["Invoice Date"], n=0, value=0.0, days=[], early=0, early_value=0.0, early_cost=0.0, missed=0,
                                     missed_value=0.0, missed_net=0.0, taken=0, taken_value=0.0, late=0, late_days=[], on_time=0, disc=None))
        s["first"] = min(s["first"], r["Invoice Date"])
        x = assess(r, t)
        s["n"] += 1
        s["value"] += r["amount"]
        s["days"].append(r["days"])
        s["disc"] = x["disc"] or s["disc"]
        if x["took"]:
            s["taken"] += 1
            s["taken_value"] += x["discount"]
        elif x["early"]:
            s["early"] += 1
            s["early_value"] += r["amount"]
            s["early_cost"] += x["cost"]
        elif x["late"]:
            s["late"] += 1
            s["late_days"].append(r["days"] - x["due"])
        else:
            s["on_time"] += 1
        if x["missed"]:
            s["missed"] += 1
            s["missed_value"] += x["discount"]
            s["missed_net"] += x["discount"] - round(r["amount"] * (r["days"] - x["disc"][1]) / 365 * FUNDING_RATE, 2)
    for ref, s in out.items():
        first = s.pop("first")
        s["terms"], s["due_days"] = terms_text(gov[ref], first), effective(gov[ref], first)[0]
        s["median_days"] = statistics.median(s.pop("days"))
        for k in ("value", "early_value", "early_cost", "missed_value", "missed_net", "taken_value"):
            s[k] = round(s[k], 2)
    return out


def late_material(s: dict) -> bool:
    """Whether a supplier's late payments are enough to act on: 5 or more, or at least 2 and a tenth of its payments.
    The on-time lever is offered only then, so a stray late payment doesn't become a recommendation."""
    return s["late"] >= LATE_MATERIAL[0] or (s["late"] >= 2 and s["late"] >= LATE_MATERIAL[1] * s["n"])
