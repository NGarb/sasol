#!/usr/bin/env python3
"""The early-payment review. Claude runs one step at a time; each prints plain-English JSON.

  ready                       the dashboard before any files arrive (for a pre-warmed chat)
  start     [--folder …]     check the project folder's files and open the review
  read                        print the agreements' text for Claude to read (nothing else)
  check     --reading FILE    compare Claude's reading with the independent rule-based reading
  gate                        print every agreement that can be read two ways, with its evidence, for the assessment
  gate      --assessment FILE check the assessment, open a decision for each, and give the card, set to the recommendations
  decide    --name --role --file FILE      record the card's decisions ({"decisions": [{"item", "option", "reason"}]})
            --name --role --item --option --reason    or one decision
  findings                    calculate (only after every decision), and print the brief for the analysis
  analysis  --file FILE       check the analysis against the review's own figures, then ask for release
  release   --approve|--return --reason --name --role --reviewed   (a different person, in a release role)
  publish                     file everything in the project folder (only if approved)
  verify    [--file RECORD]   tamper check on this review's record, or on a downloaded copy
  dashboard [--run]           rewrite the dashboard for the current stage (--run: data only)
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import analysis  # noqa: E402
import logic  # noqa: E402
import ooxml  # noqa: E402
import skillkit as kit  # noqa: E402
from governance import Review, ReviewError, verify_record  # noqa: E402

WORK = kit.work_dir()
TEMPLATE = HERE.parent / "assets" / "dashboard.html"
CARD = HERE.parent / "assets" / "decision-card.html"
ROLES = kit.roles()
DECIDERS = ROLES["decide"]["agreement terms"]
LABELS = {"stage-read": "Agreements read", "stage-checked": "Readings compared", "stage-calculated": "Findings calculated"}
TITLE, TAGLINE = "Early Payment Detection", "Supplier payments against the agreed terms"
QUESTION = "Are we paying suppliers on the right day, and taking the discounts we negotiated?"
NUMBERS = "zero one two three four five six seven eight nine ten eleven twelve".split()
NOT_STARTED = "The review hasn't started yet. It begins by reading the agreements and the payment history in the project folder."
NOT_CHECKED = "The agreements haven't been read and checked yet, so there's nothing to decide on."
NOT_CALCULATED = "The findings haven't been calculated yet."


def rv() -> Review:
    return Review(WORK)


def needs(*files: str, message: str) -> None:
    kit.needs(WORK, *files, message=message)


def saved(name: str):
    p = WORK / name
    return json.loads(p.read_text()) if p.exists() else None


def save(name: str, obj) -> None:
    (WORK / name).write_text(json.dumps(obj, indent=1, default=str))


def payments() -> list[dict]:
    return logic.load_payments(Path(rv().state["files"]["payments"]))


def agreements() -> dict[str, dict]:
    return {a["ref"]: a for a in saved("rule-reading.json")}


def decided() -> dict[str, str]:
    """The options people chose, by agreement."""
    return {k.split(":", 1)[1]: v["option"] for k, v in rv().state["decisions"].items()}


def word(n: int) -> str:
    return NUMBERS[n] if 0 <= n < len(NUMBERS) else str(n)


def review_date() -> dt.date:
    """The day the review started, in South African time: the projection starts the month after."""
    return dt.datetime.fromisoformat(rv().entries()[0]["at"]).astimezone(kit.SAST).date()


def sast(at: str) -> str:
    """A recorded time as people read it, in South African time: 26 Sep 2026 10:42 SAST."""
    t = dt.datetime.fromisoformat(at).astimezone(kit.SAST)
    return f"{t.day} {t:%b %Y %H:%M} SAST"


# ------------------------------------------------------------------ how terms are shown
def shown(sid: str, v: dict) -> str | None:
    """One term's value in words, from its keys' values (Claude's reading or the independent check), or None."""
    keys = next(k for s, _, k in logic.SHOW if s == sid)
    first, second = v.get(keys[0]), v.get(keys[-1])
    if first is None:
        return None
    try:
        if sid == "pay":
            return f"{first} days" + (" from statement" if second else "")
        if sid == "ann":
            return f"{first} days" + (", signed by both" if second is True else ", not signed by the purchaser" if second is False else "")
        if sid in ("disc", "side"):
            return f"{float(first):g}% within {second} days"
        if sid == "end":
            return logic.day(logic._norm(first))
    except (TypeError, ValueError):
        return str(first)
    return {"inv": "From the invoice", "esc": "Yearly, by CPI"}.get(sid, f"{first} days")


def terms_view(c: dict, rule: dict, quote) -> list[list]:
    """Each term the agreement has: [id, what it is, clause, read as, the independent check (0 when it reads the same, None
    when it found nothing), status, quote index]. Status: c confirmed, d differs, x read two ways (a person decides)."""
    by = {t["key"]: t for t in c["terms"]} if c else {}
    out = []
    for sid, label, keys in logic.SHOW:
        mine = {k: (by.get(k) or {}).get("claude") for k in keys}
        check = {k: logic.rule_value(rule, k) for k in keys}
        read, chk = shown(sid, mine), shown(sid, check)
        if read is None and chk is None:
            continue
        term = next((logic.rule_term(rule, k) for k in keys if logic.rule_term(rule, k)), None) or {}
        status = "x" if sid in logic.CONFLICT.get(c.get("kind") if c else None, ()) else "d" if any((by.get(k) or {}).get("status") == "differs" for k in keys) else "c"
        out.append([sid, label, term.get("clause", ""), read, 0 if chk is not None and chk == read else chk, status if c else "n", quote(term.get("quote"))])
    return out


# ------------------------------------------------------------------ the decisions
def reads(fx: dict, kind: str) -> str:
    """What one reading means for the agreement's own payments, in words."""
    early = (f"{fx['early']} payments early" + (f" ({kit.rand_spoken(fx['cost'])} in cost)" if fx["cost"] else "")) if fx["early"] else "none early"
    if kind == "side letter":
        return f"{fx['missed']} discounts not taken ({kit.rand_spoken(fx['missed_value'])}) and {early}"
    return f"{early} and {fx['late'] or 'none'} late"


def gate_item(a: dict, fx: dict) -> dict:
    """One exception as the card, the dashboard and the record see it: the question, the options, the evidence with the
    dates that matter, what each reading means, and the clause a choice would go against."""
    kind, ref, sup, main = logic.exception(a), a["ref"], a["supplier"], a["payment_days"]["value"]
    q = lambda t: t["quote"] if t else ""
    ev, said = [], ""
    ann, disc, sl = a.get("annexure_payment_days"), a.get("discount"), a.get("side_letter")
    if kind in ("annexure", "unsigned annexure"):
        signed = a["annexure_signed_by_purchaser"]
        ev = [["Clause 3.1", f"{main} days", q(a["payment_days"])], ["Annexure B.1", f"{ann['value']} days", q(ann)],
              ["Annexure B", "Signed by both parties" if signed["value"] else "Not signed by the purchaser", q(signed)]]
        ev.append(["Clause 5.1", "The annexure prevails", q(a.get("annexure_prevails"))] if kind == "annexure" else
                  ["Clause 5.2", "Amendments need both signatures", q(a.get("amendments_signed_by_both"))])
        eff = logic.day(a["annexure_effective"]) if a.get("annexure_effective") else ""
        said = (f"Clause 3.1: {main} days · Annexure B, signed by both and effective from {eff}: {ann['value']} days · clause 5.1: the annexure prevails"
                if kind == "annexure" else f"Clause 3.1: {main} days · Annexure B, to take effect from {eff}: {ann['value']} days, signed by the "
                f"supplier but not the purchaser · clause 5.2: amendments need both signatures")
    elif kind == "words":
        w = a["payment_days_in_words"]["value"]
        ev = [["Clause 3.1", f"{main} in figures, {w} in words", q(a["payment_days"])]]
        said = f"Clause 3.1 says {main} days in figures and {w} in words"
    elif kind == "side letter":
        ev = [["Clause 3.2", f"{disc['pct']:g}% within {disc['days']} days", disc["quote"]], ["Side letter", f"{sl['pct']:g}% within {sl['days']} days", sl["quote"]],
              ["Side letter", "Acknowledged for the purchaser", a.get("side_letter_purchaser") or ""]]
        said = f"Clause 3.2: {disc['pct']:g}% within {disc['days']} days · a later side letter, effective from {logic.day(sl['effective'])}: within {sl['days']} days"
    elif kind == "statement":
        ev = [["Clause 3.1", f"{main} days from statement", q(a["payment_days"])], ["Clause 3.4", "From the invoice", q(a["payment_from_invoice"])]]
        said = f"Clause 3.1: {main} days \"from statement\" · clause 3.4: periods run from the invoice"
    elif kind == "expired":
        end, after = a["end_date"], a["after_end_payment_days"]
        ev = [["Clause 4.1", f"Ended {logic.day(end['value'])}", q(end)], ["Clause 4.2", f"{after['value']} days after it ends", q(after)]]
        said = f"Clause 4.1: ended {logic.day(end['value'])} · clause 4.2: later invoices on {after['value']}-day terms"
    elif kind == "enterprise development":
        ed = a["enterprise_development_days"]
        ev = [["Clause 3.1", f"{main} days", q(a["payment_days"])], ["Clause 3.4", f"Aims to pay within {ed['value']} days", q(ed)]]
        said = f"Clause 3.1: {main} days · clause 3.4: the purchaser aims to pay this qualifying small enterprise within {ed['value']} days"
    opts = logic.options(a)
    affected = (f"{fx['affected']} payments after it ended, {kit.rand_spoken(fx['affected_value'])}" if kind == "expired"
                else f"{fx['payments']} payments, {kit.rand_spoken(fx['value'])}")
    choices = [o for o in opts if o != "refer"]
    tag = {"main": f"At {main} days", "annexure": f"At {(ann or {}).get('value')} days", "figures": f"At {main} days",
           "words": f"At {(a.get('payment_days_in_words') or {}).get('value')} days", "agreement": f"Within {(disc or {}).get('days')} days",
           "side_letter": f"Within {(sl or {}).get('days')} days", "invoice": "From the invoice", "statement": "From the statement",
           "keep": f"At {main} days", "standard": f"At {(a.get('after_end_payment_days') or {}).get('value')} days",
           "by_design": "By design", "count": "Counted"}
    sub = f"{said} · {affected} · " + " · ".join(f"{tag[o]}: {reads(fx[o], kind)}" for o in choices)
    said_as = {"main": f"the main agreement's {main} days", "annexure": f"the {'annexure' if kind == 'annexure' else 'unsigned annexure'}'s {(ann or {}).get('value')} days",
               "figures": f"the figures' {main} days", "words": f"the words' {(a.get('payment_days_in_words') or {}).get('value')} days",
               "agreement": f"the agreement's {(disc or {}).get('days')}-day window", "side_letter": f"the side letter's {(sl or {}).get('days')}-day window",
               "invoice": "counting from the invoice", "statement": "counting from the month-end statement", "keep": f"keeping the agreement's {main} days",
               "standard": f"the standard {(a.get('after_end_payment_days') or {}).get('value')}-day terms", "by_design": "treating them as paid early by design",
               "count": f"counting them against its {main} days"}
    effect = f"For {sup} ({ref}), " + "; ".join(f"{said_as[o]} means {reads(fx[o], kind)}" for o in choices) + "."
    phrase = {"main": f"the main agreement's {main} days applies", "annexure": f"the {'annexure' if kind == 'annexure' else 'unsigned annexure'}'s "
              f"{(ann or {}).get('value')} days applies", "figures": f"the figures' {main} days apply", "words": f"the words' {(a.get('payment_days_in_words') or {}).get('value')} days apply",
              "agreement": f"the agreement's discount window of {(disc or {}).get('days')} days applies", "side_letter": f"the side letter's discount window of {(sl or {}).get('days')} days applies",
              "invoice": f"its {main} days count from the invoice", "statement": f"its {main} days count from the month-end statement",
              "keep": f"the agreement's {main} days still apply after it ended", "standard": "the standard terms apply to invoices after it ended",
              "by_design": "its early payments are by design, so not a finding", "count": "its early payments count as findings",
              "refer": "refer it to a person with the authority to decide"}
    swing = max(fx[o]["cost"] + fx[o]["missed_value"] for o in choices) - min(fx[o]["cost"] + fx[o]["missed_value"] for o in choices)
    short = {"main": "Main agreement", "annexure": "Annexure" if kind == "annexure" else "Unsigned annexure", "figures": "Figures", "words": "Words",
             "agreement": "The agreement", "side_letter": "Side letter", "invoice": "From the invoice", "statement": "From the statement",
             "keep": "Agreement's terms", "standard": "Standard terms", "by_design": "By design", "count": "Counted", "refer": "Referred"}
    return dict(ref=ref, sup=sup, kind=kind, question=logic.question(a), options=opts, short={o: short[o] for o in opts}, sub=sub, effect=effect, evidence=ev,
                sentence={o: f"{ref}: {phrase[o]}." for o in opts}, fx={o: fx[o] for o in choices}, payments=fx["payments"], value=fx["value"],
                affected=[fx["affected"], fx["affected_value"]], against=logic.against(a), swing=round(swing, 2))


def assess_view(g: dict) -> dict:
    """One agreement as it's assessed: the question, the options, each clause that matters (quoted), what each reading means
    for its payments, and the clause a choice would go against."""
    ag = g["against"]
    return dict(item=g["ref"], supplier=g["sup"], question=g["question"], options=g["options"],
                clauses=[dict(clause=x[0], says=x[1], quote=x[2]) for x in g["evidence"]], evidence=g["sub"], effect=g["effect"],
                **({"against": f"{g['options'][ag['option']]} goes against clause {ag['clause']}: {ag['says']}"} if ag else {}))


def give_card(gates: list[dict]) -> None:
    """The decision card, set to the recommendation for each agreement, and what Claude says around it."""
    n = len(gates)
    card = kit.decision_card(CARD, WORK / "decision-card.html", kicker="Your decisions · agreement terms",
                             title=f"{word(n).capitalize()} agreements can each be read two ways" if n > 1 else f"{gates[0]['ref']} can be read two ways",
                             lead="Choose the reading that governs each one's payments, or refer it on, and say why.",
                             items=[dict(title=f"{g['ref']} · {g['sup']}", sub=g["sub"], options=[[k, l] for k, l in g["options"].items()],
                                         sentence=g["sentence"], rec=g.get("rec")) for g in gates], roles=DECIDERS)
    kit.emit(dict(ok=True, decision_needed=True, decisions=n, roles=DECIDERS,
                  items=[dict(item=g["ref"], supplier=g["sup"], question=g["question"], options=g["options"], evidence=g["sub"], effect=g["effect"],
                              recommended=g["options"][g["rec"]["option"]], confidence=g["rec"]["confidence"]) for g in gates],
                  largest=[g["effect"] for g in gates[:2]], decision_card=card, **write_dashboard()))


def cmd_gate(a):
    needs("comparison.json", message=NOT_CHECKED)
    r = rv()
    gates = saved("gate.json")
    if gates:                                                           # the card is already open: give it again
        if not r.state["open"]:
            kit.fail("The decisions on the card have already been recorded.")
        give_card(gates)
        return
    ags, pays = agreements(), payments()
    two = [ags[c["ref"]] for c in saved("comparison.json") if c["status"] == "needs a person"]
    if not two:
        kit.emit(dict(ok=True, decision_needed=False, message="Every agreement reads one way, so no decision is needed.", **write_dashboard()))
        return
    gates = sorted((gate_item(ag, logic.effects(pays, ag)) for ag in two), key=lambda g: -g["swing"])
    if not a.assessment:                                                # first the assessment, then the card
        kit.emit(dict(ok=True, decision_needed=True, assess=True, decisions=len(gates), roles=DECIDERS,
                      instruction="Assess each agreement as references/assessment-guide.md describes, in assessment.json in the working folder, "
                                  "then run gate --assessment assessment.json.",
                      items=[assess_view(g) for g in gates]))
        return
    refs = {g["ref"] for g in gates}
    rec = kit.read_assessment(a.assessment, {g["ref"]: g["options"] for g in gates}, lambda t: t.strip().upper() if t.strip().upper() in refs else None)
    for g in gates:
        g["rec"] = rec[g["ref"]]
        shown_to_them = {k: g[k] for k in ("ref", "question", "options", "evidence", "fx", "affected")}
        try:
            r.open_decision(f"terms:{g['ref']}", g["question"], g["options"], shown_to_them, roles=DECIDERS, recommended=g["rec"])
        except ReviewError as e:
            kit.fail(str(e))
    save("gate.json", gates)
    give_card(gates)


def cmd_decide(a):
    gates = saved("gate.json")
    if not gates:
        kit.fail("There's no decision waiting right now.")
    by = {g["ref"]: g for g in gates}
    if a.file:
        rows = kit.read_decisions(a.file)
    elif a.option:
        rows = [(a.item or (gates[0]["ref"] if len(gates) == 1 else ""), a.option, a.reason or "")]
    else:
        kit.fail("Fix and run again: give the card's decisions as --file, or one decision as --item --option --reason.")
    items = []
    for item, option, reason in rows:
        g = by.get(str(item).strip().upper())
        if not g:
            kit.fail(f"Fix and run again: \"{item}\" isn't on the card. The items are: {', '.join(by)}.")
        key = next((k for k, label in g["options"].items() if option.strip().lower() in (k, label.lower())), None)
        if not key:
            kit.fail(f"Fix and run again: the option for {g['ref']} is one of: {', '.join(g['options'])}.")
        items.append((f"terms:{g['ref']}", key, reason))
    try:
        done = rv().decide_many(items, a.name or "", a.role or "")
    except ReviewError as e:
        kit.fail(str(e))
    left = [g["ref"] for g in gates if f"terms:{g['ref']}" not in rv().state["decisions"]]
    kit.emit(dict(ok=True, recorded=[dict(agreement=d["key"].split(":", 1)[1], decision=d["label"], reason=d["reason"]) for d in done],
                  name=done[0]["name"], role=done[0]["role"], at=kit.hhmm(done[0]["at"]), still_open=left, **write_dashboard()))


# ------------------------------------------------------------------ dashboard data
def build_run() -> dict:
    r = rv()
    st, comp, f, rel = r.state, saved("comparison.json"), saved("findings.json"), r.state.get("release")
    stage = {"received": 0, "read": 1, "checked": 1, "awaiting-decision": 2, "decided": 2, "calculated": 3, "awaiting-release": 4,
             "returned": 4, "released": 4, "published": 5}.get(st["stage"], 0)
    run = dict(title=TITLE, tagline=TAGLINE, id=st["review_id"], version=st.get("version") or kit.plugin_version(), stages=kit.STAGES, stage=stage,
               rate=logic.FUNDING_RATE, tol=logic.TOLERANCE,
               awaiting=st["stage"] in ("awaiting-decision", "awaiting-release"), data=st["summary"],
               focus="decisions" if st["stage"] == "awaiting-decision" else "overview")
    qt = []

    def quote(text):                      # the quote table: each whole clause stored once
        if not text:
            return None
        if text not in qt:
            qt.append(text)
        return qt.index(text)
    rule = agreements() if (WORK / "rule-reading.json").exists() else {}
    cmap = {c["ref"]: c for c in comp or []}
    run["dec"] = {k.split(":", 1)[1]: [d["option"], d["label"], d["reason"], d["name"], d["role"], kit.hhmm(d["at"]), d["shown"][:8]]
                  for k, d in st["decisions"].items()}           # kept apart, so recording the decisions sends only these
    run["contracts"] = []
    for ref, a in rule.items():
        c = cmap.get(ref)
        item = dict(ref=ref, sup=a["supplier"], site=a["site"], st=c["status"] if c else "received")
        if c:
            item.update(k=c.get("kind"), days=a["payment_days"]["value"], disc=list(logic._disc(a.get("discount")) or []) or None,
                        t=terms_view(c, a, quote))
        run["contracts"].append({k: v for k, v in item.items() if v is not None})
    gates = saved("gate.json")
    if gates:
        run["gates"] = []
        for g in gates:
            run["gates"].append(dict(ref=g["ref"], sup=g["sup"], k=g["kind"], q=g["question"], o=[[k, v, g["short"][k]] for k, v in g["options"].items()],
                                     ev=[[x[0], x[1], quote(x[2])] for x in g["evidence"]], n=g["payments"], v=g["value"], af=g["affected"],
                                     fx={o: [x["early"], x["cost"], x["late"], x["missed"], x["missed_value"], x["taken"]] for o, x in g["fx"].items()},
                                     ag=g["against"] and [g["against"]["option"], g["against"]["clause"], g["against"]["says"]],
                                     rc=g.get("rec") and [g["rec"]["option"], g["rec"]["confidence"], g["rec"]["reason"]]))
    run["qt"] = qt
    if f:
        run["findings"] = dict(early=f["early"], missed=f["missed"], taken=f["taken"], late=f["late"], onTime=f["on_time"]["invoices"],
                               referred=f["referred"], considered=f["invoices_considered"], bySup=f["by_supplier"], top=f["top_early"],
                               lateBins=f["late_bins"], timing=f["timing"])
    acc = saved("analysis.json")
    if acc:
        run["an"] = analysis.run_view(acc, saved("analysis-brief.json"), review_date())
    if rel:
        run["release"] = kit.release_view(rel)
    run["record"] = kit.record_view(r, LABELS)
    pays = Path(st["files"]["payments"]).name
    run["inputs"] = kit.inputs_view(r, about=about_inputs(), rows={pays: st["summary"]["invoices"]})
    run["downloads"] = st.get("downloads", [])
    if st.get("filed"):
        run["filed"] = st["filed"]
    return run


def about_inputs() -> dict:
    """What each file the review read is, by its name."""
    st = rv().state
    out = {Path(st["files"]["payments"]).name: "The payment history: every invoice paid under the agreements"}
    for a in (agreements().values() if (WORK / "rule-reading.json").exists() else []):
        out[a["file"]] = f"The agreement with {a['supplier']} ({a['ref']})"
    return out


def ready_run() -> dict:
    """The dashboard before any files arrive: shown in every pre-warmed chat."""
    return dict(title=TITLE, tagline=TAGLINE, id="New review", stages=kit.STAGES, stage=0, awaiting=False, ready=True, focus="overview")


def write_dashboard(print_run=False) -> dict:
    run = build_run()
    info = kit.fill_dashboard(TEMPLATE, run, WORK / "dashboard.html")
    if print_run:
        info["run"] = run
    return info


# ------------------------------------------------------------------ steps
def cmd_start(a):
    folder = kit.check_folder(a.folder)
    docs = kit.find_files(a.files, (".docx",), folder)
    books = [b for b in kit.find_files(a.files, (".xlsx",), folder) if "payment" in b.name.lower()] or kit.find_files(a.files, (".xlsx",), folder)
    if not docs or not books:
        kit.fail(f"The project folder needs the supplier agreements (Word) in {kit.DOCUMENTS} and the payment history (Excel) in {kit.DATA}."
                 if folder else "I need the supplier agreements (Word) and the payment history (Excel). Please add both.")
    try:
        pays = logic.load_payments(books[0])
    except ValueError as e:
        kit.fail(str(e))
    by_ref, by_site, by_month = {}, {}, {}
    for p in pays:
        s = by_ref.setdefault(p["Contract Reference"], [p["Supplier"], p["Contract Reference"], 0, 0.0])
        s[2] += 1
        s[3] += p["amount"]
        by_site[p["Site"]] = by_site.get(p["Site"], 0.0) + p["amount"]
        by_month[f"{p['Invoice Date']:%Y-%m}"] = by_month.get(f"{p['Invoice Date']:%Y-%m}", 0.0) + p["amount"]
    r = rv()
    try:
        r.start("early-payment", kit.review_id("EP"), docs + books[:1], version=kit.plugin_version())
    except ReviewError as e:
        kit.fail(str(e))
    first, last = min(p["Invoice Date"] for p in pays), max(p["Invoice Date"] for p in pays)
    st = r.put(files={"agreements": [str(d) for d in docs], "payments": str(books[0])}, folder=folder, folder_copy=bool(folder and a.copy),
               summary=dict(agreements=len(docs), invoices=len(pays), value=round(sum(p["amount"] for p in pays), 2),
                            suppliers=len({p["Supplier"] for p in pays}), sites=sorted(by_site, key=lambda s: -by_site[s]),
                            period=f"{first:%b %Y} to {last:%b %Y}", first=str(first.replace(day=1)), last=str(logic.month_end(last)),
                            unmatched=sorted(set(by_ref) - {d.name.split(' ')[0] for d in docs}),
                            bySup=sorted(([s[0], s[1], s[2], round(s[3], 2)] for s in by_ref.values()), key=lambda s: -s[3]),
                            byMonth=[[dt.date.fromisoformat(m + "-01").strftime("%b %Y"), round(v, 2)] for m, v in sorted(by_month.items())]))
    save("rule-reading.json", [logic.read_agreement(d) for d in docs])     # the independent reading, kept aside
    summary = {k: v for k, v in st["summary"].items() if k not in ("bySup", "byMonth", "first", "last")}
    kit.emit(dict(ok=True, review=st["review_id"], source="the project folder" if folder else "the files shared in the chat",
                  **summary, **write_dashboard()))


def cmd_read(a):
    needs("review-state.json", message=NOT_STARTED)
    r = rv()
    out = []
    for d in r.state["files"]["agreements"]:
        paras = [p for p in ooxml.read_docx_paragraphs(d) if p.strip()]
        out.append({"file": Path(d).name, "text": "\n".join(paras)})
    r.set_stage("read", {"agreements": len(out)}, about={x["file"]: x["text"] for x in out})    # the record fingerprints what was read
    kit.emit(dict(ok=True, instruction="Read each agreement and record the terms as described in references/extraction-guide.md.",
                  agreements=out))


def cmd_check(a):
    needs("review-state.json", "rule-reading.json", message=NOT_STARTED)
    try:
        data = json.loads(Path(a.reading).read_text())
        reading = data["agreements"] if isinstance(data, dict) else data         # the review keeps its own copy as a plain list
        by = {x["ref"]: x for x in reading}
    except (OSError, KeyError, TypeError, ValueError):
        kit.fail('Fix and run again: the reading must be a JSON file with an "agreements" list, one entry per agreement, each with its "ref".')
    rule = agreements()
    missing = sorted(set(rule) - set(by))
    if missing:
        kit.fail("Fix and run again: these agreements haven't been read yet: " + ", ".join(missing) + ".")
    comp = []
    for ref in sorted(rule):
        try:
            comp.append(logic.compare(rule[ref], by[ref]))
        except (KeyError, TypeError, ValueError, AttributeError):
            kit.fail(f'Fix and run again: the reading of {ref} doesn\'t follow the extraction guide. Record each term as {{"value", "clause", "quote"}}, or null.')
    save("claude-reading.json", reading)
    save("comparison.json", comp)
    confirmed, two = [c["ref"] for c in comp if c["status"] == "confirmed"], [c["ref"] for c in comp if c["status"] == "needs a person"]
    rv().set_stage("checked", {"confirmed": len(confirmed), "read two ways": two}, about=comp)    # and what the comparison found
    kit.emit(dict(ok=True, agreements=len(comp), confirmed=len(confirmed), needs_a_person=two,
                  differences=[dict(ref=c["ref"], term=t["label"], you_read=t["claude"], independent_check=t["check"])
                               for c in comp for t in c["terms"] if t["status"] == "differs"]))


def cmd_findings(a):
    needs("comparison.json", message=NOT_CHECKED)
    r = rv()
    if r.state.get("release"):
        kit.fail("The findings have already been calculated and sent for release.")
    ags = agreements()
    two = [ref for ref, ag in ags.items() if logic.exception(ag)]
    still = [ref for ref in two if f"terms:{ref}" not in r.state["decisions"]]
    if still:
        kit.fail("This step needs a decision first. Nothing has been calculated." if len(still) == len(two) else
                 f"This step needs every decision first: {', '.join(still)} {'is' if len(still) == 1 else 'are'} still open. Nothing has been calculated.")
    f = logic.findings(payments(), ags, decided())
    save("findings.json", f)
    r.set_stage("calculated", logic.headline(f))
    b = analysis_brief(f)
    save("analysis-brief.json", b)
    kit.emit(dict(ok=True, paid_early=f["early"], discounts_not_taken=f["missed"], discounts_taken=f["taken"], paid_late=f["late"],
                  on_time=f["on_time"], referred=f["referred"],
                  largest_early_cost=[dict(supplier=s[0], cost=s[2]) for s in sorted(f["by_supplier"], key=lambda s: -s[2])[:3] if s[2]],
                  analysis=analysis.for_claude(b)))


def analysis_brief(f: dict) -> dict:
    """What Claude reads to write the analysis: each supplier's facts and levers, every figure from the rules."""
    ags, pays, R = agreements(), payments(), kit.rand
    choices, labels = decided(), {k.split(":", 1)[1]: v["label"] for k, v in rv().state["decisions"].items()}
    stats, months = logic.supplier_stats(pays, ags, choices), logic.period_months(pays)
    share = lambda part, whole: f"{part / whole:.0%}" if whole else "0%"
    items = []
    for ref, s in sorted(stats.items(), key=lambda kv: -(kv[1]["early_cost"] + kv[1]["missed_value"])):
        a, disc = ags[ref], s["disc"]
        t = logic.governing(a, choices.get(ref))
        due = f"{s['due_days']} days" + (" from the month-end statement" if t["statement"] else "")
        facts = [s["terms"][0].upper() + s["terms"][1:] + (f" (\"{labels[ref]}\", as a person decided in this review)" if ref in labels else ""),
                 f"{s['n']} payments worth {R(s['value'])} over {months} months; median time to pay {s['median_days']:g} days after the invoice",
                 "Outcomes: " + ", ".join(f"{n} {what}" for n, what in ((s["taken"], "discount taken"), (s["early"], "paid early"),
                                                                       (s["on_time"], "on time"), (s["late"], "paid late")) if n)]
        levers = []
        if s["early"]:
            facts.append(f"Paid early: {s['early']} of {s['n']} payments ({R(s['early_value'])} of invoices), costing {R(s['early_cost'])} in cash "
                         f"released early ({share(s['early_cost'], f['early']['cost'])} of the review's early-payment cost)")
            levers.append(analysis.lever(ref, "due-date", f"Pay on the agreed due date ({due})", "recurring", s["early_cost"] / months,
                                         f"{R(s['early_cost'])} of cost from paying early over {months} months ({R(s['early_cost'] / months)} a month) "
                                         f"stops once payments go out on the due date"))
        if disc:
            facts.append(f"Discounts taken correctly: {s['taken']} payments, worth {R(s['taken_value'])}")
        if s["missed"]:
            facts.append(f"Discounts not taken: {s['missed']} payments, worth {R(s['missed_value'])} ({share(s['missed_value'], f['missed']['value'])} of "
                         f"the review's total); net of the cost of paying sooner, {R(s['missed_net'])}")
            if s["missed_net"] > 0:
                levers.append(analysis.lever(ref, "discount", f"Take the {disc[0]:g}% discount by paying within {disc[1]} days", "recurring",
                                             s["missed_net"] / months, f"{R(s['missed_value'])} of discounts not taken over {months} months, "
                                             f"{R(s['missed_net'])} net of the cost of paying sooner at {logic.FUNDING_RATE:.1%} a year ({R(s['missed_net'] / months)} a month)",
                                             instead_of="due-date" if s["early"] else None))
            else:
                facts.append("Taking this discount would cost more in cash paid sooner than the discount is worth")
        if s["late"]:
            facts.append(f"Paid late: {s['late']} of {s['n']} payments, {min(s['late_days'])} to {max(s['late_days'])} days after the due date")
            if logic.late_material(s):
                levers.append(analysis.lever(ref, "on-time", f"Pay within the agreed {due}, not after", "risk", 0.0,
                                             f"{s['late']} of {s['n']} payments went out {min(s['late_days'])} to {max(s['late_days'])} days after the due "
                                             f"date: a risk to supply and to the supplier's goodwill, not valued here", note="Protects supply"))
        items.append(dict(ref=ref, name=a["supplier"], facts=facts, levers=levers))
    st = rv().state["summary"]
    n, tol = len(choices), logic.TOLERANCE
    review = [f"{f['invoices_considered']} payments reviewed across {len(items)} agreements, over {months} months ({st['period']})",
              f"Cost of paying early: {R(f['early']['cost'])} across {f['early']['invoices']} payments, at the Treasury's short-term funding rate of "
              f"{logic.FUNDING_RATE:.1%} a year",
              f"Discounts not taken: {R(f['missed']['value'])} across {f['missed']['invoices']} payments",
              f"Discounts taken correctly: {R(f['taken']['value'])} across {f['taken']['invoices']} payments",
              f"Paid late, more than {tol} days after the due date: {f['late']['invoices']} payments; on time, within {tol} days of it: {f['on_time']['invoices']} payments",
              f"{n} agreements could each be read two ways, and a person decided which reading governs each"]
    review += [f"{ref} was referred to a person with authority, so its payments aren't in these figures" for ref in f["referred"]]
    return analysis.brief("suppliers", items, review, review_date())


def cmd_analysis(a):
    needs("findings.json", "analysis-brief.json", message=NOT_CALCULATED)
    r = rv()
    if r.state.get("release"):
        kit.fail("The analysis has already been checked and sent for release.")
    try:
        draft = json.loads(Path(a.file).read_text())
    except (OSError, ValueError):
        kit.fail("Fix and run again: the analysis must be a JSON file, as references/analysis-guide.md shows.")
    acc, problems = analysis.accept(draft, saved("analysis-brief.json"))
    if problems:
        kit.fail(analysis.fix_message(problems))
    save("analysis.json", acc)
    analysis.record(r, acc)
    r.request_release(logic.headline(saved("findings.json")), acc, roles=ROLES["release"], recommended=acc["release"])   # the release approves both
    card = kit.release_card(CARD, r, WORK / "release-card.html", roles=ROLES["release"])
    b = saved("analysis-brief.json")
    first = [dict(supplier=i["name"], does=l["does"]) for i in b["suppliers"] for l in i["levers"] if l["id"] in acc["overview"]["priorities"][:1]]
    kit.emit(dict(ok=True, headline=acc["overview"]["headline"], recommendations=acc["recommendations"],
                  projected_gain_12_months=kit.rand_spoken(acc["totals"]["gain12"]), **({"first_priority": first[0]} if first else {}),
                  roles=ROLES["release"], release_card=card, **write_dashboard()))


def cmd_release(a):
    if (WORK / "findings.json").exists() and not (WORK / "analysis.json").exists():
        kit.fail("Fix and run again: write your analysis and run analysis first; it asks for the release.")
    try:
        rel = rv().decide_release(a.approve, a.reason, a.name or "", a.role, reviewed=a.reviewed)
    except ReviewError as e:
        kit.fail(str(e))
    kit.emit(dict(ok=True, status=rel["status"], name=rel["name"], role=rel["role"], at=kit.hhmm(rel["at"])))


def cmd_publish(a):
    r = rv()
    f = saved("findings.json")
    if not f:
        kit.fail("There are no findings to release yet.")
    out = kit.outputs_dir()
    try:
        written = r.publish(logic.headline(f), lambda: write_outputs(out, f), saved("analysis.json"))
    except ReviewError as e:
        write_dashboard()
        kit.fail(str(e))
    folder = str(Path(a.folder)) if a.folder else r.state.get("folder")
    into_copy = bool(r.state.get("folder_copy") and folder == r.state.get("folder"))     # a working copy is never filed into
    acc, b = saved("analysis.json"), saved("analysis-brief.json")
    res = kit.complete_release(r, out, written=written, own=[], folder=folder, into_copy=into_copy, template=TEMPLATE, build_run=build_run,
                               briefing_for=lambda places: briefing(r, f, places), pack_extra=pack_extra(f, acc, b), data=data_sheets(f),
                               trace=trace(f, acc), labels=LABELS, about_inputs=about_inputs())
    kit.emit(dict(ok=True, **res, **write_dashboard()))


# ------------------------------------------------------------------ what the release files
def decision_views(r) -> list[dict]:
    """The decisions people made, for the briefing, each with the question as the record asked it."""
    gates = {g["ref"]: g for g in saved("gate.json") or []}
    return kit.decisions_view(r, lambda key, d: gates.get(key.split(":", 1)[1], {}).get("question", key))


def briefing(r, f: dict, filed: dict) -> dict:
    """What the management pack and the review note may say: this review's released figures, decisions and record."""
    m, e, t, n = f["missed"], f["early"], f["taken"], len(r.state["decisions"])
    acc, b = saved("analysis.json"), saved("analysis-brief.json")
    actions = analysis.actions(acc, b, most=len(analysis.rows(acc, b)))       # every recommended action, so they add up to the gain
    for ref in f["referred"]:
        actions.append(dict(action=f"Settle which terms apply to {ref}, referred on in this review", owner="Contract management"))
    gain, tol = acc["totals"]["gain12"], logic.TOLERANCE
    return kit.briefing(r, use_case=TITLE, question=QUESTION,
                        answer=f"{kit.rand_spoken(m['value'])} in early-payment discounts not taken, across {m['invoices']} payments, and "
                               f"{kit.rand_spoken(e['cost'])} in cost from paying {e['invoices']} invoices early.",
                        figures=[kit.figure("Discounts not taken", m["value"], "money", f"{m['invoices']} payments"),
                                 kit.figure("Cost of paying early", e["cost"], "money", f"{e['invoices']} payments"),
                                 kit.figure("Projected gain", gain, "money", "over the next 12 months"),
                                 kit.figure("Paid late", f["late"]["invoices"], note=f"payments, more than {tol} days after the due date"),
                                 kit.figure("Discounts taken", t["value"], "money", f"{t['invoices']} payments, correctly"),
                                 kit.figure("Payments reviewed", f["invoices_considered"], note=f"{f['on_time']['invoices']} on time")],
                        findings=[f"{kit.rand_spoken(m['value'])} in early-payment discounts was not taken, across {m['invoices']} payments.",
                                  f"{e['invoices']} payments were made more than {tol} days before they were due, costing {kit.rand_spoken(e['cost'])} in cash released early.",
                                  f"{f['late']['invoices']} payments were made more than {tol} days late, {t['invoices']} discounts were taken correctly, "
                                  f"and {f['on_time']['invoices']} payments were on time.",
                                  f"{word(n).capitalize()} agreements could each be read two ways; a person decided which reading governs each."],
                        decisions=decision_views(r), actions=actions, filed=filed, analysis=analysis.briefing(acc),
                        ai_help=dict(assist=f"The {len(agreements())} supplier agreements were read and every payment term recorded with its clause, "
                                            "confirmed by an independent check.",
                                     augment=f"{word(n).capitalize()} agreements that could each be read two ways were decided by a person, with their reasons. "
                                             f"Each supplier's payments were then analysed and {acc['recommendations']} actions recommended, which the review's "
                                             f"own rules value at {kit.rand_spoken(gain)} over the next 12 months.",
                                     automate="Fixed rules checked every payment against the terms that govern it, and the report, the management briefing "
                                              "and presentation, the evidence pack, the audit trail and the data were filed in the project folder."))


def pack_extra(f: dict, acc: dict, b: dict) -> dict:
    """The management pack's lead figure, scope, basis note, asks and charts."""
    st, m, e = rv().state["summary"], f["missed"], f["early"]
    hero = (dict(value=kit.rand_spoken(m["value"]), label="Discounts not taken", note=f"across {m['invoices']} payments") if m["value"] >= e["cost"]
            else dict(value=kit.rand_spoken(e["cost"]), label="Cost of paying early", note=f"across {e['invoices']} payments"))
    sites = kit.places(st["sites"])
    scope = " · ".join(x for x in (f"{st['agreements']} supplier agreements", f"{st['invoices']} payments", f"{kit.rand_spoken(st['value'])} paid",
                                   st["period"], sites) if x)
    basis = (f"Figures cover only the {st['agreements']} agreements and {st['invoices']} invoices in this review{', at ' + sites if sites else ''}, "
             f"from {logic.day(st['first'])} to {logic.day(st['last'])} (rand excluding VAT), and are not group totals.")
    acts = analysis.actions(acc, b, most=3)
    asks = [f"Agree that {x['owner']} will {x['action'][0].lower() + x['action'][1:]}." for x in acts[:3 if not f["referred"] else 2]]
    asks += [f"Name who will settle the terms of {', '.join(f['referred'])}, referred on in this review."] if f["referred"] else []
    top = [s for s in f["by_supplier"] if s[2] + s[3] > 0][:8]
    chart = dict(title="Cost of paying early and discounts not taken, by supplier", kind="hbar", money=True, stacked=True, labels=[s[0] for s in top],
                 series=[dict(label="Cost of paying early", data=[s[2] for s in top]), dict(label="Discounts not taken", data=[s[3] for s in top])])
    return dict(hero=hero, scope=scope, basis_note=basis, asks=asks, charts=kit.pack_charts(analysis.chart_series(acc, b, review_date()), chart))


def data_sheets(f: dict) -> list[dict]:
    """The Data workbook: every payment as read, every agreement term, every payment's outcome, and the decisions applied."""
    r, ags, pays, choices = rv(), agreements(), payments(), decided()
    gov = logic.all_governing(ags, choices)
    history = dict(name="Payment history", about="Every payment in the payment history, as the review read it", headers=logic.PAYMENT_COLUMNS,
                   rows=[[p[c] for c in logic.PAYMENT_COLUMNS] for p in pays], money={"Amount Excl VAT"}, widths=[12, 32, 18, 12, 30, 13, 13, 16])
    terms = logic.term_rows(saved("comparison.json"), ags)
    rows = []
    for p in pays:
        a = ags.get(p["Contract Reference"])
        t = gov.get(p["Contract Reference"]) if a else None
        base = [p["Invoice ID"], p["Supplier"], p["Contract Reference"], p["Site"], p["Invoice Date"], p["Paid Date"], p["days"]]
        if t is None:
            rows.append(base + [None, None, "", "Not assessed: the agreement was referred on", None, 0.0, 0.0, 0.0])
            continue
        x = logic.assess(p, t)
        rows.append(base + [x["due"], p["Invoice Date"] + dt.timedelta(days=x["due"]), f"{x['disc'][0]:g}% within {x['disc'][1]} days" if x["disc"] else "",
                            x["outcome"] + (" · discount not taken" if x["missed"] else ""), p["days"] - x["due"], x["cost"],
                            x["discount"] if x["missed"] else 0.0, x["discount"] if x["took"] else 0.0])
    assessed = dict(name="Payments assessed", about=f"Every payment against the terms that govern it: its due date, its outcome (on time is within "
                    f"{logic.TOLERANCE} days either side of the due date) and what it's worth", rows=rows,
                    headers=["Invoice", "Supplier", "Agreement", "Site", "Invoice date", "Paid date", "Days to pay", "Due (days after the invoice)",
                             "Due date", "Discount", "Outcome", "Days after the due date", "Cost of paying early", "Discount not taken", "Discount taken"],
                    money={"Cost of paying early", "Discount not taken", "Discount taken"}, widths=[12, 30, 11, 11, 12, 12, 10, 12, 12, 18, 34, 12, 14, 14, 14])
    gates = {g["ref"]: g for g in saved("gate.json") or []}
    decisions = []
    for key, d in r.state["decisions"].items():
        ref = key.split(":", 1)[1]
        g = gates.get(ref, {})
        fx = (g.get("fx") or {}).get(d["option"])
        what = ("Set aside: its payments aren't in the figures" if d["option"] == "refer" else
                (f"{fx['early']} paid early ({kit.rand(fx['cost'])})" if fx["early"] else "none paid early") + f", {fx['late'] or 'none'} paid late"
                + (f", {fx['missed']} discounts not taken ({kit.rand(fx['missed_value'])})" if fx["missed"] else "") if fx else "")
        decisions.append([ref, g.get("sup", ""), d["label"], what, (g.get("affected") or [None])[0], d["name"], d["role"], d["reason"], sast(d["at"]), g.get("question", "")])
    applied = dict(name="Decisions applied", about="Each decision a person made on an agreement that can be read two ways, and what it means for that agreement's payments",
                   headers=["Agreement", "Supplier", "Decision", "What it means for the agreement's payments", "Payments it applies to", "Name", "Role",
                            "Reason, in their words", "When", "Question"], rows=decisions, widths=[11, 30, 34, 60, 12, 22, 22, 50, 22, 60])
    return [history, dict(name="Agreement terms", about="Every term in every agreement: how it was read, the independent check, and the clause quoted",
                          headers=["Agreement", "Supplier", "Term", "Read as", "Independent check", "Result", "Clause", "Quoted from the agreement"],
                          rows=terms, widths=[11, 30, 28, 14, 14, 30, 12, 90]), assessed, applied]


def trace(f: dict, acc: dict) -> list[dict]:
    """How each released figure is worked out, from which file and rows, at which step of the record."""
    entries = rv().entries()
    step = lambda ev, label: next((f"#{e['seq']} {label}" for e in entries if e["event"] == ev), "")
    calc, pays = step("stage-calculated", "Findings calculated"), Path(rv().state["files"]["payments"]).name
    rows = f"{pays}, the rows marked {{}} in the Data workbook's Payments assessed sheet"
    rate, tol = f"{logic.FUNDING_RATE:.1%}", logic.TOLERANCE
    disc = ", ".join(ref for ref, a in agreements().items() if a.get("discount"))
    return [dict(figure="Payments reviewed", value=f"{f['invoices_considered']:,}", how="Every payment in the payment history under an agreement that wasn't referred on",
                 source=f"{pays}: {rv().state['summary']['invoices']} rows", step=calc),
            dict(figure="Cost of paying early", value=kit.rand(f["early"]["cost"]), how=f"Payments made more than {tol} days before the due date, outside any "
                 f"discount window; each valued at invoice value × days early ÷ 365 × {rate}, the Treasury's short-term funding rate", source=rows.format("Paid early") +
                 "; due dates from clause 3.1 of each agreement, as decided where it reads two ways", step=calc),
            dict(figure="Discounts not taken", value=kit.rand(f["missed"]["value"]), how="Payments made after the discount window of an agreement that offers "
                 "one; each valued at invoice value × discount %", source=rows.format("discount not taken") + f"; clause 3.2 of {disc}", step=calc),
            dict(figure="Discounts taken correctly", value=kit.rand(f["taken"]["value"]), how="Payments made inside the discount window: correct, and not a finding",
                 source=rows.format("Discount taken"), step=calc),
            dict(figure="Paid late", value=f"{f['late']['invoices']:,}", how=f"Payments made more than {tol} days after the due date; counted, not valued",
                 source=rows.format("Paid late"), step=calc),
            dict(figure="On time", value=f"{f['on_time']['invoices']:,}", how=f"Payments made within {tol} days either side of the due date",
                 source=rows.format("On time"), step=calc),
            dict(figure="Projected gain from the recommendations", value=kit.rand(acc["totals"]["gain12"]), how="Each recommended action's monthly value from the "
                 "review's own rules, phased in over three months, summed over the next 12 months", source="The analysis: the Recommendations sheet in the evidence pack",
                 step=step(analysis.EVENT, analysis.LABEL))]


def write_outputs(out: Path, f: dict) -> list[str]:
    import publish_pack
    acc = saved("analysis.json")
    return publish_pack.write(out, rv(), f, agreements(), saved("comparison.json"), payments(), saved("gate.json") or [],
                              analysis.rows(acc, saved("analysis-brief.json")), acc["totals"]["gain12"], LABELS)


def cmd_verify(a):
    ok, msg = verify_record(a.file) if a.file else rv().verify()
    kit.emit(dict(ok=ok, tamper_check=msg))


def cmd_ready(a):
    WORK.mkdir(parents=True, exist_ok=True)
    kit.emit(dict(ok=True, **kit.fill_dashboard(TEMPLATE, ready_run(), WORK / "dashboard.html")))


def cmd_dashboard(a):
    needs("review-state.json", message=NOT_STARTED)
    kit.emit(dict(ok=True, **write_dashboard(a.run)))


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("ready")
    st = sub.add_parser("start")
    st.add_argument("--folder", help="the project folder: its 01 Documents and 02 Data hold the review's files")
    st.add_argument("--copy", action="store_true", help="the folder is a working copy of the project folder's 01 Documents and 02 Data")
    st.add_argument("--files", nargs="*")
    sub.add_parser("read")
    sub.add_parser("check").add_argument("--reading", required=True)
    sub.add_parser("gate").add_argument("--assessment", help="the recommendation for each agreement, as references/assessment-guide.md describes")
    d = sub.add_parser("decide")
    d.add_argument("--name", required=True, help="the full name of the person deciding")
    d.add_argument("--role", required=True, help="their role, from the roles the gate printed")
    d.add_argument("--file", help='the card\'s decisions: {"decisions": [{"item", "option", "reason"}]}')
    d.add_argument("--item", help="one agreement, for a single decision")
    d.add_argument("--option")
    d.add_argument("--reason")
    sub.add_parser("findings")
    sub.add_parser("analysis").add_argument("--file", required=True, help="the analysis, as references/analysis-guide.md describes")
    rl = sub.add_parser("release")
    grp = rl.add_mutually_exclusive_group(required=True)
    grp.add_argument("--approve", action="store_true")
    grp.add_argument("--return", dest="approve", action="store_false")
    rl.add_argument("--reason", required=True)
    rl.add_argument("--name", required=True, help="the approver's full name")
    rl.add_argument("--role", required=True)
    rl.add_argument("--reviewed", action="store_true", help="the approver confirmed they reviewed the findings, the decisions and the recommendations")
    sub.add_parser("publish").add_argument("--folder", help="the project folder to file the released results in")
    sub.add_parser("verify").add_argument("--file", help="a downloaded record to check instead of this review's")
    sub.add_parser("dashboard").add_argument("--run", action="store_true")
    kit.main(p, {name[4:]: fn for name, fn in globals().items() if name.startswith("cmd_")})


if __name__ == "__main__":
    main()
