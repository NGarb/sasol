# Reading an agreement: what to record

You read every agreement yourself. An independent check then compares your reading, term by term. Record what the agreement **says**, not what seems sensible, and quote the sentence it comes from, word for word. Where an agreement can be read two ways, record **both** readings: a person decides which governs.

Agreements are numbered and laid out in their own ways. Find each term by what it says, wherever it sits, and record the clause number the agreement itself gives it.

## The file you write: `claude-reading.json`

```json
{"agreements": [
  {"ref": "AGR-0001", "supplier": "Example Supplier (Pty) Ltd",
   "payment_days": {"value": 30, "clause": "6.1", "quote": "6.1 The Customer shall pay each undisputed invoice within 30 (thirty) days of receiving it."},
   "discount_pct": {"value": 2, "clause": "6.3", "quote": "6.3 A settlement discount of 2% applies to any invoice paid within 10 (ten) days of receipt."},
   "discount_days": {"value": 10, "clause": "6.3", "quote": "6.3 A settlement discount of 2% applies to any invoice paid within 10 (ten) days of receipt."},
   "termination_notice_days": {"value": 60, "clause": "12.2", "quote": "12.2 Either party may end this agreement on sixty days' written notice to the other."},
   "escalation": {"value": true, "clause": "7.1", "quote": "7.1 The prices in Schedule 1 may be reviewed once a year ..."}}
]}
```

One entry per agreement, **every agreement you were given**, with its reference exactly as the agreement gives it. The example is illustrative: its supplier, clauses and values are made up, so don't copy them. Each term is `{"value", "clause", "quote"}`. Leave out a term the agreement doesn't have (or record it as `null`); never guess a value for a term that isn't there. Quote the whole sentence, not part of it.

## The terms every agreement may have

| Term | Record | Watch for |
|---|---|---|
| `payment_days` | The payment period, in days, as the **figures** give it | Figures with words in brackets, such as "21 (twenty-one) days": record 21 |
| `discount_pct` | The settlement discount percentage | Leave it out if no discount is offered |
| `discount_days` | The window, in days, within which the discount applies | Usually the same sentence as `discount_pct`; quote it for both |
| `termination_notice_days` | Notice needed **to end the agreement**, in days | **Not** the notice a supplier gives before changing its rates. Written in words ("forty-five days"): record 45. An agreement with a fixed end and no renewal has none |
| `escalation` | `true` if the rates are adjusted periodically | Leave it out if the agreement has no adjustment clause |

## The second readings: record each one the agreement has

| Term | Record | Where |
|---|---|---|
| `payment_days_in_words` | The payment period **in words**, only when it differs from the figures | Figures of 21 with words of "fourteen": `payment_days` 21 and `payment_days_in_words` 14, both quoting the same clause |
| `annexure_payment_days` | A later amendment to the payment period in an annexure. The clause is the annexure and paragraph, as the document names them | Only if the annexure *changes* the period |
| `annexure_signed_by_purchaser` | `true` if the annexure is signed for the purchaser, `false` if the purchaser's signature block is blank. Quote the purchaser's signature line | Whenever there's an `annexure_payment_days` |
| `side_letter_discount_pct`, `side_letter_discount_days` | The discount and its window in a later side letter that changes the agreement's discount; clause `"Side letter"` | A letter after the agreement's clauses |
| `payment_from_statement` | `true` if the payment period is counted **from statement** (the supplier's month-end statement), not from the invoice | Quote the payment clause |
| `payment_from_invoice` | `true` if another clause says payment periods run from the invoice | Record it with `payment_from_statement` |
| `end_date` | The date the agreement **ends**, as `"YYYY-MM-DD"`, when it has a fixed end and no renewal | A date written out in full: record it as `YYYY-MM-DD` |
| `after_end_payment_days` | The payment period for anything supplied **after** the agreement ends | Record it with `end_date` |
| `enterprise_development_days` | The period within which the purchaser aims to pay a qualifying small enterprise, under an enterprise and supplier development commitment | The payment clause still gives `payment_days` |

## When an agreement can be read two ways

Record both readings, each with its own quote, and **don't choose between them**. Which one governs is a person's decision, and the review stops for it. Also note, in your quotes, the clause that bears on the choice: an annexure that prevails over the agreement, amendments that must be signed by both parties, or the terms that apply after an agreement ends. The review shows them to the person deciding.

## If the check finds a difference

The check lists each term it read differently. Re-read that clause. If you were wrong, correct the file and run the check again. If you still read it differently, leave it, say so plainly, and carry on: a person confirms it.
