# Data dictionary: early-payment review

## Supplier agreements (Word, one per supplier)

Each agreement gives its reference, the supplier, and, where it has them, the category, the delivery site and the commencement date, then its clauses. Agreements are numbered and laid out in their own ways: find each term by what it says, not by where it usually sits. The terms the review uses:

| Term | What the agreement says |
|---|---|
| Invoicing | An invoice per order, or a statement of account at the end of each month |
| Payment period | How many days the purchaser has to pay, usually from receipt of a valid tax invoice, sometimes "from statement" |
| Settlement discount | Where offered: the percentage, and the days within which paying earns it |
| When payment periods run from | Where stated: from the invoice, or from the statement |
| Enterprise and supplier development | Where present: a commitment to pay a qualifying small enterprise sooner than the payment period |
| Duration and termination | How long the agreement runs, whether it renews, and the notice needed to end it; or a fixed end date |
| After it ends | Where present: the terms for anything supplied after the agreement ends |
| Precedence and amendments | Whether an annexure prevails where it conflicts with the agreement, and whether an amendment needs both parties' signatures |
| Rate adjustment | Where present: a periodic adjustment of the rates, and the notice before it takes effect |
| Annexure | Where present: an amendment to the payment period, with its effective date and its signatures |
| Side letter | Where present: a later letter changing the settlement discount, with its effective date |

## Payment history (Excel, one sheet: Payments)

Invoices paid under the agreements, one row each.

| Column | Meaning |
|---|---|
| Invoice ID | The invoice number |
| Supplier | Supplier name, as on the agreement |
| Contract Reference | The agreement it's paid under, by the reference the agreement gives itself |
| Site | Delivery site |
| Category | What was bought |
| Invoice Date | The date on the invoice |
| Paid Date | The date it was paid |
| Amount Excl VAT | Invoice value in rand, excluding VAT |

Days to pay = Paid Date − Invoice Date.

## What the release files

| File | Where | Contents |
|---|---|---|
| Dashboard report (HTML) | Report | The dashboard at release, every page, with the data row by row and the audit trail, each to download as Excel |
| Management briefing (Word) and Presentation (PowerPoint) | Report | The results for the next meeting, with charts, the decisions, and how it was governed |
| One-page summary (PDF) | Report | The findings, the decisions, the largest amounts by supplier and the top recommended actions |
| Evidence pack (Excel) | Evidence | Summary; every paid-early, discount-not-taken, discount-taken and paid-late payment; the recommendations; each agreement's terms with the clause quoted and the independent check's result; the decisions; the record |
| Audit trail (Excel) | Evidence | Every step and decision in order, who and why, how each figure was worked out, the inputs' fingerprints and every control |
| Data (Excel) | Evidence | The payment history as read, every agreement term, every payment's outcome against its terms, and the decisions applied |
| Record of the review | 04 Records | Every step, in order, each linked to the one before it; the tamper check confirms nothing changed |
