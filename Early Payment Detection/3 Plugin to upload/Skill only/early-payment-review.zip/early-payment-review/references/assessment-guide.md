# Assessing each agreement: what to recommend

Before the card is shown, recommend a reading for every agreement that can be read two ways. The card starts on your recommendation, with your assessment in the reason box, and the person keeps it or changes it. So write the assessment as a reason a person could sign: plain, specific, and based only on that agreement's own clauses.

Base it **only on what the gate printed for that agreement**: its clauses (quoted), what each reading means for its payments, and any clause a choice would go against. Don't use outside knowledge, and don't guess about the supplier.

## The file you write: `assessment.json`

```json
{"items": [
  {"item": "AGR-0001",
   "recommendation": "annexure",
   "confidence": "high",
   "assessment": "The annexure was signed by both parties, and the agreement says an annexure prevails where they conflict, so its period applies from its effective date."}
]}
```

One entry for **every agreement the gate printed**. The example is made up. Its fields:

| Field | Write |
|---|---|
| `item` | The agreement's reference, exactly as the gate printed it |
| `recommendation` | The key of one of its `options`, as the gate printed them. `refer` when the agreement can't settle it |
| `confidence` | `high`, `medium` or `low` |
| `assessment` | One or two plain sentences, 5 to 60 words, naming the clause or clauses that decide it |

## How to weigh the clauses

- **A clause that settles it decides it.** Where the agreement says which reading prevails (an annexure prevails, an amendment needs both signatures, later invoices go on other terms), recommend that reading with `high` confidence and name the clause. When the gate prints `against`, the option it names goes against such a clause: recommend it only if the agreement itself gives a reason to.
- **Words against figures:** where the words and the figures of the same clause disagree, the words usually prevail, unless the agreement says otherwise. Say so, with `medium` confidence.
- **A later document:** a side letter or annexure changes the terms from its effective date only if the purchaser signed or acknowledged it. Say whether it was, from the quoted clause.
- **Two clauses that both apply**, with nothing to say which prevails (a period "from statement" in one clause and "from the invoice" in another): recommend the likelier reading with `medium` confidence at most, name both clauses, and say what would settle it. When neither is likelier, recommend `refer`.
- **A policy choice**, not a question of wording (paying a qualifying small enterprise sooner, under a development commitment): recommend with `medium` confidence at most, and say it's a policy choice for the person deciding.
- **Never recommend a reading because of what it does to the figures.** The figures show what each reading means; the clauses decide which applies.
- Never say or imply wrongdoing. Recommend, cite and state your confidence. The person decides.
