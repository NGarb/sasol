# Writing the analysis

After the findings, the step prints `analysis`: the brief. It lists the review's headline facts and, for each of its suppliers, the facts the rules found and its **levers**: the actions the rules can value, each with what it's worth over the next 12 months and how that's worked out. Read it the way an experienced treasury and accounts-payable manager would, then write `claude-analysis.json` in the working folder and run `analysis --file claude-analysis.json`.

The analysis is where judgement shows. The rules have counted everything; say what it means and what to do about it.

## What good looks like

- **Explain, don't restate.** The dashboard already shows the numbers. Say what the pattern means and its most likely cause, and say so plainly when it's a likely cause rather than a fact.
- **Recommend what's worth doing.** Choose from that supplier's levers only, at most three, the most valuable or most urgent first. Leave out a lever that isn't worth the effort, and say why in the insight. A lever marked `risk` is never counted as a gain: it shows what's at stake, or has no rand value at all. Recommend it when the risk matters.
- **Write each action so it stands on its own:** start with a verb, name the supplier, and keep it to one line, for example the actions in the example below.
- **Give each action an owner** from `owners`: a team, never a person.
- **The overview** is for the executive who reads nothing else: a one-sentence headline, a short summary of what the review says about the business and where to start, and your priorities, the lever ids you recommended, most important first.
- **The voice is the project's.** Plain English, calm and specific. Never promise an outcome: say what a change *would* save, on the review's figures.
- **The release.** End with your recommendation to the approver: `approve` when every decision is recorded with its reason, the analysis stands on the review's own figures, and nothing is left unresolved; `return` when something should be reworked first, and say what. The approval card starts on it, with your reason in the box, and the approver keeps it or changes it, then names themselves and confirms the review. Write the reason as one an approver could sign: one or two sentences, 5 words or more and up to 360 characters, saying what they're approving and why it's ready. Items referred on don't stop a release: they're listed for someone with authority.

## Figures: the rule that matters

Use only figures that are in the brief: that supplier's facts and levers, or the review's headline facts. Quote them as given, or rounded: R4,062,118.50 as "R4.1 million", R248,610.40 as "R249,000", 41.6% as "42%". Counts and days exactly as given.

Never add, subtract, average or estimate a figure. The review totals your recommendations itself and shows the total beside your headline. Write dates as the brief writes them.

## The file

```json
{
  "overview": {
    "headline": "One sentence, up to 140 characters",
    "summary": "Up to 640 characters",
    "priorities": ["<lever id>", "<lever id>"]
  },
  "release": {
    "recommendation": "approve",
    "confidence": "high",
    "reason": "One or two sentences, up to 360 characters"
  },
  "suppliers": {
    "<ref>": {
      "insight": "Up to 480 characters",
      "recommendations": [{"lever": "<lever id>", "action": "Up to 120 characters", "owner": "<one of owners>"}]
    }
  }
}
```

- Every supplier with a lever needs an insight. One without levers needs nothing.
- `priorities` holds one to five lever ids, each one you recommended.
- `release` is your recommendation for the release: `recommendation` is `approve` or `return`, `confidence` is `high`, `medium` or `low`, and `reason` is the sentence the approval card starts on, for example *"Every decision is recorded with its reason and every figure in the analysis is the review's own, so the findings are ready to release."*
- If `analysis` answers *"Fix and run again"*, correct exactly what it names and run it again, without mentioning it. It never needs a different figure than the brief has.

## Example

One supplier's entry, as it reads in a finished analysis. The supplier and its figures are made up, to show the shape; the brief for each review gives its own. Here the brief gives 90-day terms with no discount, a median time to pay of 41 days, 38 of 52 payments made early, and R301,250.00 released early (64% of the review's early-payment cost), with the lever `AGR-0001:due-date`:

```json
"AGR-0001": {
  "insight": "Example Supplier is on 90-day terms with no discount, yet its median payment goes out on day 41 and 38 of its 52 payments were early. That looks like a payment run set for shorter terms applied to a 90-day agreement. It is 64% of the review's early-payment cost: R301,250.00 of cash released early for nothing. If paying early helps the supplier, ask for a discount in return rather than giving the cash away.",
  "recommendations": [
    {"lever": "AGR-0001:due-date", "action": "Set Example Supplier's 90-day terms in the payment run", "owner": "Treasury"}
  ]
}
```

The insight explains the pattern and its likely cause, and it may suggest something with no figure attached (asking for a discount). Where a supplier offers a discount and was also paid early, its two levers are alternatives: taking the discount means paying sooner, not on the due date, so recommend one of them. A supplier's late payments have a lever with no rand value, offered only where they're material: recommend it where the risk to supply matters, and say in the insight when a few short delays are worth watching rather than acting on. Where a person decided how an agreement reads, the brief says so; analyse the supplier on that reading.
