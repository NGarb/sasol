# Business rules: early-payment review

Every figure comes from these rules, applied the same way every time. Use them to explain a figure in one or two plain sentences.

## The due date that applies

Each agreement's payment period sets when a payment is due, in days from the invoice. Days are counted from the invoice date in the payment history. Agreements usually count from receipt of a valid invoice, which is a few days later, so the review allows **5 days either side of the due date** as on time.

## When an agreement can be read two ways

The review stops, and **a person decides** which reading governs the agreement's payments, or refers it on. Nothing is calculated until every one is decided. A referred agreement is set aside and listed; its payments aren't in the figures.

These are the ways the review recognises that an agreement's payment terms can be read two ways. Any agreement may have none, one or several of them; the review stops only for those it finds, and never guesses which reading applies.

| The agreement | The choice | What the decision changes |
|---|---|---|
| The payment clause gives one period, an annexure signed by both parties gives another, and the agreement says an annexure prevails where they conflict | The main agreement's period, or the annexure's | The payment period, for invoices from the annexure's effective date |
| The payment period's figures and its words disagree | The figures, or the words | The payment period |
| An annexure changes the period, but only the supplier signed it, and the agreement says an amendment needs both parties' signatures | The main agreement, or the unsigned annexure | The payment period |
| A later side letter changes the settlement discount or its window | The agreement's discount, or the side letter's | Which payments took the discount and which missed it, from the letter's effective date |
| The payment clause counts the period "from statement", and another clause counts it from the invoice | From the invoice, or from the month-end statement | The due date: the invoice date plus the period, or the last day of the invoice's month plus the period |
| The agreement ended during the period reviewed and payments continued, and it puts later invoices on other terms | Keep the agreement's period, or apply the later terms to invoices after it ended | The payment period for the later invoices |
| The purchaser aims to pay a qualifying small enterprise sooner than the payment clause requires, under an enterprise and supplier development commitment | Paid early by design (the shorter period governs: not a finding), or count its early payments against the payment clause | Whether its early payments are findings |

Where a choice goes against the clause that settles it (choosing the main agreement over an annexure the agreement says prevails, an annexure the agreement says has no effect unless both parties sign it, or keeping terms the agreement replaces once it ends), the decision page says so plainly, quoting that clause. The person's reason is recorded either way.

## The outcomes

Each payment reviewed has exactly one of four outcomes for its timing, so they add up to the payments reviewed. A discount not taken is counted as well, alongside its timing.

| Outcome | When | How it's valued |
|---|---|---|
| **Discount taken** | Paid within the discount window (the agreement's, or the side letter's where a person decided it applies) | Invoice value × discount %. **Correct behaviour, never a finding** |
| **Paid early** | Paid **more than 5 days** before the due date, and not inside a discount window | The cost of releasing the cash early: invoice value × days early ÷ 365 × **9.5%** |
| **On time** | Within 5 days either side of the due date | Not a finding |
| **Paid late** | Paid **more than 5 days** after the due date | Counted, not valued |
| **Discount not taken** (alongside the above) | A discount was on offer and the payment came after its window | Invoice value × discount %: the saving that was missed |

**The 9.5% rate** is the Treasury's cost of short-term funding: what cash paid out early costs the business for the days it's gone. It isn't the weighted average cost of capital used for long-term investment decisions, which is higher; at a higher rate the cost of paying early rises in proportion, and the what-if on the dashboard's Paid early page shows how.

**Plain explanations:**
- *Paid early:* "Paying before the due date costs the business the use of that cash. We value it at the Treasury's short-term funding rate, 9.5% a year, for the days it was paid early."
- *On time:* "A payment within five days either side of its due date counts as on time: payment runs are weekly, and the invoice date isn't the day the invoice arrived."
- *Discounts taken:* "These were paid inside the discount window, which is exactly right, so they're shown but aren't findings."
- *Paid early by design:* "Paying a qualifying small enterprise sooner, within the period its agreement names, is part of the purchaser's enterprise and supplier development commitment. Where a person decided that governs, those payments aren't findings."

## Recommendations and what they're worth

After the findings, Claude analyses each supplier and recommends which of its **levers** to act on, with an owner. The rules, not Claude, value each lever, from the supplier's own payments over the months the payment history covers:

| Lever | Offered when | Worth, each month |
|---|---|---|
| **Pay on the agreed due date** | Some payments were made early | The supplier's cost of paying early, as a monthly run-rate |
| **Take the discount** | Discounts were not taken, and taking them is worth more than the cost of paying sooner | The discounts not taken, less the cost of paying at the end of the window instead of when each was paid (at 9.5%), as a monthly run-rate |
| **Pay within the agreed terms, not after** | Five or more payments were late, or at least two and a tenth of the supplier's payments | Not valued: a risk to supply and goodwill |

**Over the next 12 months**, each change is phased in over its first three months (a quarter, a half, then three quarters of its monthly value, then all of it), so a lever is worth 10.5 months of its run-rate. The projection assumes the next 12 months look like the period reviewed. Claude may quote only the review's own figures: the review checks every figure in the analysis before accepting it, and the release approves the analysis with the findings.

**Plain explanation:** "Each recommendation is valued by the review's own rules: what the supplier's payments cost over the period reviewed, carried forward a year, with the change phased in over the first three months."

## The approvals

- Each **decision** is made by a named person, with a reason, in a role allowed to decide agreement terms. The card starts on the review's recommendation for each, with its reason; the person keeps or changes both, and the record says which. The roles: Contracts Manager, Category Manager, Procurement Manager or Legal Counsel. One card records all of them together, or none.
- The **release** is approved by a *different* person, named, in a release role: Financial Controller, Group Treasurer, Financial Manager or Chief Financial Officer. No one who made a decision can approve, and the approver confirms they reviewed the findings, the decisions and the recommendations.
- The release is tied to a fingerprint of the approved figures and recommendations. If anything changed after approval, it can't be released without approving again.
- Every step is kept in a tamper-evident record: each entry carries the fingerprint of the one before it, so any change shows. The audit trail filed with the release sets out every step, decision and figure.

## What this review never does

It changes nothing in any system. It produces evidence and recommendations for people to act on. Its projections are its own rules applied to the period reviewed and carried forward 12 months; it makes no other claim about savings.
