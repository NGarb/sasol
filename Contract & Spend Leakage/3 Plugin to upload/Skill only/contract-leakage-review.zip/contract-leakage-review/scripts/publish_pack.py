"""The review's own files: the evidence pack (Excel), the draft letters and the referral note (Word, on the letterhead) and
the one-page summary (PDF). Only ever called through Review.publish(), which refuses unless the release was approved; the
release then files them with the report, the management pack, the audit trail and the data (skillkit.complete_release).
Every letter is a draft for a person to review, sign and send: nothing is sent."""
from __future__ import annotations

import datetime as dt
from collections import defaultdict
from pathlib import Path

import audit
import logic
import office
import ooxml
import pdf
import skillkit as kit

fmt = lambda iso: kit.day(iso)
day = lambda iso: (lambda d: f"{d.day} {d:%b %Y}")(dt.date.fromisoformat(str(iso)[:10]))
R = lambda v: f"R{v:,.2f}"
low = lambda s: s[:1].lower() + s[1:]          # "Above CPI" as "above CPI"
LOGO = Path(__file__).resolve().parents[1] / "assets" / "sasol-logo.png"
DECIDED = {"claim": "Claim a credit note", "accept": "Accept the rise", "refer": "Refer it on",
           "register": "Rely on the contract register", "uncontracted": "Treat as uncontracted until filed"}
SIGN = [("p", "Yours faithfully"), ("p", " "), ("p", "______________________________"), ("p", "[Name and surname]"),
        ("p", "[Role], for and on behalf of the Purchaser")]


def write(out: Path, review, f: dict, agreements: dict, comparison: list, spend: list,
          advice: list[list] | None = None, gain: float = 0.0, split: list[float] | None = None) -> list[str]:
    st = review.state
    rid, off, cal, esc, missing = st["review_id"], f["off"], f["cal"], f["esc"], f["missing"]
    decs = st["decisions"]
    dec = decs.get("definition", {})
    rises = sorted((e for e in esc if e["overcharge"] > 0), key=lambda e: -e["overcharge"])
    measured, assumed = split or [gain, 0.0]
    money = {"Spend", "Value", "Amount", "Rate before", "Rate after", "Rate allowed", "Rate charged", "Charged above the terms", "Spend quoting it",
             "A year", "With no reference", "Projected gain, 12 months", "At stake"}
    summary = [["Review", rid], ["Review date", st["review_date"]],
               ["Purchase orders", st["summary"]["lines"]], ["Spend (R)", st["summary"]["value"]], ["Agreements read", len(agreements)],
               ["Agreements the spend quotes that aren't on file", ", ".join(f"{m['ref']} ({DECIDED[m['decision']].lower()})" for m in missing) or "None"],
               ["Definition of off contract", dec.get("label", "")], ["Off-contract purchases", off["lines"]], ["Off-contract spend (R)", off["value"]],
               ["Notice deadlines passed (will renew automatically)", sum(r["status"] == "passed" for r in cal)],
               ["Notice deadlines within 60 days", sum(r["status"] == "due within 60 days" for r in cal)],
               ["Rate rises outside the terms", len(rises)], ["Charged above the terms (R)", round(sum(e["overcharge"] for e in rises), 2)],
               ["Claimed in credit notes (R)", round(sum(e["overcharge"] for e in rises if e["decision"] == "claim"), 2)],
               ["CPI allowed", "Headline CPI for the second month before the month of the notice, as published by Statistics South Africa (clause 2.3)"],
               ["Projected gain from the recommendations, next 12 months (R)", gain],
               ["Of which measured: credit notes and paying the agreed rate (R)", measured],
               ["Of which assumed: buying on contract at 5% (R)", assumed],
               ["On-contract saving assumed (planning assumption, not measured)", f"{logic.ON_CONTRACT_SAVING:.0%}"]]
    contracted = set(f["cats"])
    off_rows = [[s["PO ID"], s["Vendor Name"], s["Category"], s["Site"], s["PO Date"], s["amount"]] for s in spend
                if not s["ref"] and off["definition"] != "refer" and (off["definition"] == "A" or s["Category"] in contracted)]
    over_rows = [[e["ref"], e["supplier"], *inv] for e in rises for inv in e.get("invoices", [])]
    terms = [[c["ref"], c["category"], t["label"], t["claude"], t["check"], t["status"], t["clause"] or "", t["quote"] or ""] for c in comparison for t in c["terms"]]
    who = lambda d: kit.by(d)
    dec_rows = [[k, v["label"], v["reason"], v.get("name", ""), v.get("role", ""), sast(v["at"]), v["shown"][:16], audit.followed(v)] for k, v in decs.items()]
    rel = st.get("release") or {}
    if rel:
        dec_rows.append([f"Release: {rel['status']}", rel.get("reviewed", ""), rel.get("reason", ""), rel.get("name", ""), rel.get("role", ""), sast(rel.get("at")), rel["figures"][:16], ""])
    record = [[e["seq"], sast(e["at"]), kit.event_label(e, {"stage-read": "Agreements read", "stage-checked": "Readings compared"}), kit.who(e),
               e["fingerprint"][:16], e["hash"][:16]] for e in review.entries()]
    pack = out / f"Evidence pack {rid}.xlsx"
    ooxml.write_xlsx(pack, [
        {"name": "Summary", "headers": ["Item", "Value"], "rows": summary, "widths": [52, 90]},
        {"name": "Off contract by category", "headers": ["Category", "Purchases", "Spend"], "rows": off["by_category"], "money": money, "widths": [34, 12, 18]},
        {"name": "Off-contract purchases", "headers": ["Order", "Supplier", "Category", "Site", "Date", "Amount"], "rows": off_rows, "money": money},
        {"name": "Agreements not on file", "headers": ["Agreement", "Category", "Purchases quoting it", "Spend quoting it", "A year", "Purchases with no reference",
                                                       "With no reference", "Decision", "Decided by"],
         "rows": [[m["ref"], m["category"], m["orders"], m["value"], m["annual"], m["blank_lines"], m["blank_value"], DECIDED[m["decision"]],
                   who(decs.get(f"missing:{m['ref']}", {}))] for m in missing], "money": money, "widths": [12, 24, 12, 16, 16, 12, 16, 32, 36]},
        {"name": "Renewal calendar", "headers": ["Agreement", "Category", "Period ends", "Notice by", "Days left", "Status"],
         "rows": [[r["ref"], r["category"], r["period_end"], r["notice_deadline"], r["days_left"], r["status"]] for r in cal], "widths": [12, 30, 13, 13, 10, 20]},
        {"name": "Rate changes", "headers": ["Agreement", "Supplier", "Result", "Rate before", "Rate after", "Rise", "CPI month", "CPI allowed", "Rate allowed",
                                             "Notice received", "Received by", "Effective per the notice", "First invoiced at the new rate", "Days of notice given",
                                             "Charged above the terms", "Decision"],
         "rows": [[e["ref"], e["supplier"], logic.CASES[e["case"]], e["base"], e["new"], f"{e['increase']:.1%}", logic.month_name(e["cpi_month"]) if e.get("cpi_month") else "",
                   f"{e['cpi']:.1%}" if e.get("cpi") else "", e.get("allowed") or "", e.get("notice") or "none", e.get("received") or "", e.get("effective") or "",
                   e.get("first") or "", e.get("notice_days") if e.get("notice_days") is not None else "", e["overcharge"], DECIDED.get(e.get("decision"), "")] for e in esc],
         "money": money},
        {"name": "Charged above the terms", "headers": ["Agreement", "Supplier", "Invoice", "Date", "Quantity", "Rate charged", "Rate allowed", "Charged above the terms"],
         "rows": over_rows, "money": money},
        {"name": "Recommendations", "headers": ["Agreement or category", "Name", "Recommended action", "Owner", "Kind", "Projected gain, 12 months",
                                                "At stake", "How the rules value it", "Analysis"],
         "rows": advice or [], "money": money, "widths": [24, 32, 50, 20, 11, 16, 16, 70, 90]},
        {"name": "Agreement terms", "headers": ["Agreement", "Category", "Term", "Read as", "Independent check", "Result", "Clause", "Quoted from the agreement"],
         "rows": terms, "widths": [11, 28, 20, 12, 16, 12, 9, 90]},
        {"name": "Decisions", "headers": ["Decision", "Chosen", "Reason", "Name", "Role", "When (SAST)", "Fingerprint of the figures shown",
                                          "Followed the recommendation"], "rows": dec_rows, "widths": [22, 40, 50, 22, 26, 20, 20, 34]},
        {"name": "Record", "headers": ["#", "When (SAST)", "Step", "By", "Fingerprint", "Entry hash"], "rows": record, "widths": [5, 20, 34, 40, 20, 20]},
    ])
    logo = LOGO.read_bytes() if LOGO.exists() else None
    head = lambda title, who_for: {"title": title, "subtitle": f"Contract & Spend Leakage · review {rid} · {who_for}", "footer": f"Draft for review · {rid} · nothing has been sent"}
    office.write_document(out / f"Draft letters {rid}.docx", letters(review, f, agreements, spend), head("Draft letters", "for a person to review, sign and send"), logo)
    office.write_document(out / f"Referral note {rid}.docx", referral(review, f), head("Referral note", "for the category managers and the contracts office"), logo)
    _summary(out / f"One-page summary {rid}.pdf", st, f, rises, dec, advice or [], gain, measured, assumed)
    return [pack.name, f"Draft letters {rid}.docx", f"Referral note {rid}.docx", f"One-page summary {rid}.pdf"]


def sast(at: str | None) -> str:
    """A recorded moment in South African time, as people read it: 29 Sep 2026 10:42."""
    try:
        t = dt.datetime.fromisoformat(at).astimezone(kit.SAST)
    except (TypeError, ValueError):
        return ""
    return f"{t.day} {t:%b %Y %H:%M}"


def reason(e: dict, cpi: str) -> str:
    """Why a rise is outside its agreement's terms, in the words of the rate query."""
    c, note = e["case"], (f"Your notice of {fmt(e['notice'])} gave {fmt(e['effective'])} as the effective date" if e.get("notice") else "")
    if c == "above CPI":
        return f"{note}. {cpi}, so each unit was charged {R(e['new'] - e['allowed'])} above the agreement."
    if c == "no notice":
        return (f"We have no record of a written notice of the adjusted rate. Clause 2.3 allows no adjustment until {e['need']} days after written notice "
                f"delivered to the contracts office (clause 8.1), so the previous rate of {R(e['base'])} applies to these invoices.")
    if c == "notice outside the terms":
        return (f"Your notice of {fmt(e['notice'])} wasn't delivered to the contracts office (our record shows: {e['received']}). Clause 8.1 requires notices to be "
                f"delivered in writing to the contracts office, so it isn't a valid notice under the agreement, and the previous rate of {R(e['base'])} applies "
                f"until a valid notice has run for {e['need']} days.")
    if c == "late notice":
        return (f"{note}, {e['notice_days']} days later. Clause 2.3 requires {e['need']} days' written notice, so the new rate could apply only from "
                f"{fmt((dt.date.fromisoformat(e['notice']) + dt.timedelta(days=e['need'])).isoformat())}; the invoices below were charged before then.")
    if c == "before the anniversary":
        return (f"{note}. Clause 2.3 allows an adjustment only from the anniversary of the commencement date, {fmt(e['anniversary'])}, so the previous rate "
                f"of {R(e['base'])} applies to the invoices before then.")
    return "The agreement fixes its rates, so the previous rate applies."


def panel(spend: list, ref: str) -> list[str]:
    """The panel suppliers under an agreement: those whose orders quote it, the largest first."""
    by = defaultdict(float)
    for s in spend:
        if s["ref"] == ref:
            by[s["Vendor Name"]] += s["amount"]
    return [n for n, _ in sorted(by.items(), key=lambda x: (-x[1], x[0]))]


def letters(review, f: dict, agreements: dict, spend: list) -> list[tuple]:
    """A notice of non-renewal for each deadline inside 60 days, and a rate query for each rise a person decided to claim."""
    today = fmt(review.state["review_date"])
    blocks = []
    for r in (x for x in f["cal"] if x["status"] == "due within 60 days"):
        a, names = agreements[r["ref"]], panel(spend, r["ref"])
        notice = a["termination_notice_days"]["value"]
        blocks += [("title", f"Notice of non-renewal · {r['ref']}"),
                   ("p", f"**To:** the {len(names)} panel suppliers under agreement {r['ref']}, the {r['category']} panel agreement, listed below"),
                   ("p", f"**Date:** {today}"),
                   ("p", f"**Agreement:** {r['ref']}, commencement date {fmt(a['commencement']['value'])}"),
                   ("p", f"In terms of clause 4.1 of the agreement, we give {notice} days' written notice that the agreement will not renew automatically at the "
                         f"end of the current period on {fmt(r['period_end'])}."),
                   ("p", "We intend to review the category before any new agreement is concluded, and will write to you about the arrangements after that date. "
                         "Please acknowledge receipt of this notice."),
                   *SIGN,
                   ("table", ["Panel supplier", "Agreement"], [[n, r["ref"]] for n in names]),
                   ("small", f"To take effect, this notice must reach each panel supplier by {fmt(r['notice_deadline'])}, in writing, as clauses 4.1 and 8.1 require."),
                   ("pagebreak",)]
    for e in sorted((x for x in f["esc"] if x["overcharge"] > 0 and x["decision"] == "claim"), key=lambda x: -x["overcharge"]):
        a = agreements[e["ref"]]
        rise = f"Your unit rate under agreement {e['ref']} rose from {R(e['base'])} to {R(e['new'])} ({e['increase']:.1%}), first invoiced on {fmt(e['first'])}."
        cpi = (f"Clause 2.3 allows a rise of no more than the annual change in headline CPI for {logic.month_name(e['cpi_month'])}, {e['cpi']:.1%}, as published "
               f"by Statistics South Africa: a rate of up to {R(e['allowed'])}")
        why = reason(e, cpi)
        ask = ("Please issue a credit note for the amount above and confirm that invoices from now on will be at no more than "
               f"{R(e['allowed'])} a unit." if e["case"] == "above CPI" else
               f"Please issue a credit note for the amount above. If you wish to adjust the rate, please give written notice to the contracts office as "
               f"clause 8.1 requires: an adjusted rate of up to {R(e['allowed'])} can then apply {e['need']} days later." if e.get("still") else
               "Please issue a credit note for the amount above.")
        blocks += [("title", f"Rate query · {e['ref']}"), ("p", f"**To:** {e['supplier']}"), ("p", f"**Date:** {today}"),
                   ("p", f"**Agreement:** {e['ref']}, the {a['category']} panel agreement"),
                   ("p", f"{rise} {why}"),
                   ("table", ["Invoice", "Date", "Quantity", "Rate charged", "Rate allowed", "Above the terms"],
                    [[i[0], day(i[1]), i[2], R(i[3]), R(i[4]), R(i[5])] for i in e["invoices"]] + [["Total", "", "", "", "", R(e["overcharge"])]]),
                   ("p", f"{ask} The total above the terms is **{R(e['overcharge'])}**."), *SIGN, ("pagebreak",)]
    if not blocks:
        return [("p", "No notice of non-renewal falls due within 60 days, and no rate rise was claimed, so no letter is needed.")]
    return blocks[:-1] if blocks[-1] == ("pagebreak",) else blocks


def referral(review, f: dict) -> list[tuple]:
    """The referral note: the off-contract hotspots for the category managers, the agreements to obtain for the contracts office,
    and anything a person referred on, with their reason."""
    st, off = review.state, f["off"]
    decs = st["decisions"]
    dec = decs.get("definition", {})
    b = [("h1", "Off-contract hotspots")]
    if off["definition"] == "refer":
        b.append(("p", f"The definition of off contract was referred on by {kit.by(dec)}: \"{dec.get('reason', '')}\". No off-contract spend is counted until "
                       "it's decided."))
    else:
        top = off["by_category"][:3]
        b += [("p", f"**Definition used:** {dec.get('label', '')}, decided by {kit.by(dec)}: \"{dec.get('reason', '')}\"."),
              ("p", f"{off['lines']:,} purchases worth {R(off['value'])} were bought off contract. The three categories with the most:"),
              ("table", ["Category", "Purchases", "Off-contract spend", "Share"], [[c, f"{n:,}", R(v), f"{v / off['value']:.0%}"] for c, n, v in top]),
              ("p", "Please review why these purchases didn't go through the agreements, and how orders in these categories are raised at each site. "
                    "Every off-contract purchase is listed in the evidence pack.")]
    obtain = [m for m in f["missing"] if m["decision"] != "refer"]
    if obtain:
        short = {"register": "Relied on the register", "uncontracted": "Uncontracted until filed"}
        b += [("h1", "Agreements to obtain and file"),
              ("p", "The purchases quote these agreements, but they aren't in the project folder, so their renewal dates and rates can't be checked:"),
              ("table", ["Agreement", "Category", "Purchases", "A year", "Decision"],
               [[m["ref"], m["category"], f"{m['orders']:,}", R(m["annual"]), short[m["decision"]]] for m in obtain]),
              ("p", f"Decided by {kit.by(decs.get('missing:' + obtain[0]['ref'], {}))}. Please send the signed agreements to the contracts office.")]
    refer = [(k, d) for k, d in decs.items() if k != "definition" and d["option"] == "refer"]
    if refer:
        esc, miss = {e["ref"]: e for e in f["esc"]}, {m["ref"]: m for m in f["missing"]}
        b += [("h1", "Referred for a decision"), ("p", "These were referred on at the review's decision point, for a person with the authority to decide:")]
        for k, d in refer:
            ref = k.split(":", 1)[1]
            e, m = esc.get(ref), miss.get(ref)
            what = (f"{e['supplier']}, {low(logic.CASES[e['case']])}: {R(e['overcharge'])} charged above the terms on {e['lines']} invoice lines"
                    if e and k.startswith("rate:") else f"{m['category']}: {m['orders']:,} purchases quote it, but the agreement isn't on file" if m else "")
            b.append(("p", f"**{ref}, {what}.** Referred by {kit.by(d)}: \"{d['reason']}\"."))
    return b + [("small", "Draft for review. Nothing has been sent.")]


def _summary(path: Path, st: dict, f: dict, rises: list, dec: dict, advice: list[list], gain: float, measured: float, assumed: float) -> None:
    off, cal = f["off"], f["cal"]
    d = pdf.Pdf()
    d.rect(0, 0, pdf.PAGE_W, 104, fill=pdf.NAVY)
    d.rect(0, 104, pdf.PAGE_W, 3, fill=pdf.CYAN)
    d.text(40, 44, "Contract and spend leakage review", 22, True, pdf.WHITE)
    d.text(40, 72, f"One-page summary · review {st['review_id']}", 11, False, (0.89, 0.92, 0.95))
    claimed = sum(e["overcharge"] for e in rises if e["decision"] == "claim")
    tiles = [("Off contract", f"R{off['value']:,.0f}" if off["definition"] != "refer" else "Referred", f"{off['lines']:,} purchases"),
             ("Renewals", str(sum(r["status"] != "later" for r in cal)), "passed or due in 60 days"),
             ("Above the terms", f"R{sum(e['overcharge'] for e in rises):,.0f}", f"{len(rises)} rate rises"),
             ("To recover", f"R{claimed:,.0f}", f"{sum(e['decision'] == 'claim' for e in rises)} credit notes claimed")]
    x = 40
    for label, value, sub in tiles:
        d.rect(x, 124, 122, 74, fill=pdf.PALE, stroke=pdf.LINE)
        d.text(x + 10, 142, label.upper(), 7.5, True, pdf.MUTE)
        d.text(x + 10, 166, value, 13, True, pdf.CORP)
        d.text(x + 10, 184, sub, 8.5, False, pdf.MUTE)
        x += 130
    y = 226
    d.text(40, y, "What the review found", 13, True, pdf.CORP)
    y += 18
    lines = [f"Off contract (definition {off['definition']}, decided by {kit.by(dec)}): {off['lines']:,} purchases worth R{off['value']:,.2f}."
             if off["definition"] != "refer" else f"The definition of off contract was referred on by {kit.by(dec)}, so it isn't counted here."]
    if f["missing"]:
        lines.append("Not on file: " + "; ".join(f"{m['ref']} ({m['category']}, R{m['annual']:,.0f} a year, {DECIDED[m['decision']].lower()})" for m in f["missing"]) + ".")
    passed = [r for r in cal if r["status"] == "passed"]
    due = [r for r in cal if r["status"] == "due within 60 days"]
    if passed:
        lines.append("Notice passed, so these will renew automatically: " + ", ".join(f"{r['ref']} (deadline {day(r['notice_deadline'])})" for r in passed) + ".")
    if due:
        lines.append("Notice due within 60 days: " + ", ".join(f"{r['ref']} by {day(r['notice_deadline'])}" for r in due) + ".")
    for e in rises:
        lines.append(f"{e['ref']} ({e['supplier']}): {low(logic.CASES[e['case']])}, R{e['overcharge']:,.2f} above the terms · {DECIDED[e['decision']].lower()}.")
    for ln in lines:
        y = d.paragraph(52, y, "• " + ln, 500, 9.5)
    y += 6
    y = d.paragraph(40, y, f"Rate rises are checked against the published headline CPI for the month clause 2.3 names. The review date is {fmt(st['review_date'])}. "
                           "The letters are drafts for review before sending.", 515, 9, color=pdf.MUTE)
    if advice:
        y += 18
        d.text(40, y, "Recommended actions", 13, True, pdf.CORP)
        d.text(555, y, f"R{gain:,.2f} over the next 12 months", 10, True, pdf.CORP, "right")
        y += 16
        for ref, name, action, owner, kind, g, risk, *_ in advice[:5]:
            label = action if name.split()[0].lower() in action.lower() or ref in action else f"{name}: {action}"
            value = f"R{g:,.2f}" if g else f"R{risk:,.2f} at stake" if risk else "not valued"
            y = d.paragraph(52, y, f"• {label} · {owner} · {value}", 500, 9.5)
        d.paragraph(52, y + 2, f"Of the projected gain, R{measured:,.2f} is measured (credit notes and paying the agreed rate) and R{assumed:,.2f} rests on the "
                               f"planning assumption that buying on contract costs {logic.ON_CONTRACT_SAVING:.0%} less. Each value comes from the review's own rules: "
                               "the next 12 months at the pace of the period reviewed, each change phased in over three months. A renewal's spend at stake is "
                               "never counted as a gain. The recommendations were approved with the findings.", 500, 8.5, color=pdf.MUTE)
    d.line(40, 790, 555, 790)
    rel = st.get("release") or {}
    d.text(40, 806, f"Decided by {kit.by(dec) or '-'}. Release approved by {kit.by(rel) or '-'}.", 8.5, False, pdf.MUTE)
    d.text(40, 820, "Nothing was sent or changed in any system. The full record is in 04 Records, and the audit trail in the Evidence folder.", 8.5, False, pdf.MUTE)
    d.save(path)
