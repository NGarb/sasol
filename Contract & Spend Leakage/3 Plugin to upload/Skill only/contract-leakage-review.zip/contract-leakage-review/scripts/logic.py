"""Contract-leakage review rules. Every figure the review reports comes from here.

Definitions (see references/business-rules.md):
  off contract (A)     every purchase with no contract reference
  off contract (B)     a purchase with no contract reference in a category a contract covers: other purchases in the category
                       quote an agreement read in this review, or one a person decided to count on the contract register
  not on file          an agreement the spend quotes that isn't among the documents. A person decides: rely on the contract
                       register (the category counts as contracted), treat the category as uncontracted until the agreement
                       is filed, or refer it on
  notice deadline      end of the period running on the review date, less the notice days in clause 4.1. The review date is
                       the day the review started, so the calendar doesn't move while it runs
  rate rise            clause 2.3: once a year, from the anniversary of the commencement date, by no more than headline CPI
                       for the second month before the month of the notice (CPI below), after written notice delivered to
                       the contracts office (clause 8.1). A rise outside those terms is valued line by line (escalations);
                       a person decides whether to claim a credit note, accept the rise or refer it on
Levers, for the analysis (see references/business-rules.md). The spend history covers period_months() months:
  credit               a claimed rise: what was charged above the terms, recovered once. The drafted rate query asks for it
  hold-rate            a claimed rise still charged on the latest invoice: above CPI, the overcharge each month
                       (overcharge_run_rate), stopped by paying the rate CPI allows; within CPI (only the notice was wrong),
                       one notice period of it, once, because a proper notice lets the rise apply after that
  notice               a notice deadline due within 60 days: the agreement's annual spend is at stake. Never a gain
  renegotiate          a notice deadline passed, so the agreement will renew automatically: its annual spend is at stake
  obtain               an agreement not on file, relied on or treated as uncontracted: the annual spend under it is at stake
  on-contract          off-contract spend in a contracted category: its spend each month x ON_CONTRACT_SAVING, an assumption
  tender               off-contract spend in a category no contract covers (definition A only): 12 months of it at stake
  annual spend         what was bought under an agreement's contract reference over the months of the spend history,
                       carried to 12 months (annual_spend)
"""
from __future__ import annotations

import calendar
import datetime as dt
import re
from collections import defaultdict
from pathlib import Path

import ooxml

# Headline CPI, annual change, by the month it measures, as published by Statistics South Africa (statistical release P0141,
# June 2025 to August 2026). Clause 2.3 allows the figure for the second month before the month of the notice.
CPI = {"2025-06": 0.030, "2025-07": 0.035, "2025-08": 0.033, "2025-09": 0.034, "2025-10": 0.036, "2025-11": 0.035,
       "2025-12": 0.036, "2026-01": 0.035, "2026-02": 0.030, "2026-03": 0.031, "2026-04": 0.040, "2026-05": 0.045,
       "2026-06": 0.050, "2026-07": 0.043, "2026-08": 0.044}
CPI_SOURCE = "Statistics South Africa, Consumer Price Index (statistical release P0141): headline CPI, annual change"
CPI_LAG = 2
VALID_NOTICE = "Contracts office"            # clause 8.1: a notice counts only when the contracts office receives it
ON_CONTRACT_SAVING = 0.05                    # the review's stated planning assumption, shown wherever it's used: buying on
                                             # contract costs 5% less than buying off it; not measured in this review
DUE_WINDOW = 60
SPEND_COLUMNS = ["PO ID", "Vendor ID", "Vendor Name", "Category", "Site", "PO Date", "Amount Excl VAT", "Contract Reference"]
LINE_COLUMNS = ["Agreement Reference", "Supplier", "Invoice ID", "Invoice Date", "Item", "Quantity", "Unit Rate", "Line Amount"]
NOTICE_COLUMNS = ["Agreement Reference", "Supplier", "Notice Date", "Effective Date", "Previous Unit Rate", "New Unit Rate", "Received By"]
UNITS = {w: i for i, w in enumerate("zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen "
                                    "sixteen seventeen eighteen nineteen".split())}
TENS = {w: 10 * i for i, w in enumerate("twenty thirty forty fifty sixty seventy eighty ninety".split(), 2)}
MONTHS = {m: i for i, m in enumerate(calendar.month_name) if m}
CASES = {"no notice": "No notice", "notice outside the terms": "Notice outside the terms", "late notice": "Late notice",
         "before the anniversary": "Before the anniversary", "above CPI": "Above CPI", "compliant": "Within the terms",
         "unchanged": "Unchanged", "fixed": "Fixed rates", "no clause": "Raised on fixed rates"}
OUTSIDE = ("no notice", "notice outside the terms", "late notice", "before the anniversary", "above CPI", "no clause")


def _load(path: Path, columns: list[str], what: str, sheet: str | None = None) -> list[dict]:
    rows = ooxml.read_xlsx(path, sheet)
    missing = [c for c in columns if rows and c not in rows[0]]
    if not rows or missing:
        raise ValueError(f"The {what} doesn't have the expected columns: " + ", ".join(missing or columns))
    return rows


def load_spend(path: Path) -> list[dict]:
    rows = _load(path, SPEND_COLUMNS, "spend history")
    for r in rows:
        r["amount"] = round(float(r["Amount Excl VAT"]), 2)
        r["ref"] = str(r["Contract Reference"] or "").strip()
    return rows


def load_lines(path: Path) -> tuple[list[dict], list[dict]]:
    return _load(path, LINE_COLUMNS, "invoice lines", "Invoice lines"), _load(path, NOTICE_COLUMNS, "rate notices", "Rate notices")


# ------------------------------------------------------------------ the independent reading of an agreement
def _find(paras: list[str], pattern: str):
    for p in paras:
        m = re.search(pattern, p)
        if m:
            return m, p
    return None, None


def number(words: str) -> int | None:
    """A number written in words, as agreements write them: "thirty six", "one hundred and twenty"."""
    total = 0
    for w in words.replace("-", " ").split():
        if w in UNITS or w in TENS:
            total += UNITS.get(w, 0) + TENS.get(w, 0)
        elif w == "hundred":
            total *= 100
        elif w != "and":
            return None
    return total or None


def read_agreement(path: Path) -> dict:
    """The rule-based reader: the independent check on Claude's reading. It also keeps clause 8.1 (where notices go), which
    the rate check relies on."""
    paras = [p for p in ooxml.read_docx_paragraphs(path) if p.strip()]
    field = lambda label: (_find(paras, rf"^{label}: (.+)$")[0] or [None, None])[1]
    out = dict(ref=field("Agreement reference"), category=field("Category"), file=path.name)
    m, p = _find(paras, r"^Commencement date: (\d{1,2}) (\w+) (\d{4})$")
    out["commencement"] = dict(value=dt.date(int(m.group(3)), MONTHS[m.group(2)], int(m.group(1))).isoformat(), clause="Heading", quote=p) if m else None
    m, p = _find(paras, r"^4\.1 This Agreement endures for ([a-z ]+?) months .*?renews automatically for successive ([a-z ]+?) month periods "
                        r"unless either party gives ([a-z ]+?) days written notice of termination")
    for i, key in enumerate(("initial_term_months", "renewal_months", "termination_notice_days"), 1):
        out[key] = dict(value=number(m.group(i)), clause="4.1", quote=p) if m else None
    m, p = _find(paras, r"^2\.3 The rates in the schedule may be adjusted .*?has given the Purchaser ([a-z ]+?) days written notice of the adjusted rates")
    out["escalation"] = dict(value=True, clause="2.3", quote=p) if m else None
    out["rate_notice_days"] = dict(value=number(m.group(1)), clause="2.3", quote=p) if m else None
    m, p = _find(paras, r"^8\.1 Any notice under this Agreement")
    out["notices"] = dict(value=VALID_NOTICE, clause="8.1", quote=p) if m else None
    m, p = _find(paras, r"^3\.1 Payment shall be made by the Purchaser within (\d+) \(")
    out["payment_days"] = dict(value=int(m.group(1)), clause="3.1", quote=p) if m else None
    return out


TERMS = [("commencement", "Commencement date"), ("initial_term_months", "Initial term"), ("renewal_months", "Renewal period"),
         ("termination_notice_days", "Termination notice"), ("escalation", "Price adjustment"), ("rate_notice_days", "Rate-change notice")]


def compare(rule: dict, claude: dict) -> dict:
    """Claude's reading against the rule-based reading, term by term."""
    terms, status = [], "confirmed"
    for key, label in TERMS:
        mine = claude.get(key) or {}
        a, b = mine.get("value"), (rule.get(key) or {}).get("value")
        if a is None and b is None:
            s = "not found"
        elif a is not None and b is not None and str(a) == str(b):
            s = "confirmed"
        else:
            s, status = "differs", "check"
        terms.append(dict(key=key, label=label, claude=a, check=b, status=s, clause=mine.get("clause"), quote=mine.get("quote")))
    return dict(ref=rule["ref"], category=rule["category"], status=status, terms=terms)


# ------------------------------------------------------------------ off contract, and the agreements not on file
def references(spend: list[dict]) -> dict[str, set]:
    """Each category's contract references: the agreements its purchases quote."""
    refs = defaultdict(set)
    for s in spend:
        if s["ref"]:
            refs[s["Category"]].add(s["ref"])
    return refs


def not_on_file(spend: list[dict], on_file: set[str]) -> list[dict]:
    """The agreements the spend quotes that aren't among the documents, by reference: the category, the purchases that quote
    each one (its entry on the contract register), their suppliers, a year of that spend, and the purchases in the category with
    no reference, which count under definition B only if a person relies on the register."""
    months, out = period_months(spend), []
    for ref in sorted({s["ref"] for s in spend if s["ref"]} - set(on_file)):
        carry = [s for s in spend if s["ref"] == ref]
        cats = sorted({s["Category"] for s in carry})
        blank = [s for s in spend if not s["ref"] and s["Category"] in cats]
        value = round(sum(s["amount"] for s in carry), 2)
        out.append(dict(ref=ref, category=" and ".join(cats), cats=cats, orders=len(carry), value=value, annual=round(value * 12 / months, 2),
                        suppliers=len({s["Vendor ID"] for s in carry}), blank_lines=len(blank), blank_value=round(sum(s["amount"] for s in blank), 2)))
    return out


def contracted(spend: list[dict], on_file: set[str], relied: set[str] = frozenset()) -> set[str]:
    """The categories a contract covers: a purchase in them quotes an agreement read in this review, or one a person decided to
    count on the contract register."""
    keep = set(on_file) | set(relied)
    return {cat for cat, refs in references(spend).items() if refs & keep}


def definitions(spend: list[dict], on_file: set[str]) -> dict:
    """Both readings of "off contract", counted side by side for the decision (nothing is reported until a person chooses).
    B counts every category whose purchases quote an agreement; `on_file` is B where only the agreements read count, so the
    difference is what the decisions on the agreements not on file move."""
    blank = [s for s in spend if not s["ref"]]
    count = lambda rows: dict(lines=len(rows), value=round(sum(s["amount"] for s in rows), 2))
    every, read = set(references(spend)), contracted(spend, on_file)
    return dict(contracted=sorted(every), A=count(blank), B=count([s for s in blank if s["Category"] in every]),
                on_file=count([s for s in blank if s["Category"] in read]))


def off_contract(spend: list[dict], choice: str, cats: set[str]) -> dict:
    """Off-contract spend under the decided definition: A counts every purchase with no reference; B those in `cats`."""
    if choice == "refer":
        return dict(definition="refer", lines=0, value=0.0, by_category=[], by_site=[], hotspots=[])
    rows = [s for s in spend if not s["ref"] and (choice == "A" or s["Category"] in cats)]
    by_cat, by_site = defaultdict(lambda: [0, 0.0]), defaultdict(lambda: [0, 0.0])
    for s in rows:
        for key, ix in ((s["Category"], by_cat), (s["Site"], by_site)):
            ix[key][0] += 1
            ix[key][1] = round(ix[key][1] + s["amount"], 2)
    cats_ = sorted(([c, n, v] for c, (n, v) in by_cat.items()), key=lambda x: -x[2])
    return dict(definition=choice, lines=len(rows), value=round(sum(s["amount"] for s in rows), 2),
                by_category=cats_, by_site=sorted(([s, n, v] for s, (n, v) in by_site.items()), key=lambda x: -x[2]), hotspots=[c[0] for c in cats_[:3]])


# ------------------------------------------------------------------ the renewal calendar
def add_months(d: dt.date, months: int) -> dt.date:
    y, m = divmod(d.month - 1 + months, 12)
    return dt.date(d.year + y, m + 1, min(d.day, calendar.monthrange(d.year + y, m + 1)[1]))


def renewals(agreements: list[dict], on: dt.date) -> list[dict]:
    out = []
    for a in agreements:
        start = dt.date.fromisoformat(a["commencement"]["value"])
        end = add_months(start, a["initial_term_months"]["value"])
        while end <= on:
            end = add_months(end, a["renewal_months"]["value"])
        deadline = end - dt.timedelta(days=a["termination_notice_days"]["value"])
        days = (deadline - on).days
        out.append(dict(ref=a["ref"], category=a["category"], period_end=end.isoformat(), notice_deadline=deadline.isoformat(), days_left=days,
                        status="passed" if days < 0 else "due within 60 days" if days <= DUE_WINDOW else "later"))
    return sorted(out, key=lambda r: r["notice_deadline"])


# ------------------------------------------------------------------ rate rises
def cpi_for(d: dt.date) -> tuple[str, float]:
    """Clause 2.3's CPI for a notice given on d: the month two months before d's month, and its published annual change.
    Outside the published months, the nearest one."""
    y, m = divmod(d.year * 12 + d.month - 1 - CPI_LAG, 12)
    key = f"{y}-{m + 1:02d}"
    key = key if key in CPI else min(CPI, key=lambda k: abs((int(k[:4]) * 12 + int(k[5:])) - (y * 12 + m + 1)))
    return key, CPI[key]


def month_name(key: str) -> str:
    """"2025-08" as people write it: August 2025."""
    return f"{calendar.month_name[int(key[5:])]} {key[:4]}"


def next_anniversary(commencement: str | None, on: dt.date) -> dt.date | None:
    """The first anniversary of the commencement date on or after a date."""
    if not commencement:
        return None
    c = dt.date.fromisoformat(commencement)
    for year in (on.year - 1, on.year, on.year + 1):
        d = add_months(c, (year - c.year) * 12)
        if d >= on:
            return d
    return None


def escalations(agreements: dict[str, dict], lines: list[dict], notices: list[dict]) -> list[dict]:
    """Every agreement with invoice lines: its rate change, the notice received, the CPI clause 2.3 allows, and, line by line,
    anything charged outside the terms. A rise with no valid notice (none, or not delivered to the contracts office), charged
    before the notice period had run or before the anniversary is outside the terms in full; after those, only the part
    above the CPI allowed is."""
    notice = {n["Agreement Reference"]: n for n in notices}
    by = defaultdict(list)
    for ln in lines:
        by[ln["Agreement Reference"]].append(ln)
    out = []
    for ref, ls in sorted(by.items()):
        ls.sort(key=lambda x: (x["Invoice Date"], x["Invoice ID"]))
        base = float(ls[0]["Unit Rate"])
        changed = [x for x in ls if float(x["Unit Rate"]) != base]
        a, n = agreements.get(ref, {}), notice.get(ref)
        esc, need = bool(a.get("escalation")), ((a.get("rate_notice_days") or {}).get("value")) or 30
        row = dict(ref=ref, supplier=ls[0]["Supplier"], base=base, checked=len(ls), value=round(sum(float(x["Line Amount"]) for x in ls), 2))
        if not changed:
            out.append(dict(row, case="unchanged" if esc else "fixed", new=base, increase=0.0, overcharge=0.0, lines=0, invoices=[]))
            continue
        first, new = changed[0]["Invoice Date"], float(changed[0]["Unit Rate"])
        valid = bool(n) and str(n.get("Received By") or "").startswith(VALID_NOTICE)
        month, cpi = cpi_for(n["Notice Date"] if n else first)
        allowed = round(base * (1 + cpi), 2)
        anniv = next_anniversary((a.get("commencement") or {}).get("value"), n["Notice Date"] if n else first - dt.timedelta(days=364))
        over, hit, why = 0.0, [], set()
        for x in changed:
            d, rate, qty = x["Invoice Date"], float(x["Unit Rate"]), int(x["Quantity"])
            reason = ("no clause" if not esc else "notice" if not valid else "timing" if d < n["Notice Date"] + dt.timedelta(days=need)
                      else "anniversary" if anniv and d < anniv else "basis" if rate > allowed else None)
            o = (rate - allowed) * qty if reason == "basis" else (rate - base) * qty if reason else 0.0
            if o > 0:
                over += o
                why.add(reason)
                hit.append([x["Invoice ID"], d.isoformat(), qty, rate, base if reason != "basis" else allowed, round(o, 2)])
        case = ("no clause" if "no clause" in why else "no notice" if not n and why else "notice outside the terms" if "notice" in why
                else "late notice" if "timing" in why else "before the anniversary" if "anniversary" in why else "above CPI" if why else "compliant")
        out.append(dict(row, case=case, new=new, increase=round(new / base - 1, 4), cpi=cpi, cpi_month=month, allowed=allowed,
                        within=new <= allowed, need=need, anniversary=anniv and anniv.isoformat(), first=first.isoformat(),
                        notice=n and n["Notice Date"].isoformat(), effective=n and n["Effective Date"].isoformat(),
                        notice_days=n and (n["Effective Date"] - n["Notice Date"]).days, received=n and n.get("Received By"),
                        overcharge=round(over, 2), lines=len(hit), invoices=hit))
    return out


def headline(off: dict, cal: list[dict], esc: list[dict], decisions: dict[str, str]) -> dict:
    """Only what's needed to fingerprint the release: the figures and the decisions that shape them."""
    return dict(definition=off["definition"], off_lines=off["lines"], off_value=off["value"], renewals={r["ref"]: r["status"] for r in cal},
                rates={e["ref"]: [e["case"], e["overcharge"]] for e in esc if e["overcharge"] > 0}, decisions=decisions)


# ------------------------------------------------------------------ for the analysis
def months_between(first: dt.date, last: dt.date) -> int:
    """Calendar months from one date to another, both counted: March 2024 to February 2025 is 12."""
    return (last.year - first.year) * 12 + last.month - first.month + 1


def period_months(spend: list[dict]) -> int:
    """How many calendar months the spend history covers, by order date."""
    dates = [s["PO Date"] for s in spend]
    return months_between(min(dates), max(dates))


def annual_spend(spend: list[dict]) -> dict[str, dict]:
    """Each agreement's spend in a year: what was bought under its contract reference, over the months the spend history
    covers, carried to 12 months. With the purchases counted."""
    months, by = period_months(spend), defaultdict(lambda: [0, 0.0])
    for s in spend:
        if s["ref"]:
            by[s["ref"]][0] += 1
            by[s["ref"]][1] += s["amount"]
    return {ref: dict(orders=n, value=round(v * 12 / months, 2)) for ref, (n, v) in by.items()}


def next_deadline(r: dict, agreement: dict) -> str:
    """For an agreement whose notice deadline passed: the deadline for the period after the one it renews into."""
    end = add_months(dt.date.fromisoformat(r["period_end"]), agreement["renewal_months"]["value"])
    return (end - dt.timedelta(days=agreement["termination_notice_days"]["value"])).isoformat()


def overcharge_run_rate(e: dict, lines: list[dict]) -> dict | None:
    """What a rise outside the terms still costs each month: the overcharge / the calendar months from its first overcharged
    invoice to its last. None once it has stopped (the agreement's latest invoice was within its terms, for example once a
    late notice's period had run). `capped` when the rise itself is within CPI and only the notice was wrong: a proper notice
    lets it apply one notice period later, so paying the old rate is worth one notice period of it, not a year."""
    hit = e.get("invoices") or []
    mine = [x for x in lines if x["Agreement Reference"] == e["ref"]]
    if not hit or not mine:
        return None
    latest = max(mine, key=lambda x: (x["Invoice Date"], x["Invoice ID"]))
    if latest["Invoice ID"] != hit[-1][0]:
        return None
    first, last = dt.date.fromisoformat(str(hit[0][1])), dt.date.fromisoformat(str(hit[-1][1]))
    months = months_between(first, last)
    monthly = round(e["overcharge"] / months, 2)
    capped = bool(e.get("within")) and e["case"] != "above CPI"
    return dict(monthly=monthly, months=months, first=first.isoformat(), last=last.isoformat(), capped=capped,
                once=round(monthly * e["need"] / 30, 2), agreed=e["base"] if capped else e["allowed"])


def category_stats(spend: list[dict], choice: str, cats: set[str]) -> dict[str, dict]:
    """Each category's off-contract spend under the decided definition: its purchases and value, the category's whole spend,
    the contract references its other purchases quote (none: no contract covers it), how much went to suppliers that also sell
    under those references in the category, and the site with the most of it."""
    if choice == "refer":
        return {}
    refs, sellers, total = defaultdict(set), defaultdict(set), defaultdict(float)
    for s in spend:
        total[s["Category"]] += s["amount"]
        if s["ref"]:
            refs[s["Category"]].add(s["ref"])
            sellers[s["Category"]].add(s["Vendor ID"])
    out = {}
    for s in spend:
        c = s["Category"]
        if s["ref"] or (choice == "B" and c not in cats):
            continue
        x = out.setdefault(c, dict(lines=0, value=0.0, total=round(total[c], 2), refs=sorted(refs.get(c, ())), panel=0.0, sites=defaultdict(float)))
        x["lines"] += 1
        x["value"] += s["amount"]
        x["panel"] += s["amount"] if s["Vendor ID"] in sellers.get(c, ()) else 0.0
        x["sites"][s["Site"]] += s["amount"]
    for x in out.values():
        site = max(x.pop("sites").items(), key=lambda kv: kv[1])
        x.update(value=round(x["value"], 2), panel=round(x["panel"], 2), site=site[0], site_value=round(site[1], 2))
    return out
