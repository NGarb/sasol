#!/usr/bin/env python3
"""The contract-leakage review. Claude runs one step at a time; each prints plain-English JSON.

  ready                         the dashboard before any files arrive (for a pre-warmed chat)
  start     [--folder …] [--copy] [--files …]   check the spend history, the invoice lines and the agreements, and open the review
  read                          print the agreements' text for Claude to read
  check     --reading FILE      compare Claude's reading with the independent rule-based reading
  gate                          what the one card will ask: what off contract means, each agreement the spend quotes that isn't
                                in the folder, and each rate rise outside its agreement's terms, each with its evidence, for the assessment
  gate      --assessment FILE   check the assessment, open a decision for each item, and give the card, set to the recommendations
  decide    --file FILE --name --role          record the whole card ({"decisions": [{"item", "option", "reason"}]})
            --item --option --reason --name --role   or one item
  findings                      off contract, the renewal calendar and the rate results under the decisions, and the brief for
                                the analysis (only once every item on the card is decided)
  analysis  --file FILE         check the analysis against the review's own figures, then ask for release
  release   --approve|--return --reason --name --role --reviewed   (a different person, in a role that may release)
  publish                       file everything in the project folder (only if approved)
  verify    [--file RECORD]     tamper check on this review's record, or on a downloaded copy
  dashboard                     rewrite the dashboard for the current stage

The review date is the day `start` runs, in South African time, and stays the same for the whole review: every notice
deadline is counted from it. JUMPSTART_REVIEW_DATE (YYYY-MM-DD) sets it instead, for the tests and the reference run.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import analysis  # noqa: E402
import logic  # noqa: E402
import ooxml  # noqa: E402
import skillkit as kit  # noqa: E402
from governance import Review, ReviewError, verify_record  # noqa: E402

WORK = kit.work_dir()
TEMPLATE = HERE.parent / "assets" / "dashboard.html"
CARD = HERE.parent / "assets" / "decision-card.html"
LABELS = {"stage-read": "Agreements read", "stage-checked": "Readings compared", analysis.EVENT: analysis.LABEL}
KIND = "contract exceptions"                   # the delegation of authority for every item on the card
DEFINE = {"A": "Every purchase with no contract reference", "B": "Only where a contract exists for the category", "refer": "Refer it on"}
REGISTER = {"register": "Rely on the contract register", "uncontracted": "Treat as uncontracted until filed", "refer": "Refer it on"}
RISE = {"claim": "Claim a credit note", "accept": "Accept the rise", "refer": "Refer it on"}
NOT_STARTED = "The review hasn't started yet. It begins by reading the spend history, the invoice lines and the agreements in the project folder."
NOT_CHECKED = "The agreements haven't been read and checked yet."
NOT_GATED = "The decisions come first: the card hasn't been given yet."
NOT_CALCULATED = "The findings haven't been calculated yet."
SAID = {"no notice": "raised its rate with no written notice", "notice outside the terms": "gave notice of its new rate to a buyer, not the contracts office",
        "late notice": "charged its new rate before the notice period had run", "before the anniversary": "charged its new rate before the anniversary",
        "above CPI": "raised its rate by more than CPI allows", "no clause": "raised a rate the agreement fixes"}
WHY = {"no notice": "no written notice of the adjusted rate was received, as clause 2.3 requires",
       "notice outside the terms": "the notice went to a buyer, not to the contracts office, so under clause 8.1 it isn't a valid notice",
       "late notice": "the adjusted rate was charged before the written notice clause 2.3 requires had run",
       "before the anniversary": "clause 2.3 allows an adjustment only from the anniversary of the commencement date",
       "above CPI": "the rise is more than the CPI change clause 2.3 allows", "no clause": "the agreement fixes its rates"}
DEFINED = {"A": "every purchase with no contract reference", "B": "a purchase with no contract reference in a category a contract covers"}


def rv() -> Review:
    return Review(WORK)


def started_on() -> str:
    """The review date, as start records it: today in South African time, or JUMPSTART_REVIEW_DATE when it's set."""
    pinned = os.environ.get("JUMPSTART_REVIEW_DATE", "").strip()
    return dt.date.fromisoformat(pinned).isoformat() if pinned else dt.datetime.now(kit.SAST).date().isoformat()


def review_date() -> dt.date:
    """The day the review started: every notice deadline is counted from it, for the whole review."""
    return dt.date.fromisoformat(rv().state["review_date"])


def saved(name: str):
    p = WORK / name
    return json.loads(p.read_text()) if p.exists() else None


def save(name: str, obj) -> None:
    (WORK / name).write_text(json.dumps(obj, indent=1, default=str))


def spend() -> list[dict]:
    return logic.load_spend(Path(rv().state["files"]["spend"]))


def agreements() -> dict[str, dict]:
    return {a["ref"]: a for a in saved("rule-reading.json")}


def decided() -> dict[str, str]:
    """Each card item's chosen option, by its key."""
    return {k: d["option"] for k, d in (rv().state.get("decisions") or {}).items()}


# ------------------------------------------------------------------ dashboard data
def ready_run() -> dict:
    return dict(title="Contract & Spend Leakage", tagline="Purchases, renewals and rates against the agreements", id="New review",
                stages=kit.STAGES, stage=0, awaiting=False, ready=True, focus="overview")


def build_run() -> dict:
    r = rv()
    st = r.state
    stage = {"received": 0, "read": 1, "checked": 1, "awaiting-decision": 2, "decided": 2, "calculated": 3, "awaiting-release": 4,
             "returned": 4, "released": 4, "published": 5}.get(st["stage"], 0)
    run = dict(title="Contract & Spend Leakage", tagline="Purchases, renewals and rates against the agreements", id=st["review_id"],
               stages=kit.STAGES, stage=stage, awaiting=st["stage"] in ("awaiting-decision", "awaiting-release"), data=st["summary"],
               review_date=st["review_date"], focus="decisions" if st["stage"] == "awaiting-decision" else "overview",
               inputs=kit.inputs_view(r, about=about_inputs(), rows=st.get("rows")))
    comp = {c["ref"]: c for c in saved("comparison.json") or []}
    qt = []

    def qi(term):
        if not term:
            return None
        if term["quote"] not in qt:
            qt.append(term["quote"])                  # whole clauses, each stored once
        return qt.index(term["quote"])
    if comp:                                                              # the agreements, once read and checked
        run["contracts"] = []
        for ref, a in agreements().items():
            v = lambda k: (a.get(k) or {}).get("value")
            run["contracts"].append({k: x for k, x in dict(ref=ref, cat=a["category"], st=comp.get(ref, {}).get("status", "received"), start=v("commencement"),
                                                             term=v("initial_term_months"), ren=v("renewal_months"), notice=v("termination_notice_days"),
                                                             esc=bool(a.get("escalation")), rn=v("rate_notice_days"),
                                                             q=[qi(a.get("termination_notice_days")), qi(a.get("escalation")), qi(a.get("notices"))]).items() if x is not None})
        run["qt"] = qt
    g, f, dec = saved("gate.json"), saved("findings.json"), st.get("decisions") or {}
    if g:                                                                 # the card: what each item's options count
        run["defs"] = g["defs"]
        run["miss"] = g["missing"]
        run["items"] = [[i["key"], i["title"], i["sub"], i["options"], i.get("rec") and [i["rec"]["option"], i["rec"]["confidence"], i["rec"]["reason"]]] for i in g["items"]]
        run["dec"] = {k: [d["option"], d["label"], d["reason"], d.get("name"), d.get("role"), kit.hhmm(d["at"]), d["shown"][:8]] for k, d in dec.items()}
        run["esc"] = [esc_view(e) for e in g["esc"]]
        run["rates"] = g["rates"]
    if f:
        run["off"] = f["off"]
        run["cats"] = f["cats"]
        run["cal"] = [[x["ref"], x["category"], x["period_end"], x["notice_deadline"], x["days_left"], x["status"]] for x in f["cal"]]
        run["actions"] = f["actions"]
    acc = saved("analysis.json")
    if acc:                                                               # the analysis, once the review has checked it
        run["an"] = analysis.run_view(acc, saved("analysis-brief.json"), review_date())
        run["split"] = split(acc, saved("analysis-brief.json"))
    run["release"] = kit.release_view(st.get("release"))
    run["record"] = kit.record_view(r, LABELS)
    run["downloads"] = st.get("downloads", [])
    run["filed"] = st.get("filed")
    return {k: v for k, v in run.items() if v is not None}


def esc_view(e: dict) -> dict:
    """One agreement's rate check as the dashboard needs it (the decision on it is in the decisions)."""
    keep = ("ref", "supplier", "case", "base", "new", "increase", "cpi", "cpi_month", "allowed", "within", "need", "anniversary", "first", "notice",
            "effective", "notice_days", "received", "overcharge", "lines", "checked", "value")
    return {**{k: e[k] for k in keep if e.get(k) is not None}, **({"cm": logic.month_name(e["cpi_month"])} if e.get("cpi_month") else {})}


def about_inputs() -> dict:
    """What each file the review read is, for the Data page and the audit trail."""
    st = rv().state
    files = st.get("files") or {}
    out = {Path(files["spend"]).name: "Spend history: every purchase order, with its contract reference",
           Path(files["lines"]).name: "Invoice lines under the panel agreements, and the rate notices received"} if files else {}
    for a in saved("rule-reading.json") or []:
        out[a["file"]] = f"Panel agreement {a['ref']}, {a['category']}"
    return out


def write_dashboard() -> dict:
    return kit.fill_dashboard(TEMPLATE, build_run(), WORK / "dashboard.html")


# ------------------------------------------------------------------ steps
def cmd_ready(a):
    WORK.mkdir(parents=True, exist_ok=True)
    kit.emit(dict(ok=True, **kit.fill_dashboard(TEMPLATE, ready_run(), WORK / "dashboard.html")))


def cmd_start(a):
    folder = kit.check_folder(a.folder)
    docs = kit.find_files(a.files, (".docx",), folder)
    books = kit.find_files(a.files, (".xlsx",), folder)
    sp_f = [b for b in books if "spend" in b.name.lower()]
    ln_f = [b for b in books if "invoice" in b.name.lower() or "line" in b.name.lower()]
    if not docs or not sp_f or not ln_f:
        kit.fail(f"The project folder needs the agreements (Word) in {kit.DOCUMENTS} and the spend history and invoice lines (Excel) in {kit.DATA}."
                 if folder else "I need the spend history and the invoice lines (Excel) and the agreements (Word). Please add all three.")
    try:
        sp, (lines, notices) = logic.load_spend(sp_f[0]), logic.load_lines(ln_f[0])
    except ValueError as e:
        kit.fail(str(e))
    r = rv()
    try:
        r.start("contract-leakage", kit.review_id("CL"), docs + [sp_f[0], ln_f[0]], version=kit.plugin_version())
    except ReviewError as e:
        kit.fail(str(e))
    dates = [s["PO Date"] for s in sp]
    sites = sorted({s["Site"] for s in sp}, key=lambda x: -sum(s["amount"] for s in sp if s["Site"] == x))
    summary = dict(lines=len(sp), value=round(sum(s["amount"] for s in sp), 2), period=f"{min(dates):%b %Y} to {max(dates):%b %Y}",
                   first=min(dates).isoformat(), last=max(dates).isoformat(), sites=sites, agreements=len(docs), invoice_lines=len(lines),
                   notices=len(notices), with_ref=sum(bool(s["ref"]) for s in sp), checked=round(sum(float(x["Line Amount"]) for x in lines), 2),
                   bySite=[[site, round(sum(s["amount"] for s in sp if s["Site"] == site), 2)] for site in sites])
    st = r.put(files={"agreements": [str(d) for d in docs], "spend": str(sp_f[0]), "lines": str(ln_f[0])}, folder=folder, folder_copy=bool(folder and a.copy),
               summary=summary, rows={sp_f[0].name: len(sp), ln_f[0].name: len(lines) + len(notices)}, review_date=started_on())
    save("rule-reading.json", [logic.read_agreement(d) for d in docs])       # the independent reading, kept aside
    kit.emit(dict(ok=True, review=st["review_id"], source="the project folder" if folder else "the files shared in the chat",
                  orders=summary["lines"], spend=summary["value"], agreements=summary["agreements"], invoice_lines=summary["invoice_lines"],
                  period=summary["period"], **write_dashboard()))


def cmd_read(a):
    kit.needs(WORK, "review-state.json", message=NOT_STARTED)
    r = rv()
    out = [{"file": Path(d).name, "text": "\n".join(p for p in ooxml.read_docx_paragraphs(d) if p.strip())} for d in r.state["files"]["agreements"]]
    if r.state["stage"] in ("received", "read"):
        r.set_stage("read", {"agreements": len(out)}, about=out)              # the record fingerprints the texts read
    kit.emit(dict(ok=True, instruction="Read each agreement and record the terms as described in references/extraction-guide.md.", agreements=out))


def cmd_check(a):
    kit.needs(WORK, "review-state.json", "rule-reading.json", message=NOT_STARTED)
    if saved("gate.json"):
        kit.fail("The agreements have already been read and checked, and the decisions are on the card.")
    try:
        data = json.loads(Path(a.reading).read_text())
        reading = data["agreements"] if isinstance(data, dict) else data         # the review keeps its own copy as a plain list
        by = {x["ref"]: x for x in reading}
    except (OSError, KeyError, TypeError, ValueError):
        kit.fail('Fix and run again: the reading must be a JSON file with an "agreements" list, one entry per agreement, each with its "ref".')
    rule = agreements()
    missing = sorted(set(rule) - set(by))
    if missing:
        kit.fail("Fix and run again: these agreements haven't been read yet: " + ", ".join(missing) + ".")
    comp = []
    for ref in sorted(rule):
        try:
            comp.append(logic.compare(rule[ref], by[ref]))
        except (KeyError, TypeError, ValueError, AttributeError):
            kit.fail(f'Fix and run again: the reading of {ref} doesn\'t follow the extraction guide. Record each term as {{"value", "clause", "quote"}}, or null.')
    save("claude-reading.json", reading)
    save("comparison.json", comp)
    ok = sum(c["status"] == "confirmed" for c in comp)
    rv().set_stage("checked", {"agreements": len(comp), "confirmed": ok}, about=dict(reading=reading, comparison=comp))
    kit.emit(dict(ok=True, agreements=len(comp), confirmed=ok,
                  differences=[dict(ref=c["ref"], term=t["label"], you_read=t["claude"], independent_check=t["check"]) for c in comp for t in c["terms"] if t["status"] == "differs"],
                  **write_dashboard()))


def gate_items(d: dict, miss: list[dict], rises: list[dict]) -> list[dict]:
    """The card: one item per decision, each with its question, options, a one-line summary of the evidence (sub) and the
    sentence the card sends for each option."""
    R, day = kit.rand_spoken, lambda iso: short_day(iso)
    pending = round(d["B"]["value"] - d["on_file"]["value"], 2)
    items = [dict(key="definition", title='What should "off contract" mean?', options=DEFINE,
                  question='What should "off contract" mean?',
                  sub=f"A counts {d['A']['lines']:,} purchases, {R(d['A']['value'])} · B counts {d['B']['lines']:,}, {R(d['B']['value'])}"
                      + (f", {R(pending)} of it in the categories below" if miss and pending else ""),
                  sentence={"A": 'Off contract: definition A, every purchase with no contract reference.',
                            "B": 'Off contract: definition B, only purchases in categories where a contract exists.',
                            "refer": 'Off contract: refer the definition to the category owner.'})]
    for m in miss:
        items.append(dict(key=f"missing:{m['ref']}", title=f"{m['ref']} · {m['category']}: quoted by purchases, but the agreement isn't in the folder",
                          question=f"{m['ref']} ({m['category']}) isn't in the folder: rely on the contract register?", options=REGISTER,
                          sub=f"{m['orders']:,} purchases quote it, {R(m['value'])} · {plural(m['blank_lines'], 'purchase')} with no reference, {R(m['blank_value'])}, "
                              f"counted under B only if it's relied on",
                          sentence={"register": f"{m['ref']} ({m['category']}): rely on the contract register and count the category as contracted.",
                                    "uncontracted": f"{m['ref']} ({m['category']}): treat the category as uncontracted until the agreement is filed.",
                                    "refer": f"{m['ref']} ({m['category']}): refer it on."}))
    for e in rises:
        what = (f"CPI allowed {e['cpi']:.1%}" if e["case"] == "above CPI" else "no notice received" if e["case"] == "no notice" else
                f"notice sent to a buyer on {day(e['notice'])}" if e["case"] == "notice outside the terms" else
                f"{e['notice_days']} days' notice, {e['need']} required" if e["case"] == "late notice" else
                f"anniversary {day(e['anniversary'])}" if e["case"] == "before the anniversary" else "fixed rates")
        items.append(dict(key=f"rate:{e['ref']}", title=f"{e['ref']} · {e['supplier']}: {low(logic.CASES[e['case']])}",
                          question=f"{e['ref']}: {poss(e['supplier'])} rate rise, {low(logic.CASES[e['case']])}: claim, accept or refer?", options=RISE,
                          sub=f"Rate up {e['increase']:.1%} from {day(e['first'])} · {what} · {e['lines']} lines · {R(e['overcharge'])} over",
                          sentence={"claim": f"{e['ref']} rate rise ({e['supplier']}): claim a credit note.",
                                    "accept": f"{e['ref']} rate rise ({e['supplier']}): accept the rise.",
                                    "refer": f"{e['ref']} rate rise ({e['supplier']}): refer it on."}))
    return items


CARD_LABEL = {"A": "A · every purchase with no reference", "B": "B · only where a contract exists"}
low = lambda s: s[:1].lower() + s[1:]


def short_day(iso: str) -> str:
    d = dt.date.fromisoformat(str(iso)[:10])
    return f"{d.day} {d:%b %Y}"


def history(esc: list[dict], lines: list[dict], ags: dict) -> dict:
    """Each changed rate, invoice by invoice: [date, rate charged, rate the agreement allows]. The agreement allows the old rate
    until a valid notice has run and the anniversary has come, then up to the CPI rate."""
    out = {}
    for e in esc:
        if e["case"] in ("unchanged", "fixed"):
            continue
        valid = e.get("received") and str(e["received"]).startswith(logic.VALID_NOTICE)
        start = max(dt.date.fromisoformat(e["notice"]) + dt.timedelta(days=e["need"]), dt.date.fromisoformat(e["anniversary"] or e["notice"])) if valid else None
        rows = sorted((x for x in lines if x["Agreement Reference"] == e["ref"]), key=lambda x: (x["Invoice Date"], x["Invoice ID"]))
        out[e["ref"]] = [[x["Invoice Date"].isoformat(), float(x["Unit Rate"]), e["allowed"] if start and x["Invoice Date"] >= start else e["base"]] for x in rows]
    return out


def assess_view(it: dict, facts: dict) -> dict:
    """One item as it's assessed: the question, the options, the evidence in one line and the facts behind it."""
    return dict(item=it["key"], question=it["question"], options=it["options"], evidence=it["sub"], facts=facts)


def give_card(g: dict) -> None:
    """The card, set to the recommendation for each item, and the figures Claude says around it."""
    n, items = len(g["items"]), g["items"]
    rises = sorted((e for e in g["esc"] if e["overcharge"] > 0), key=lambda e: -e["overcharge"])
    kit.decision_card(CARD, WORK / "decision-card.html", kicker=f"Your decisions · {n} item{'s' * (n != 1)}",
                      title=f"{kit_words(n).capitalize()} item{'s need' if n != 1 else ' needs'} your decision" if n > 1 else items[0]["title"],
                      lead="", items=[dict(title=it["title"], sub=it["sub"], options=[[k, CARD_LABEL.get(k, v) if it["key"] == "definition" else v] for k, v in it["options"].items()],
                                           sentence=it["sentence"], rec=it.get("rec")) for it in items],
                      roles=g["roles"])
    d = g["defs"]
    kit.emit(dict(ok=True, decision_needed=True, items=card_items(g), roles=g["roles"],
                  definition_A=d["A"], definition_B=d["B"], definition_B_on_file=d["F"], ratio=round(d["A"]["lines"] / max(1, d["B"]["lines"]), 1),
                  contracted_categories=d["cats"], not_on_file=[dict(ref=m["ref"], category=m["category"], orders=m["orders"], value=m["value"]) for m in g["missing"]],
                  rate_rises=[dict(ref=e["ref"], supplier=e["supplier"], what=SAID[e["case"]], rise=f"{e['increase']:.1%}", cpi_allowed=cpi_said(e), overcharge=e["overcharge"]) for e in rises],
                  decision_card=str(WORK / "decision-card.html"), **write_dashboard()))


def cmd_gate(a):
    kit.needs(WORK, "review-state.json", message=NOT_STARTED)
    kit.needs(WORK, "comparison.json", message=NOT_CHECKED)
    r = rv()
    g = saved("gate.json")
    if g:                                                                 # the card is already open: give it again
        if not r.state["open"]:
            kit.fail("The decisions on the card have already been recorded.")
        give_card(g)
        return
    sp, ags = spend(), agreements()
    lines, notices = logic.load_lines(Path(r.state["files"]["lines"]))
    d, miss = logic.definitions(sp, set(ags)), logic.not_on_file(sp, set(ags))
    esc = logic.escalations(ags, lines, notices)
    rises = sorted((e for e in esc if e["overcharge"] > 0), key=lambda e: -e["overcharge"])
    items = gate_items(d, miss, rises)
    roles = kit.roles()["decide"][KIND]
    shown = {"definition": dict(A=d["A"], B=d["B"], on_file=d["on_file"], contracted=d["contracted"]),
             **{f"missing:{m['ref']}": m for m in miss}, **{f"rate:{e['ref']}": {k: v for k, v in e.items() if k != "invoices"} for e in rises}}
    if not a.assessment:                                                  # first the assessment, then the card
        facts = {"definition": dict(A=d["A"], B=d["B"], contracted_categories=len(d["contracted"])),
                 **{f"missing:{m['ref']}": {k: m[k] for k in ("category", "orders", "value", "suppliers", "blank_lines", "blank_value")} for m in miss},
                 **{f"rate:{e['ref']}": dict(supplier=e["supplier"], what=SAID[e["case"]], rise=f"{e['increase']:.1%}", cpi_allowed=cpi_said(e),
                                             lines=e["lines"], overcharge=e["overcharge"]) for e in rises}}
        kit.emit(dict(ok=True, decision_needed=True, assess=True, roles=roles,
                      instruction="Assess each item as references/assessment-guide.md describes, in assessment.json in the working folder, "
                                  "then run gate --assessment assessment.json.",
                      items=[assess_view(it, facts[it["key"]]) for it in items]))
        return
    alias = {**{it["key"].split(":", 1)[-1]: it["key"] for it in items}, **{it["key"]: it["key"] for it in items}}
    rec = kit.read_assessment(a.assessment, {it["key"]: it["options"] for it in items}, lambda t: alias.get(t.strip()))
    try:
        for it in items:
            it["rec"] = rec[it["key"]]
            r.open_decision(it["key"], it["question"], it["options"], shown[it["key"]], roles, recommended=it["rec"])
    except ReviewError as e:
        kit.fail(str(e))
    g = dict(items=[{k: it[k] for k in ("key", "title", "question", "sub", "options", "sentence", "rec")} for it in items], roles=roles,
             defs=dict(A=d["A"], B=d["B"], F=d["on_file"], cats=len(d["contracted"])),
             missing=[{k: m[k] for k in ("ref", "category", "orders", "value", "annual", "suppliers", "blank_lines", "blank_value")} for m in miss],
             esc=esc, rates=history(esc, lines, ags))
    save("gate.json", g)
    give_card(g)


def cpi_said(e: dict) -> str:
    """The CPI clause 2.3 allowed a rise, as said: "3.3%, for August 2025"."""
    return f"{e['cpi']:.1%}, for {logic.month_name(e['cpi_month'])}" if e.get("cpi_month") else "none: the rates are fixed"


def kit_words(n: int) -> str:
    return "zero one two three four five six seven eight nine ten eleven twelve".split()[n] if n <= 12 else str(n)


def card_items(g: dict) -> list[dict]:
    """The card's items as Claude records them: the item, the question, the options, the evidence and the recommendation."""
    return [dict(item=i["key"], question=i["question"], options=i["options"], evidence=i["sub"],
                 **({"recommended": i["options"][i["rec"]["option"]], "confidence": i["rec"]["confidence"]} if i.get("rec") else {})) for i in g["items"]]


def cmd_decide(a):
    g = saved("gate.json")
    if not g:
        kit.fail("There's no decision waiting right now.")
    r = rv()
    keys = {i["key"]: i for i in g["items"]}
    alias = {**{k.split(":", 1)[-1]: k for k in keys}, **{k: k for k in keys}}          # "AGR-0001" is missing:AGR-0001
    if a.file:
        rows = kit.read_decisions(a.file)
    elif a.item:
        rows = [(a.item, a.option or "", a.reason or "")]
    else:
        kit.fail("Fix and run again: record the card with --file, or one item with --item, --option and --reason.")
    items = []
    for item, option, reason in rows:
        key = alias.get(item.strip())
        if not key:
            kit.fail(f"Fix and run again: \"{item}\" isn't on the card. Its items are: {', '.join(keys)}.")
        if option not in keys[key]["options"]:
            kit.fail(f"Fix and run again: the options for {key} are {', '.join(keys[key]['options'])}.")
        items.append((key, option, reason))
    left = [k for k in r.state["open"] if k not in {k2 for k2, _, _ in items}]
    if a.file and left:
        kit.fail("Every item on the card needs a choice and a reason before any is recorded. Still to decide: "
                 + "; ".join(keys[k]["title"] for k in left) + ".")
    try:
        done = r.decide_many(items, a.name, a.role)
    except ReviewError as e:
        kit.fail(str(e))
    kit.emit(dict(ok=True, recorded=[dict(item=x["key"], decision=x["label"], reason=x["reason"]) for x in done], name=done[0]["name"], role=done[0]["role"],
                  at=kit.hhmm(done[0]["at"]), still_open=[keys[k]["title"] for k in r.state["open"]], **write_dashboard()))


def cmd_findings(a):
    kit.needs(WORK, "review-state.json", message=NOT_STARTED)
    kit.needs(WORK, "comparison.json", message=NOT_CHECKED)
    kit.needs(WORK, "gate.json", message=NOT_GATED)
    r = rv()
    if r.state["open"] or not r.state["decisions"]:                        # nothing is counted before every decision
        kit.fail("This step needs every decision on the card first. Nothing has been calculated.")
    if r.state.get("release"):
        kit.fail("The findings have already been calculated and sent for release.")
    g, dec = saved("gate.json"), decided()
    lines, _ = logic.load_lines(Path(r.state["files"]["lines"]))
    sp, ags = spend(), agreements()
    relied = {m["ref"] for m in g["missing"] if dec.get(f"missing:{m['ref']}") == "register"}
    cats = logic.contracted(sp, set(ags), relied)
    off = logic.off_contract(sp, dec["definition"], cats)
    cal = logic.renewals(list(ags.values()), review_date())
    esc = [dict(e, decision=dec.get(f"rate:{e['ref']}"), still=bool(e["overcharge"] and logic.overcharge_run_rate(e, lines))) for e in g["esc"]]
    missing = [dict(m, decision=dec.get(f"missing:{m['ref']}")) for m in g["missing"]]
    f = dict(off=off, cats=sorted(cats), cal=cal, esc=esc, missing=missing, actions=actions(off, cal, esc, missing))
    save("findings.json", f)
    r.set_stage("calculated", figures(f), about=f)
    b = analysis_brief(f, lines)
    save("analysis-brief.json", b)
    rises = sorted((e for e in esc if e["overcharge"] > 0), key=lambda e: -e["overcharge"])
    kit.emit(dict(ok=True, off_contract=dict(definition=off["definition"], lines=off["lines"], value=off["value"], top_categories=off["hotspots"]),
                  not_on_file=[dict(ref=m["ref"], category=m["category"], decision=REGISTER[m["decision"]]) for m in missing],
                  notice_passed=[x["ref"] for x in cal if x["status"] == "passed"], due_within_60_days=[[x["ref"], x["notice_deadline"]] for x in cal if x["status"] == "due within 60 days"],
                  rate_rises=[dict(ref=e["ref"], supplier=e["supplier"], what=SAID[e["case"]], rise=f"{e['increase']:.1%}", cpi_allowed=cpi_said(e), overcharge=e["overcharge"],
                                   decision=RISE[e["decision"]]) for e in rises],
                  claimed_total=round(sum(e["overcharge"] for e in rises if e["decision"] == "claim"), 2),
                  overcharge_total=round(sum(e["overcharge"] for e in rises), 2), drafts=len(f["actions"]), analysis=analysis.for_claude(b)))


def figures(f: dict) -> dict:
    """The findings' figures, for the record and the release's fingerprint."""
    return logic.headline(f["off"], f["cal"], f["esc"], decided())


def actions(off: dict, cal: list[dict], esc: list[dict], missing: list[dict]) -> list[list]:
    """The drafts a person approves and sends: notice letters, rate queries for the rises claimed, and a referral note with the
    off-contract hotspots, the agreements to obtain and anything referred on. Nothing is sent."""
    day = short_day
    out = [["notice", r["ref"], f"Notice of non-renewal · {r['ref']}", f"Send by {day(r['notice_deadline'])}"] for r in cal if r["status"] == "due within 60 days"]
    out += [["rate", e["ref"], f"Rate query · {e['ref']} · {e['supplier']}", f"R{e['overcharge']:,.2f} to recover"]
            for e in sorted(esc, key=lambda e: -e["overcharge"]) if e["overcharge"] > 0 and e["decision"] == "claim"]
    out += [["request", m["ref"], f"Request for the agreement · {m['ref']}", f"{m['category']} · quoted by {m['orders']:,} purchases"] for m in missing if m["decision"] != "refer"]
    refer = [e["ref"] for e in esc if e.get("decision") == "refer"] + [m["ref"] for m in missing if m["decision"] == "refer"]
    if (off["definition"] != "refer" and off["lines"]) or refer or off["definition"] == "refer":
        what = ([f"Hotspots: {', '.join(off['hotspots'])}"] if off["definition"] != "refer" and off["lines"] else []) + ([f"Referred: {', '.join(refer)}"] if refer else []) \
            + (["The definition of off contract"] if off["definition"] == "refer" else [])
        out.append(["referral", "", "Referral note", " · ".join(what)])
    return out


# ------------------------------------------------------------------ the brief for the analysis
def share(part: float, whole: float) -> str:
    """A share as a whole percentage, or to one decimal where whole numbers would say "all" or "none" and it isn't."""
    x = part / whole if whole else 0.0
    return f"{x:.1%}" if 0 < part < whole and round(x * 100) in (0, 100) else f"{x:.0%}"


def plural(n: int, noun: str) -> str:
    return f"{n:,} {noun}{'s' * (n != 1)}"


def poss(name: str) -> str:
    """A name's possessive: Example Metrology's, Example Pumping Solutions'."""
    return name + ("'" if name.endswith("s") else "'s")


def by_whom(key: str) -> str:
    d = (rv().state.get("decisions") or {}).get(key) or {}
    return kit.by(d)


def analysis_brief(f: dict, lines: list[dict]) -> dict:
    """What Claude reads to write the analysis. One item per agreement or category, so each appears once: an agreement read in
    this review (its renewal, its rate rise and its category's off-contract spend), an agreement not on file, or, under
    definition A, a category no contract covers. Every figure comes from the rules; an item is listed when it has a lever."""
    R, day, pct, S = kit.rand, kit.day, share, logic.ON_CONTRACT_SAVING
    sp, ags = spend(), agreements()
    off, cal, esc = f["off"], {x["ref"]: x for x in f["cal"]}, {e["ref"]: e for e in f["esc"]}
    months, annual = logic.period_months(sp), logic.annual_spend(sp)
    cats = logic.category_stats(sp, off["definition"], set(f["cats"]))
    missing = {m["ref"]: m for m in f["missing"]}
    refs = logic.references(sp)

    def on_contract(key: str, cat: str, extra: str = "", depends: str = "") -> tuple[list[str], dict | None]:
        """The category's off-contract facts, and the lever that values moving it on contract at the assumed saving."""
        x = cats.get(cat)
        if not x:
            return [], None
        facts = [f"Bought off contract in {cat}: {R(x['value'])} across {plural(x['lines'], 'purchase')}, {pct(x['value'], off['value'])} of all off-contract "
                 f"spend and {pct(x['value'], x['total'])} of the {R(x['total'])} spent in the category",
                 (f"{R(x['panel'])} of it, {pct(x['panel'], x['value'])}, went to the category's own panel suppliers, ordered without the agreement's reference; "
                  f"the rest went to suppliers outside the panel" if x["panel"] else "All of it went to suppliers outside the category's panel"),
                 f"Most of it at {x['site']}: {R(x['site_value'])}, {pct(x['site_value'], x['value'])}"]
        monthly = round(x["value"] / months * S, 2)                     # to the cent, so 12 months is exactly 10.5 times what's shown
        lever = analysis.lever(key, "on-contract", "Buy on the agreement, not off it, at an assumed 5% saving", "recurring", monthly,
                               f"{R(x['value'])} bought off contract over {months} months, {R(x['value'] / months)} a month; valued at an assumed "
                               f"{S:.0%} saving, the review's planning assumption that buying on contract costs {S:.0%} less than buying off it, "
                               f"which this review doesn't measure: {R(monthly)} a month{extra}{depends}")
        return facts, lever

    items = []
    for ref in sorted(ags):
        a, c, e = ags[ref], cal[ref], esc.get(ref)
        v = lambda k: (a.get(k) or {}).get("value")
        ren, cat, spent = v("renewal_months"), a["category"], annual.get(ref, dict(orders=0, value=0.0))
        facts = [f"The {cat} panel agreement, {ref}, from {day(v('commencement'))}: {v('initial_term_months')} months, then it renews automatically for "
                 f"{ren} months at a time unless {v('termination_notice_days')} days' written notice is given (clause 4.1)",
                 f"Annual spend under the agreement: {R(spent['value'])}, from {spent['orders']} purchases in the {months} months of the spend history"]
        levers, depends = [], ""
        if c["status"] == "passed":
            nxt = logic.next_deadline(c, a)
            facts.append(f"Notice deadline {day(c['notice_deadline'])}: it passed {-c['days_left']} days before the review date, so the agreement will renew "
                         f"automatically when its period ends on {day(c['period_end'])}, for another {ren} months. The next notice deadline is {day(nxt)}")
            levers.append(analysis.lever(ref, "renegotiate", "Renegotiate the terms before the renewal", "risk", spent["value"],
                                         f"The notice deadline, {day(c['notice_deadline'])}, has passed, so the agreement will renew on {day(c['period_end'])} for "
                                         f"another {ren} months with {R(spent['value'])} a year of spend under it; the next chance to give notice ends on {day(nxt)}",
                                         note=None if spent["value"] else "Resets the terms"))
        elif c["status"] == "due within 60 days":
            facts.append(f"Notice deadline {day(c['notice_deadline'])}, {c['days_left']} days after the review date: unless notice is given by then, the agreement "
                         f"renews automatically when its period ends on {day(c['period_end'])}, for another {ren} months. A notice of non-renewal is drafted")
            levers.append(analysis.lever(ref, "notice", f"Renegotiate or give notice by {day(c['notice_deadline'])}", "risk", spent["value"],
                                         f"Unless notice is given by {day(c['notice_deadline'])}, the agreement renews on {day(c['period_end'])} for another {ren} months "
                                         f"with {R(spent['value'])} a year of spend under it on the current terms; renegotiate or give notice by the deadline",
                                         note=None if spent["value"] else "Stops a renewal"))
            depends = f"; this assumes the category stays on an agreement: {ref}'s renewal is still to be decided, with notice due by {day(c['notice_deadline'])}"
        else:
            facts.append(f"Notice deadline {day(c['notice_deadline'])}, {c['days_left']} days after the review date")
        if e and e["case"] in ("unchanged", "fixed"):
            facts.append(f"Rates: {poss(e['supplier'])} unit rate stayed at {R(e['base'])} on all {e['checked']} invoice lines" + (", as its fixed rates require" if e["case"] == "fixed" else ""))
        elif e and e["case"] == "compliant":
            facts.append(f"Rates: {e['supplier']} raised its unit rate from {R(e['base'])} to {R(e['new'])} ({e['increase']:.1%}) from {day(e['first'])}, after "
                         f"{e['notice_days']} days' notice, within the {e['cpi']:.1%} CPI clause 2.3 allows ({logic.month_name(e['cpi_month'])}): within the agreement")
        elif e:
            first, last = e["invoices"][0][1], e["invoices"][-1][1]
            on = f"{e['lines']} invoice line{'s' * (e['lines'] != 1)}, " + (f"from {day(first)} to {day(last)}" if first != last else f"on {day(first)}")
            notice = ("no written notice of the new rate was received" if not e.get("notice") else
                      f"its notice, dated {day(e['notice'])}, wasn't delivered to the contracts office, as clause 8.1 requires (received: {e['received']})" if e["case"] == "notice outside the terms" else
                      f"notice was received on {day(e['notice'])}, giving {day(e['effective'])} as the effective date ({e['notice_days']} days)")
            facts.append(f"Rate rise: {e['supplier']} raised its unit rate from {R(e['base'])} to {R(e['new'])} ({e['increase']:.1%}), first invoiced on "
                         f"{day(e['first'])}; {notice}. Clause 2.3 allows a rise from the anniversary, {day(e['anniversary'])}, of up to {e['cpi']:.1%}, the CPI for "
                         f"{logic.month_name(e['cpi_month'])}: up to {R(e['allowed'])}, after {e['need']} days' written notice")
            facts.append(f"Outside the terms: {WHY[e['case']]}. {R(e['overcharge'])} charged above the terms on {on}")
            d = e["decision"]
            facts.append({"claim": f"Decided by {by_whom('rate:' + ref)}: claim a credit note. A rate query asking for {R(e['overcharge'])} is drafted",
                          "accept": f"Decided by {by_whom('rate:' + ref)}: accept the rise, so the {R(e['overcharge'])} isn't claimed",
                          "refer": f"Decided by {by_whom('rate:' + ref)}: refer it on, so it's listed for a decision elsewhere and not valued here"}[d])
            if d == "claim":
                levers.append(analysis.lever(ref, "credit", "Claim a credit note for the amount charged above the terms", "one-off", e["overcharge"],
                                             f"{R(e['overcharge'])} charged above the terms on {on}: {WHY[e['case']]}; the drafted rate query asks "
                                             f"{e['supplier']} for a credit note for it"))
                rr = logic.overcharge_run_rate(e, lines)
                if rr and rr["capped"]:
                    facts.append(f"Still charged: the latest invoice, on {day(rr['last'])}, was at the new rate. The rise is within CPI, so once proper notice is "
                                 f"given it can apply {e['need']} days later: holding the old rate is worth one notice period, {R(rr['once'])}, not a year")
                    levers.append(analysis.lever(ref, "hold-rate", "Pay the old rate until a proper notice has run", "one-off", rr["once"],
                                                 f"{R(e['overcharge'])} over {rr['months']} months is {R(rr['monthly'])} a month; the rise is within CPI, so once written "
                                                 f"notice is delivered to the contracts office it can apply {e['need']} days later, and paying {R(rr['agreed'])} a unit "
                                                 f"until then is worth one notice period, {R(rr['once'])}"))
                elif rr:
                    facts.append(f"Still charged: the latest invoice, on {day(rr['last'])}, was {R(e['new'])} a unit against the {R(rr['agreed'])} allowed")
                    levers.append(analysis.lever(ref, "hold-rate", "Pay only the rate the agreement allows", "recurring", rr["monthly"],
                                                 f"{R(e['overcharge'])} charged above CPI over {rr['months']} months, {R(rr['monthly'])} a month, and still charged at "
                                                 f"{R(e['new'])} a unit; paying the rate CPI allows, {R(rr['agreed'])} a unit, from now on stops it"))
                else:
                    facts.append("The overcharge has stopped: the invoices since then are within the agreement")
        oc_facts, lever = on_contract(ref, a["category"], depends=depends)
        facts += oc_facts
        levers += [lever] if lever else []
        if levers:
            items.append(dict(ref=ref, name=f"{cat} ({ref})", facts=facts, levers=levers))
    for ref, m in missing.items():                                       # the agreements the spend quotes that aren't on file
        d, who = m["decision"], by_whom(f"missing:{ref}")
        facts = [f"{ref}, the {m['category']} panel agreement, isn't in the project folder, but {m['orders']:,} purchases from {m['suppliers']} suppliers quote it: "
                 f"{R(m['value'])} over {months} months" + (f", {R(m['annual'])} a year" if months != 12 else "") + ". Its term, renewal date and rates haven't been checked",
                 {"register": f"Decided by {who}: rely on the contract register, so the category counts as contracted until the agreement is filed",
                  "uncontracted": f"Decided by {who}: treat the category as uncontracted until the agreement is filed, so its {plural(m['blank_lines'], 'purchase')} with no "
                                  f"reference, {R(m['blank_value'])}, aren't counted as off contract under definition B",
                  "refer": f"Decided by {who}: refer it on, so it's listed for a decision elsewhere"}[d]]
        if d == "refer":
            continue
        levers = [analysis.lever(ref, "obtain", "Obtain the signed agreement and check its terms", "risk", m["annual"],
                                 f"{R(m['annual'])} a year is bought under {ref}, whose agreement isn't on file, so its renewal date and rates can't be checked; "
                                 f"a request for the signed agreement is drafted")]
        if d == "register":
            oc_facts, lever = on_contract(ref, m["category"], extra=f"; the agreement isn't on file, so its own prices haven't been checked")
            facts += oc_facts
            levers += [lever] if lever else []
        elif m["category"] in cats:                                       # definition A: counted, but no agreement to move it onto
            x = cats[m["category"]]
            facts.append(f"Under definition A, {R(x['value'])} across {plural(x['lines'], 'purchase')} in {m['category']} is counted as off contract, with no agreement on "
                         f"file to move it onto")
        items.append(dict(ref=ref, name=f"{m['category']} ({ref}, not on file)", facts=facts, levers=levers))
    for cat, n, value in off["by_category"]:                             # definition A: categories no contract covers
        if refs.get(cat):
            continue
        x = cats[cat]
        yearly = value / months * 12
        facts = [f"Off contract: {R(value)} across {plural(n, 'purchase')}, {pct(value, off['value'])} of all off-contract spend and {pct(value, x['total'])} of the "
                 f"{R(x['total'])} spent in the category", "No contract covers the category: none of its purchases quotes an agreement",
                 f"Most of it at {x['site']}: {R(x['site_value'])}, {pct(x['site_value'], value)}"]
        items.append(dict(ref=cat, name=cat, facts=facts, levers=[analysis.lever(cat, "tender", "Put an agreement in place", "risk", yearly,
                                                                                  f"No contract covers the category: {R(value)} bought with no contract over {months} months"
                                                                                  + (f", {R(yearly)} a year" if months != 12 else "") + "; an agreement would bring it under agreed terms")]))
    return analysis.brief("items", items, review_facts(f, sp, months), review_date())


def review_facts(f: dict, sp: list[dict], months: int) -> list[str]:
    """The review's headline facts for the brief."""
    R, st, dec = kit.rand, rv().state, rv().state["decisions"]
    off, cal, esc, acts = f["off"], f["cal"], f["esc"], f["actions"]
    d = dec["definition"]
    dates = [s["PO Date"] for s in sp]
    passed, due = [x for x in cal if x["status"] == "passed"], [x for x in cal if x["status"] == "due within 60 days"]
    rises = sorted((e for e in esc if e["overcharge"] > 0), key=lambda e: -e["overcharge"])
    top = off["by_category"][:3]
    count = lambda kind: sum(x[0] == kind for x in acts)
    meant = f"Off contract means {DEFINED.get(d['option'], '')} (definition {d['option']}), decided by {kit.by(d)}: {R(off['value'])} across {off['lines']:,} purchases"
    facts = [f"Review date {kit.day(st['review_date'])}: every notice deadline is counted from it",
             f"{st['summary']['lines']:,} purchase orders worth {R(st['summary']['value'])}, from {min(dates):%B %Y} to {max(dates):%B %Y} "
             f"({months} months), and {st['summary']['agreements']} panel agreements read",
             "The definition of off contract was referred on, so no off-contract spend is counted or analysed" if off["definition"] == "refer" else
             f"{meant} in {len(off['by_category'])} categories. The three largest, {top[0][0]}, {top[1][0]} and {top[2][0]}, hold "
             f"{sum(c[2] for c in top) / off['value']:.0%} of it" if len(top) == 3 else meant,
             f"Agreements not on file: {', '.join(m['ref'] + ' (' + m['category'] + ', ' + REGISTER[m['decision']].lower() + ')' for m in f['missing']) or 'none'}",
             f"Renewals: {len(passed)} agreements' notice deadlines have passed ({', '.join(x['ref'] for x in passed) or 'none'}), so they will renew "
             f"automatically; {len(due)} are due within 60 days ({', '.join(x['ref'] + ' by ' + kit.day(x['notice_deadline']) for x in due) or 'none'}); "
             f"{len(cal) - len(passed) - len(due)} are later",
             f"Rate rises: {len(rises)} outside their agreements' terms, {R(sum(e['overcharge'] for e in rises))} charged above the terms in all "
             f"({'; '.join(e['ref'] + ' ' + R(e['overcharge']) + ', decided: ' + RISE[e['decision']].lower() for e in rises) or 'none'}); "
             f"{sum(e['case'] == 'compliant' for e in esc)} within the terms; {sum(e['case'] in ('unchanged', 'fixed') for e in esc)} unchanged, on fixed rates",
             f"Drafted for a person to review and send: {count('notice')} notices of non-renewal, {count('rate')} rate queries, {count('request')} requests "
             f"for an agreement not on file and {count('referral')} referral note",
             f"Assumptions: rate rises are checked against the published headline CPI for the month clause 2.3 names; buying on contract is taken to "
             f"cost {logic.ON_CONTRACT_SAVING:.0%} less than buying off it, the review's planning assumption, not measured in this review"]
    return facts


def split(acc: dict, b: dict) -> list[float]:
    """The projected gain in two parts: measured (credit notes and paying the agreed rate) and assumed (buying on contract, at
    the review's planning assumption)."""
    levers = {l["id"]: l for i in b["items"] for l in i["levers"]}
    chosen = [levers[r["lever"]] for v in acc["items"].values() for r in v["recommendations"]]
    assumed = round(sum(l["gain12"] for l in chosen if l["id"].endswith(":on-contract")), 2)
    return [round(acc["totals"]["gain12"] - assumed, 2), assumed]


ASSUMED = re.compile(r"assum\w*[^.]{0,30}?5\s?%|5\s?%[^.]{0,30}?assum", re.I)


def cmd_analysis(a):
    kit.needs(WORK, "findings.json", "analysis-brief.json", message=NOT_CALCULATED)
    r = rv()
    if r.state.get("release"):
        kit.fail("The analysis has already been checked and sent for release.")
    try:
        draft = json.loads(Path(a.file).read_text())
    except (OSError, ValueError):
        kit.fail("Fix and run again: the analysis must be a JSON file, as references/analysis-guide.md shows.")
    b = saved("analysis-brief.json")
    acc, problems = analysis.accept(draft, b)
    if not problems:                                                     # a value resting on the 5% says so wherever it's shown
        problems = [f"the action for {x['lever']} is valued at the planning assumption, so it must say so, for example \"(at an assumed 5% saving)\""
                    for v in acc["items"].values() for x in v["recommendations"] if x["lever"].endswith(":on-contract") and not ASSUMED.search(x["action"])]
    if problems:
        kit.fail(analysis.fix_message(problems))
    save("analysis.json", acc)
    f = saved("findings.json")
    analysis.record(r, acc)
    r.request_release(figures(f), acc, roles=kit.roles()["release"], recommended=acc["release"])        # the release approves both
    card = kit.release_card(CARD, r, WORK / "release-card.html", what="findings and recommendations", roles=kit.roles()["release"])
    measured, assumed = split(acc, b)
    first = [dict(item=i["name"], does=l["does"])
             for i in b["items"] for l in i["levers"] if l["id"] in acc["overview"]["priorities"][:1]]
    kit.emit(dict(ok=True, headline=acc["overview"]["headline"], recommendations=acc["recommendations"],
                  projected_gain_12_months=kit.rand_spoken(acc["totals"]["gain12"]), measured=kit.rand_spoken(measured),
                  assumed_at_5_percent=kit.rand_spoken(assumed), **({"first_priority": first[0]} if first else {}),
                  roles=kit.roles()["release"], release_card=card, **write_dashboard()))


def cmd_release(a):
    if (WORK / "findings.json").exists() and not (WORK / "analysis.json").exists():
        kit.fail("Fix and run again: write the analysis and run analysis first; it asks for the release.")
    try:
        rel = rv().decide_release(a.approve, a.reason, a.name, a.role, reviewed=a.reviewed)
    except ReviewError as e:
        kit.fail(str(e))
    kit.emit(dict(ok=True, status=rel["status"], name=rel["name"], role=rel["role"], at=kit.hhmm(rel["at"]), **write_dashboard()))


OWN = [["Draft letters (Word)", "Notices of non-renewal and rate queries, for a person to review, sign and send"],
       ["Referral note (Word)", "The off-contract hotspots for the category managers, the agreements to obtain, and anything referred on"]]


def cmd_publish(a):
    r = rv()
    f = saved("findings.json")
    if not f:
        kit.fail("There are no findings to release yet.")
    out = kit.outputs_dir()
    try:
        written = r.publish(figures(f), lambda: write_outputs(out, f), saved("analysis.json"))
    except ReviewError as e:
        write_dashboard()
        kit.fail(str(e))
    folder = str(Path(a.folder)) if a.folder else r.state.get("folder")
    into_copy = r.state.get("folder_copy") and folder == r.state.get("folder")     # a working copy is never filed into
    acc, b = saved("analysis.json"), saved("analysis-brief.json")
    res = kit.complete_release(r, out, written=written, own=OWN, folder=folder, into_copy=into_copy, template=TEMPLATE, build_run=build_run,
                               briefing_for=lambda places: briefing(r, f, places), labels=LABELS, about_inputs=about_inputs(),
                               pack_extra=pack_extra(r, f, acc, b), data=data_sheets(f), trace=trace(r, f, acc, b))
    kit.emit(dict(ok=True, **res, **write_dashboard()))


def when(iso: str) -> str:
    d = dt.date.fromisoformat(iso)
    return f"{d.day} {d:%B %Y}"


def pack_extra(r, f: dict, acc: dict, b: dict) -> dict:
    """The management pack's lead figure, scope, basis of the figures, what's asked of the meeting, and charts."""
    s, off = r.state["summary"], f["off"]
    rises = [e for e in f["esc"] if e["overcharge"] > 0]
    claimed = round(sum(e["overcharge"] for e in rises if e["decision"] == "claim"), 2)
    due = [x for x in f["cal"] if x["status"] == "due within 60 days"]
    hero = (dict(value=kit.rand_spoken(off["value"]), label="Off-contract spend", note=f"{off['lines']:,} purchases, definition {off['definition']}")
            if off["definition"] != "refer" else dict(value=kit.rand_spoken(claimed), label="Credit notes due", note=f"{sum(e['decision'] == 'claim' for e in rises)} rate queries")
            if claimed else dict(value=str(len(due)), label="Renewals due within 60 days", note="notice letters drafted"))
    sites = kit.places(s["sites"])
    scope = " · ".join(x for x in (f"{s['lines']:,} orders", f"{s['agreements']} panel agreements", kit.rand_spoken(s["value"]), s["period"], sites) if x)
    first, last = dt.date.fromisoformat(s["first"]).replace(day=1), dt.date.fromisoformat(s["last"])
    last = logic.add_months(last.replace(day=1), 1) - dt.timedelta(days=1)
    basis = (f"Figures cover only the {s['lines']:,} orders and {s['agreements']} panel agreements in this review{', at ' + sites if sites else ''}, "
             f"from {when(first.isoformat())} to {when(last.isoformat())} (rand excluding VAT), and are not group totals.")
    asks = []
    if due:
        asks.append(f"Agree who gives notice on {due[0]['ref']} ({due[0]['category']}), or renews it on purpose, before {when(due[0]['notice_deadline'])}.")
    if claimed:
        asks.append(f"Approve the {sum(e['decision'] == 'claim' for e in rises)} rate queries, claiming {kit.rand_spoken(claimed)} in credit notes.")
    obtain = [m["ref"] for m in f["missing"] if m["decision"] != "refer"]
    if obtain:
        asks.append(f"Ask the contracts office for the signed {' and '.join(obtain)} agreement{'s' * (len(obtain) > 1)}, so their terms can be checked.")
    elif off["definition"] != "refer" and off["lines"]:
        asks.append(f"Ask the category managers to bring {', '.join(off['hotspots'][:-1])} and {off['hotspots'][-1]} onto their agreements.")
    found = (dict(title="Off-contract spend by category", kind="hbar", money=True, labels=[c[0] for c in off["by_category"][:8]],
                  series=[dict(label="Off-contract spend", data=[c[2] for c in off["by_category"][:8]])]) if off["lines"] else
             dict(title="Charged above the terms, by agreement", kind="hbar", money=True, labels=[f"{e['ref']} · {e['supplier']}" for e in rises],
                  series=[dict(label="Charged above the terms", data=[e["overcharge"] for e in rises])]) if rises else None)
    return dict(hero=hero, scope=scope, basis_note=basis, asks=asks[:3], charts=kit.pack_charts(analysis.chart_series(acc, b, review_date()), found))


def data_sheets(f: dict) -> list[dict]:
    """The Data workbook: every row the review read, as read, and every row-level result."""
    r = rv()
    sp = spend()
    lines, notices = logic.load_lines(Path(r.state["files"]["lines"]))
    cats, dec, off = set(f["cats"]), decided(), f["off"]
    refs, on_file = logic.references(sp), set(agreements())
    counted = {id(s) for s in sp if not s["ref"] and off["definition"] != "refer" and (off["definition"] == "A" or s["Category"] in cats)}

    def result(s: dict) -> str:
        if s["ref"]:
            return "On contract" + ("" if s["ref"] in on_file else f": {s['ref']} not on file")
        if id(s) in counted:
            return "Off contract"
        if off["definition"] == "refer":
            return "Not counted: the definition was referred on"
        return "Not counted: no contract covers the category" if not refs.get(s["Category"]) else "Not counted: the category's agreement isn't on file"
    esc = {e["ref"]: e for e in f["esc"]}
    allowed = {(ref, d): a for ref, pts in saved("gate.json")["rates"].items() for d, _, a in pts}     # the rate each line was allowed
    rate_rows = []
    for x in sorted(lines, key=lambda x: (x["Agreement Reference"], x["Invoice Date"], x["Invoice ID"])):
        e = esc.get(x["Agreement Reference"], {})
        hit = next((h for h in e.get("invoices", []) if h[0] == x["Invoice ID"]), None)
        rate_rows.append([x["Agreement Reference"], x["Supplier"], x["Invoice ID"], x["Invoice Date"], x["Item"], int(x["Quantity"]), float(x["Unit Rate"]),
                          hit[4] if hit else allowed.get((x["Agreement Reference"], x["Invoice Date"].isoformat()), float(x["Unit Rate"])),
                          hit[5] if hit else 0.0, logic.CASES[e["case"]] if hit else "Within the terms", RISE.get(e.get("decision"), "") if hit else ""])
    terms = [[c["ref"], c["category"], t["label"], t["claude"], t["check"], {"confirmed": "Confirmed", "differs": "Differs", "not found": "Not in the agreement"}[t["status"]],
              t["clause"] or "", t["quote"] or ""] for c in saved("comparison.json") for t in c["terms"]]
    ags = agreements()
    cal = [[x["ref"], x["category"], (ags[x["ref"]]["commencement"] or {}).get("value"), ags[x["ref"]]["initial_term_months"]["value"],
            ags[x["ref"]]["renewal_months"]["value"], ags[x["ref"]]["termination_notice_days"]["value"], x["period_end"], x["notice_deadline"], x["days_left"],
            {"passed": "Notice passed: renews automatically", "due within 60 days": "Notice due within 60 days", "later": "Later"}[x["status"]]] for x in f["cal"]]
    money = {"Amount Excl VAT", "Unit Rate", "Line Amount", "Previous Unit Rate", "New Unit Rate", "Rate charged", "Rate allowed", "Charged above the terms", "Amount"}
    return [
        dict(name="Spend history", about="Every purchase order in the spend history, with the columns the review reads, and how it counted each", money=money,
             headers=[*logic.SPEND_COLUMNS, "Counted as"], rows=[[*(s[c] for c in logic.SPEND_COLUMNS), result(s)] for s in sp]),
        dict(name="Invoice lines", about="Every invoice line under the panel agreements, as read", money=money, headers=logic.LINE_COLUMNS,
             rows=[[x[c] for c in logic.LINE_COLUMNS] for x in lines]),
        dict(name="Rate notices", about="Every notice of an adjusted rate received, as read", money=money, headers=logic.NOTICE_COLUMNS,
             rows=[[n[c] for c in logic.NOTICE_COLUMNS] for n in notices]),
        dict(name="Agreement terms", about="Each term of each agreement: how it was read, the independent check's reading, and the clause it comes from",
             headers=["Agreement", "Category", "Term", "Read as", "Independent check", "Result", "Clause", "Quoted from the agreement"], rows=terms),
        dict(name="Off-contract purchases", about=f"The purchases counted as off contract under definition {off['definition']}, as decided", money=money,
             headers=["PO ID", "Supplier", "Category", "Site", "PO Date", "Amount"],
             rows=[[s["PO ID"], s["Vendor Name"], s["Category"], s["Site"], s["PO Date"], s["amount"]] for s in sp if id(s) in counted]),
        dict(name="Renewal calendar", about=f"Each agreement's current period and the last day to give notice, from the review date, {kit.day(r.state['review_date'])}",
             headers=["Agreement", "Category", "Commencement", "Initial term (months)", "Renewal (months)", "Notice (days)", "Period ends", "Notice by",
                      "Days left", "Status"], rows=cal),
        dict(name="Rate checks", about="Each invoice line against the rate its agreement allows, with anything charged above the terms and the decision on it",
             money=money, headers=["Agreement", "Supplier", "Invoice", "Date", "Item", "Quantity", "Rate charged", "Rate allowed", "Charged above the terms",
                                   "Result", "Decision"], rows=rate_rows)]


def trace(r, f: dict, acc: dict, b: dict) -> list[dict]:
    """How each released figure was worked out, from which file and rows, and at which step of the record."""
    s, files = r.state["summary"], r.state["files"]
    step = lambda event: next((f"#{e['seq']}" for e in r.entries() if e["event"] == event), "")
    sp_name, ln_name = f"{kit.DATA}/{Path(files['spend']).name}", f"{kit.DATA}/{Path(files['lines']).name}"
    off, rises = f["off"], [e for e in f["esc"] if e["overcharge"] > 0]
    measured, assumed = split(acc, b)
    return [dict(figure="Purchase orders", value=f"{s['lines']:,}", how="Every row of the spend history", source=f"{sp_name}, sheet Spend, rows 2 to {s['lines'] + 1:,}", step=step("review-started")),
            dict(figure="Spend", value=kit.rand(s["value"]), how="The sum of Amount Excl VAT on every order", source=f"{sp_name}, sheet Spend", step=step("review-started")),
            dict(figure="Off-contract spend", value=kit.rand(off["value"]), how=f"Orders with no contract reference, counted under definition {off['definition']}: "
                 + ("every one" if off["definition"] == "A" else "those in a category a contract covers, on file or relied on" if off["definition"] == "B" else "none: referred on"),
                 source=f"{sp_name}, sheet Spend: {off['lines']:,} orders (Data workbook, Off-contract purchases)", step=step("stage-calculated")),
            dict(figure="Missing agreements", value=str(len(f["missing"])), how="Contract references the spend quotes with no agreement among the documents",
                 source=f"{sp_name}, Contract Reference, against {kit.DOCUMENTS}", step=step("decision-requested")),
            dict(figure="Notice deadlines passed or due within 60 days", value=str(sum(x["status"] != "later" for x in f["cal"])),
                 how="The end of each agreement's current period, less the notice in clause 4.1, from the review date", source=f"{kit.DOCUMENTS}: clause 4.1 of each agreement", step=step("stage-calculated")),
            dict(figure="Rate breaches", value=str(len(rises)), how="Each invoice line against clause 2.3: the anniversary, a valid notice (clause 8.1), the notice period and the CPI for the month it names",
                 source=f"{ln_name}, sheets Invoice lines and Rate notices", step=step("decision-requested")),
            dict(figure="Charged above the terms", value=kit.rand(sum(e["overcharge"] for e in rises)), how="Per invoice line: the whole rise where it wasn't yet allowed, or the part above the CPI allowed",
                 source=f"{ln_name}, sheet Invoice lines ({sum(e['lines'] for e in rises)} lines)", step=step("stage-calculated")),
            dict(figure="Credit notes due", value=kit.rand(sum(e["overcharge"] for e in rises if e["decision"] == "claim")), how="The rises a person decided to claim",
                 source=f"{ln_name}, sheet Invoice lines", step=step("decision-recorded")),
            dict(figure="Projected gain, next 12 months", value=kit.rand(acc["totals"]["gain12"]), how=f"The recommended levers, valued by the review's rules: {kit.rand(measured)} measured "
                 f"(credit notes and paying the agreed rate) and {kit.rand(assumed)} at an assumed 5% saving on buying on contract", source="The findings", step=step(analysis.EVENT))]


def briefing(r, f: dict, filed: dict) -> dict:
    """What the management pack may say: this review's released figures, decisions and record, already formatted."""
    off, cal, esc = f["off"], f["cal"], f["esc"]
    passed, due = [x for x in cal if x["status"] == "passed"], [x for x in cal if x["status"] == "due within 60 days"]
    rises = sorted((e for e in esc if e["overcharge"] > 0), key=lambda e: -e["overcharge"])
    claimed = [e for e in rises if e["decision"] == "claim"]
    to_recover = round(sum(e["overcharge"] for e in claimed), 2)
    acc, b = saved("analysis.json"), saved("analysis-brief.json")
    measured, assumed = split(acc, b)
    gain = acc["totals"]["gain12"]
    owner = {"notice": "Category management", "rate": "Accounts payable", "request": "Contract management", "referral": "Category management"}
    actions = analysis.actions(acc, b) + [dict(action=x[2], owner=owner[x[0]], detail=x[3]) for x in f["actions"]]     # then the drafts
    refer = off["definition"] == "refer"
    count = lambda n: kit_words(n).capitalize() if n <= 12 else str(n)
    findings = ["The definition of off contract was referred on, so off-contract spend isn't counted here." if refer else
                f"{kit.rand_spoken(off['value'])} of spend across {off['lines']:,} purchases went outside the contracts, led by {off['hotspots'][0]}."]
    if f["missing"]:
        named = [f"{m['ref']} ({m['category']}, {kit.rand_spoken(m['annual'])} a year)" for m in f["missing"]]
        findings.append(f"{count(len(named))} agreement{'s' * (len(named) > 1)} the purchases quote {'aren' if len(named) > 1 else 'isn'}'t on file: "
                        + (", ".join(named[:-1]) + " and " + named[-1] if len(named) > 1 else named[0]) + ".")
    findings.append((f"{count(len(passed))} agreements will renew automatically because their notice deadlines have passed; " if passed else "")
                    + (f"{kit_words(len(due))} more renew unless notice is given by {kit.days([x['notice_deadline'] for x in due])}." if due else "no other notice falls due within 60 days."))
    findings.append(f"{count(len(rises))} rate rises broke their agreements' terms, {kit.rand_spoken(sum(e['overcharge'] for e in rises))} above the terms: "
                    f"{kit_words(len(claimed))} claimed as credit notes ({kit.rand_spoken(to_recover)}), {kit_words(sum(e['decision'] == 'accept' for e in rises))} accepted and "
                    f"{kit_words(sum(e['decision'] == 'refer' for e in rises))} referred on." if rises else "No supplier raised its rates outside its agreement.")
    what = lambda k, d: 'What "off contract" means' if k == "definition" else f"{k.split(':')[1]}, not on file" if k.startswith("missing:") else f"{k.split(':')[1]}'s rate rise"
    return kit.briefing(r, use_case="Contract & Spend Leakage", question="Are we buying through our contracts, and are their terms being honoured?",
                        answer=("Off-contract spend was referred on; the renewals and rate rises are reported." if refer else
                                f"{kit.rand_spoken(off['value'])} of spend across {off['lines']:,} purchases went outside the contracts."),
                        figures=[kit.figure("Off-contract spend", off["value"], "money", f"{off['lines']:,} purchases, definition {off['definition']}"),
                                 kit.figure("Credit notes due", to_recover, "money", f"{len(claimed)} of {len(rises)} rate rises outside the terms"),
                                 kit.figure("Projected gain", gain, "money", "over the next 12 months"),
                                 kit.figure("Measured gain", measured, "money", "credit notes and the agreed rate"),
                                 kit.figure("Assumed gain", assumed, "money", "buying on contract at 5%, not measured"),
                                 kit.figure("Renewals to act", len(passed) + len(due), f"{len(passed)} passed, {len(due)} due within 60 days"),
                                 kit.figure("Missing agreements", len(f["missing"])), kit.figure("Rate breaches", len(rises)),
                                 kit.figure("Purchase orders", r.state["summary"]["lines"]), kit.figure("Agreements read", r.state["summary"]["agreements"])],
                        findings=findings, decisions=kit.decisions_view(r, what), actions=actions, filed=filed, analysis=analysis.briefing(acc),
                        ai_help=dict(assist=f"The {r.state['summary']['agreements']} panel agreements were read and every term recorded with its clause, confirmed by an "
                                            f"independent check, and the letters, the requests and the referral note were drafted.",
                                     augment=f"People decided {len(r.state['decisions'])} items on one card before anything was counted: what off contract means, "
                                             f"the agreements not on file and each rate rise outside its terms. Each agreement and category was then analysed, and "
                                             f"{acc['recommendations']} recommendations valued by the review's own rules at {kit.rand_spoken(gain)} over the next 12 months.",
                                     automate="Fixed rules measured off-contract spend, worked out every notice deadline and checked every invoice line against the "
                                              "published CPI, and the evidence, the drafts and a tamper-evident record were filed in the project folder."))


def write_outputs(out: Path, f: dict) -> list[str]:
    import publish_pack
    acc, b = saved("analysis.json"), saved("analysis-brief.json")
    return publish_pack.write(out, rv(), f, agreements(), saved("comparison.json"), spend(), analysis.rows(acc, b), acc["totals"]["gain12"], split(acc, b))


def cmd_verify(a):
    ok, msg = verify_record(a.file) if a.file else rv().verify()
    kit.emit(dict(ok=ok, tamper_check=msg))


def cmd_dashboard(a):
    kit.needs(WORK, "review-state.json", message=NOT_STARTED)
    kit.emit(dict(ok=True, **write_dashboard()))


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("ready", "read", "findings", "dashboard"):
        sub.add_parser(name)
    sub.add_parser("gate").add_argument("--assessment", help="the recommendation for each item on the card, as references/assessment-guide.md describes")
    st = sub.add_parser("start")
    st.add_argument("--folder", help="the project folder: its 01 Documents and 02 Data hold the review's files")
    st.add_argument("--copy", action="store_true", help="the folder is a working copy of the project folder's 01 Documents and 02 Data")
    st.add_argument("--files", nargs="*")
    sub.add_parser("publish").add_argument("--folder", help="the project folder to file the released results in")
    sub.add_parser("check").add_argument("--reading", required=True)
    d = sub.add_parser("decide")
    d.add_argument("--file", help='the card\'s decisions: {"decisions": [{"item", "option", "reason"}]}')
    d.add_argument("--item")
    d.add_argument("--option")
    d.add_argument("--reason")
    d.add_argument("--name", required=True)
    d.add_argument("--role", required=True)
    sub.add_parser("analysis").add_argument("--file", required=True, help="the analysis, as references/analysis-guide.md describes")
    rl = sub.add_parser("release")
    grp = rl.add_mutually_exclusive_group(required=True)
    grp.add_argument("--approve", action="store_true")
    grp.add_argument("--return", dest="approve", action="store_false")
    rl.add_argument("--reason", required=True)
    rl.add_argument("--name", required=True)
    rl.add_argument("--role", required=True)
    rl.add_argument("--reviewed", action="store_true", help='the approver confirms: "I have reviewed the findings, the decisions and the recommendations."')
    sub.add_parser("verify").add_argument("--file", help="a downloaded record to check instead of this review's")
    return p


if __name__ == "__main__":
    kit.main(parser(), {n[4:]: f for n, f in globals().items() if n.startswith("cmd_")})
