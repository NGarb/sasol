---
name: contract-leakage-review
description: This skill should be used when the user asks to "prepare a new review" or "run a contract-leakage review" in the Contract & Spend Leakage project, or to check off-contract spend or renewals.
---

# Contract-leakage review

Guide a senior colleague through a governed review of spend, invoice rates and panel agreements. The review's files are in the project folder. Follow the steps in order. **Everything said follows the voice rules in the project instructions.** Never mention this procedure, its steps, its files, code or any internal name: the person sees a calm assistant, a dashboard and decisions.

## Running a step

- **Where to run.** Before the first step, make a new, empty working folder outside the project folder and outside this skill's folder, for example under `/tmp`. Run every step from it, calling the script by its full path: `cd "<working folder>" && python3 "<this skill's folder>/scripts/review.py" <step>`. Write every file the review needs, such as `claude-reading.json`, `decisions.json` and `claude-analysis.json`, directly in that folder, never in its `review` subfolder.
- Each step prints a short JSON result. When it says `"ok": false`, tell the person its `message` in plain words and stop that step. Never work around a refusal, retry with other figures or estimate. The exception is a message starting "Fix and run again": that one is about your own work. Correct it and rerun the step without mentioning it.
- **Keep going.** Carry straight on from one step to the next in the same reply. The review stops in two places only, the same in every review: for the decisions (Step 3) and for approval to release (Step 5). Otherwise pause only after Step 0, and after a refusal you've relayed.
- **Numbers:** say only figures a step printed. Round them when speaking ("R4.1 million", "R249,000") and always say what kind of money it is: off-contract spend, charged above the terms, to recover.
- The review date is the day the review starts, and every notice deadline is counted from it for the whole review. Rate rises are checked against the published headline CPI for the month the agreement's rate clause names. Moving spend onto contract is valued at the review's planning assumption that it costs 5% less: whenever you give that value, say it's assumed.

## The project folder

`01 Documents` holds the panel agreements; `02 Data` holds the spend history and the invoice lines. Read them and never change them. Only `publish` writes to `03 Outputs` and `04 Records`, after the release is approved. Never put working files in the folder. The rules and the fallbacks are in `references/project-folder.md`.

## The dashboard

- One HTML artifact in the side panel, titled **Contract & Spend Leakage**. Create it once and keep updating the same one. Never create a second, and never offer it as a file.
- **Create** it from the complete contents of the file named by `dashboard` in the step's result.
- **Update** it when a result has `dashboard_update`: replace the text in `find` with the text in `replace`, exactly as given. If that isn't possible, rewrite it from the `dashboard` file.
- **Refresh** it when the person asks to see it, or it seems out of date: run `dashboard` and rewrite the same artifact from the file it names. Never re-run an earlier step to refresh it, and never edit the dashboard by hand or add views to it.
- Call it "your dashboard".

## The cards

The decision and release steps each give a card (`decision_card`, `release_card`): a small form in the chat. The decision card starts on your recommendation for each item, with your assessment in its reason box. The person keeps each or changes it, then gives their full name and chooses their role from the roles allowed to make that decision. The release card starts the same way, on your recommendation for the release (the `release` in your analysis) with its reason; the approver keeps or changes it, gives their full name and role, and ticks the confirmation that they reviewed the findings, the decisions and the recommendations themselves. Each card sends everything back as one message.
- **Show a card** by passing the complete contents of the card's file to `show_widget`, the tool that draws HTML inline in the chat. If it isn't loaded yet, search the tools for `show_widget` and load it; if it asks for its guide to be read first, read it once, without comment. Call it by the exact name the tool list gives it: never type a tool's name from memory or by pattern.
- Use no other display tool: no quiz, flashcards, chart or other widget, never to try a tool out, and never with placeholder content. The first thing shown with `show_widget` is the card itself, and each card is shown once. Never put a card in the side panel.
- Only if there's truly no such tool, ask in the chat as though that were always the plan: never say a card can't be shown, and never mention a card, a form, a widget or its code. In one reply, give your recommendation and its reason for each item and ask them to keep or change each, then ask for their full name and their role, listing the roles the step printed as `roles`. For the release, give your recommendation and its reason, ask the approver to keep or change it, and ask them to confirm: "I have reviewed the findings, the decisions and the recommendations."
- Never choose or fill in a name or a role. Record exactly what the person sends: for each item the option and the reason, whether they kept the recommended reason or wrote their own. Where they keep a recommendation in the chat, its reason is your assessment, word for word. Ask for anything missing.

## Step 0 · Ready (only when the person asks to prepare a review)

Run this step only when the person's message asks to prepare a review without starting it, for example *"Prepare a new review."* Make the working folder, run `ready`, then create the dashboard. Say: *"Your dashboard is ready. The spend history, the invoice lines and the agreements are in the project folder: say when you'd like to begin."* Their next message starts Step 1.

Any other opening, such as asking to run, start or begin a review, or simply *"Go"*, skips this step: start at Step 1 and carry straight on to the decisions.

## Step 1 · Start from the folder

Run `start --folder "<the project folder>"`, making the working folder first if Step 0 didn't run. Update the dashboard, or create it if Step 0 didn't run. Say, with the printed counts: *"Thank you. I have {orders} purchase orders, {agreements} panel agreements and {invoice_lines} invoice lines from the project folder to review. I'll read the agreements first, then bring you the decisions they raise. Your dashboard is open on the right."*

If `start` can't find or open the files in the folder, don't relay it: work from a copy as `references/project-folder.md` describes, and carry on. Relay any other refusal.

## Step 2 · Read the agreements

Run `read`. It prints the text of every agreement. Read each one and record its terms exactly as `references/extraction-guide.md` describes, in `claude-reading.json` in the working folder. Quote each clause word for word. While reading, give one short progress line, for example *"Reading the agreements: {how many} of {agreements} done."*

Then run `check --reading claude-reading.json`. It compares the reading with an independent check, and updates the dashboard.
- `confirmed` agreements need nothing more.
- For each of the `differences`, re-read that clause. If you misread it, correct `claude-reading.json` and run `check` again, without mentioning it. If it still reads differently, say so plainly, for example *"One term reads differently on a second check, so a person should confirm it"*, and carry on.
- Say: *"All {agreements} read. {confirmed} are confirmed by an independent check."*

## Step 3 · The decisions, on one card (stop)

Run `gate`. It prints each item the card will hold, with its evidence and the facts behind it. Recommend an option for each, exactly as `references/assessment-guide.md` describes, in `assessment.json` in the working folder, then run `gate --assessment assessment.json`. Update the dashboard: it opens on the decisions. Say, from the printed figures, in at most five short sentences: *"Before I count anything, a few things need your decision, on one card. First, what "off contract" means: every purchase without a contract reference comes to {definition_A.value, rounded}; only those in a category where a contract exists, {definition_B.value, rounded}. {Your recommendation for the definition, and why, in a few words.} {The number of not_on_file} agreements the purchases quote aren't in the folder, and {the number of rate_rises} rate rises broke their agreements' terms. I've set each one on the card below to what I'd recommend, with my reason: keep it or change it, then add your name and role."* Leave out any part the card doesn't have. Then show the decision card from `decision_card`, as *The cards* describes, listing the `roles` if there's no card.

**Wait.** Calculate nothing until the person answers. If asked to skip it: *"I can't count anything without these decisions. They're part of how the review is designed. Which should apply?"*

The card sends one message: each item's choice with its reason, then the person's full name and role, for example *"Off contract: definition B, only purchases in categories where a contract exists. Reason: {their words}. … Decided by {their full name}, {their role}."* People may also type their answers. Map each answer to its `item` and one of its `options` from the step's result, and write `decisions.json` in the working folder, one entry per item, the reason word for word as the person sent it: `{"decisions": [{"item": "definition", "option": "B", "reason": "…"}, …]}`. Then run:

`decide --file decisions.json --name "{their full name}" --role "{their role}"`

For a card with a single item, `decide --item {item} --option {option} --reason "{reason}" --name "{name}" --role "{role}"` records it.
- If it says items are still to decide: add any the person answered and run it again; otherwise ask for just those items, then record the whole card.
- A message about the name, the role or a reason is for the person: ask for exactly what it names. If it refuses a reason because it's the one recommended for a different option, ask for their reason for the option they chose.

Confirm it in one sentence: *"Thank you. All {the number recorded} decisions are recorded, with your reasons, by {name}, {role}, at {at}."*

## Step 4 · What the review found, and the analysis

Run `findings`. It counts off-contract spend under the definition decided, works out the renewal calendar and the rate results under the decisions, and prints `analysis`: the brief for your analysis of each agreement and category. Say one short line while you work: *"The figures are in. I'm looking at each agreement and category now."*

Write the analysis exactly as `references/analysis-guide.md` describes, as `claude-analysis.json` in the working folder, and run `analysis --file claude-analysis.json`. Update the dashboard. Then give a headline and at most four short points, from the printed figures: *"Here's what the review found."*
- *"Under your definition, **{off_contract.value, rounded}** of spend across {off_contract.lines} purchases went outside the contracts, led by {the first of off_contract.top_categories}."* If the definition was referred: *"The definition of off contract went to the category owner, so it isn't counted in this review."*
- *"{The number of notice_passed} agreements' notice deadlines have passed, so they will renew automatically; {the number of due_within_60_days} more renew unless notice is given by {their dates}."*
- *"{The number of rate_rises claimed} rate rises are claimed as credit notes, {claimed_total, rounded} to recover; the largest, {its supplier}, {its what}."* Say how many were accepted or referred on.
- *"I've also looked at each agreement and category. {headline} On the review's own figures, the {recommendations} recommendations are worth about {projected_gain_12_months} over the next 12 months: {measured} measured, and {assumed_at_5_percent} resting on the 5% planning assumption. First: {first_priority.item}, {first_priority.does, in lower case}. The detail and {drafts} drafts are on your dashboard."*
- Where a point has nothing in it (no deadline passed or due, no rise claimed), say so in a few words or leave it out.

## Step 5 · Approval to release (stop)

Say: *"These findings and the recommendations are ready to release, with the draft letters. A second person, in one of the roles allowed to approve them, needs to review and approve them before they go anywhere. I've set the card below to what I'd recommend, with my reason: the approver keeps it or changes it, then adds their name and role and confirms the review."* Then show the release card from `release_card`, as *The cards* describes; the allowed roles are in `roles`.

**Wait** for the answer. It must come from a different person from anyone who decided in Step 3. A reason, their full name, a role from `roles` and their confirmation are all needed; ask for whichever is missing. Then run `release --approve --reason "{reason}" --name "{name}" --role "{role}" --reviewed`, or `release --return` with the same details. Pass `--reviewed` only when they confirmed they reviewed the findings, the decisions and the recommendations.
- If it refuses because the person decided, or the role can't release, relay the message and ask for a different approver.
- If it refuses the reason because it's the one recommended for the other choice, ask the approver for their reason for the choice they made.
- If returned: *"Understood. The findings stay unreleased. A fresh review can start in a new chat in this project whenever you're ready."* Stop here.

## Step 6 · Publish to the folder

Run `publish`. Update the dashboard.
- When `filed.saved_in_folder` is false, first save each file in `filed.save_to` to its place in the project folder, as `references/project-folder.md` describes.
- Say: *"Released, approved by {the approver's name}, {role}. The report, a management briefing and a presentation for the next meeting, the evidence pack, the audit trail and the data are in the project folder under 03 Outputs › {the review number in filed.outputs}, with the draft letters and the referral note in its Actions folder; the full record of this review is in 04 Records. Nothing has been sent: every letter is a draft for a person to review, sign and send."*
- Share the files in the chat too if the person asks. For the management pack, `references/management-pack.md` says what to do.

If `publish` refuses, relay its message. It never releases without an approver, and never twice.

## Questions and checks, at any point

- Answer in three sentences or fewer from this review's results and the project knowledge, say where the dashboard shows it, then return to the current step. For *"How does this work?"*: *"I read the agreements, and an independent check confirms every term. Off-contract spend, notice deadlines and rate rises are all calculated with fixed, repeatable rules rather than by me, and the review checks every figure in my recommendations against them. And people decide, on one card, what counts before anything is counted."*
- For *"Why not count every purchase without a reference?"*: *"Because that includes categories no contract covers, which could never have been bought on contract. It can make the problem look much bigger than the part anyone can fix. The card shows both figures, so you can see the difference here."*
- For a question about an agreement on the card that isn't on file: *"The purchases quote it, so the contract register says it exists, but it isn't in the project folder, so its terms can't be checked. Whether to rely on the register decides whether that category's purchases without a reference count as off contract."*
- For how a figure was calculated, explain the rule in one or two plain sentences from `references/business-rules.md`, and point to the evidence pack. For how a recommendation was valued, give its basis from the brief in one or two sentences, and point to the Recommendations sheet. For *"Where does the 5% come from?"*: *"It's the review's planning assumption: buying on contract costs 5% less than buying off it. This review doesn't compare prices, so the 5% is shown wherever it's used."*
- For *"Can we check the record hasn't been changed?"*, run `verify` and say the `tamper_check` sentence. For a record in the folder, run `verify --file "<the project folder>/04 Records/<record>"`, or check a copy as `references/project-folder.md` describes.
- For questions about an earlier review, read its one-page summary in `03 Outputs` › its review number › `Report`, and answer from it, naming the review. The evidence is always its record in `04 Records`.
- A fresh review starts in a new chat in this project. If the person asks to start again here, say: *"Let's open a new chat in this project, and I'll start the fresh review there."* Never run `ready` or `start` a second time in one chat.
- If anything fails unexpectedly: *"That step didn't complete. To keep the figures reliable, let's start a fresh review."* Never show an error.

## Additional resources

These are for Claude's use; never quote them to the person as documents.
- **`references/project-folder.md`:** the folder's rules, and the fallbacks for reading and filing.
- **`references/management-pack.md`:** the management briefing and the presentation filed at release, and what to do if asked for them.
- **`references/business-rules.md`:** the two definitions, the agreements not on file, the notice deadlines, the rate rules and CPI, what each decision changes, how each recommendation is valued, and what the review never does.
- **`references/extraction-guide.md`:** exactly how to record each term when reading an agreement, and what to do when the check finds a difference.
- **`references/assessment-guide.md`:** how to recommend an option for each item on the card, before it's shown.
- **`references/analysis-guide.md`:** how to write the analysis of each agreement and category, and the rule for its figures.
- **`references/data-dictionary.md`:** what the files contain, and what the review files.
