# Reading an agreement: what to record

You read every agreement yourself. An independent check then compares your reading, term by term. Record what the agreement **says**, not what seems sensible, and quote the sentence it comes from, word for word and in full.

Agreements are numbered and laid out in their own ways. Find each term by what it says, wherever it sits, and record the clause number the agreement itself gives it.

## The file you write: `claude-reading.json`

```json
{"agreements": [
  {"ref": "AGR-0100", "category": "Example Category",
   "commencement": {"value": "2022-05-16", "clause": "Heading", "quote": "Commencement date: 16 May 2022"},
   "initial_term_months": {"value": 36, "clause": "9.1", "quote": "9.1 This agreement runs for thirty six months from the Commencement Date and then renews automatically for further periods of twelve months each, unless either party gives ninety days' written notice before the end of the period then running."},
   "renewal_months": {"value": 12, "clause": "9.1", "quote": "9.1 This agreement runs for thirty six months … before the end of the period then running."},
   "termination_notice_days": {"value": 90, "clause": "9.1", "quote": "9.1 This agreement runs for thirty six months … before the end of the period then running."},
   "escalation": {"value": true, "clause": "5.4", "quote": "5.4 The Supplier may adjust the scheduled rates once in each year, … on written notice under clause 14."},
   "rate_notice_days": {"value": 45, "clause": "5.4", "quote": "5.4 The Supplier may adjust the scheduled rates once in each year, … on written notice under clause 14."}}
]}
```

One entry per agreement, **every agreement you were given**, with its reference exactly as the agreement gives it. The example is illustrative: its agreement, clauses and values are made up, so don't copy them, and write every quote in full (the example shortens them only to fit). Each term is `{"value", "clause", "quote"}`, or `null` when the agreement doesn't contain it. Never guess a value for a term that isn't there.

## The terms, precisely

| Term | Record | Watch for |
|---|---|---|
| `commencement` | The commencement date in the heading, as `YYYY-MM-DD`; clause is `"Heading"` | A date written out in the heading: record it as `YYYY-MM-DD`, and quote the heading line |
| `initial_term_months` | How long the agreement runs from commencement, in months | Written in words ("forty eight months"): record 48. The agreements differ: read each one |
| `renewal_months` | The length of each automatic renewal period, in months | Often the same sentence as the term; quote it again |
| `termination_notice_days` | Notice needed **to stop the agreement renewing**, in days | "one hundred and twenty days" is 120. **Not** the notice a supplier gives before changing its rates |
| `escalation` | `true` if the rates may be adjusted each year | `null` when the agreement fixes its rates or has no adjustment clause |
| `rate_notice_days` | The written notice a supplier must give before an adjusted rate takes effect, in days | `null` whenever `escalation` is `null` |

The rate-adjustment clause may also name the CPI month it allows, and a notices clause where notices must go: the review applies both itself, so you don't record them. The payment period isn't needed; leave it out.

Some agreements the spend quotes may not be in the folder at all: record only the agreements you were given. The review raises the missing ones itself, as decisions.

## If the check finds a difference

The check lists each term it read differently. Re-read that clause. If you were wrong, correct the file and run the check again. If you still read it differently, leave it, say so plainly, and carry on: a person confirms it.
