# Assessing each item on the card: what to recommend

Before the card is shown, recommend an option for every item on it. The card starts on your recommendation, with your assessment in the reason box, and the person keeps it or changes it. So write the assessment as a reason a person could sign: plain, specific, and based only on that item's evidence.

Base it **only on what the gate printed for that item**: its `evidence` and its `facts`. Don't use outside knowledge, and don't guess about the suppliers.

## The file you write: `assessment.json`

```json
{"items": [
  {"item": "definition",
   "recommendation": "B",
   "confidence": "high",
   "assessment": "Only purchases in categories a contract covers could have been bought on contract, so B measures the leakage that can be fixed."},
  {"item": "rate:AGR-0100",
   "recommendation": "claim",
   "confidence": "high",
   "assessment": "The rate rose by more than CPI allows, so the part above the allowed rate should be recovered as a credit note."}
]}
```

One entry for **every item the gate printed**. The example is made up. Its fields:

| Field | Write |
|---|---|
| `item` | The item exactly as the gate printed it: `definition`, `missing:<reference>` or `rate:<reference>` |
| `recommendation` | The key of one of its `options`, as the gate printed them. `refer` when the evidence can't settle it |
| `confidence` | `high`, `medium` or `low` |
| `assessment` | One or two plain sentences, 5 to 60 words, naming the facts that decide it |

## How to weigh each kind of item

- **What "off contract" means:** recommend **B**, with `high` confidence: only purchases in a category a contract covers could have been bought on contract. Recommend A only if nothing in the evidence shows which categories are contracted.
- **An agreement that isn't in the folder:** its terms can't be checked, so confidence is `medium` at most.
  - Where the purchases show the agreement plainly in use (many of them quote it, and few in the category carry no reference), recommend **relying on the contract register**, and say the signed copy should be filed.
  - Where the register alone can't show which purchases the agreement covers (many purchases in the category carry no reference, or many different suppliers quote the one reference), recommend **treating the category as uncontracted until the agreement is filed**.
  - Where it's unclear either way, recommend `refer`.
- **A rate rise outside the terms:**
  - A clear breach of the agreement's own terms (no notice at all, charged before the anniversary, or above what CPI allows): recommend **claiming a credit note**, with `high` confidence.
  - A breach of procedure only, where the rise itself is within CPI and notice was given (late, or to the wrong person): the claim is supported, but weigh what's at stake. For a small amount on a few lines, accepting the rise can be proportionate, with `medium` confidence; say so. Where notice went to someone other than the contracts office, whether it counts is a question for the contract owner: recommend `refer`.
  - Say what the rise was against what the terms allow, in the evidence's own figures.
- **Never recommend an option because of what it does to the totals.** The evidence decides it.
- Never say or imply wrongdoing. Recommend, cite and state your confidence. The person decides.
