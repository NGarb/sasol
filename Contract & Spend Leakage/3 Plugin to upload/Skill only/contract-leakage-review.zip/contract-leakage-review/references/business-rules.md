# Business rules: contract-leakage review

Every figure comes from these rules, applied the same way every time. Use them to explain a figure in one or two plain sentences.

## The decisions: one card, before anything is counted

After the agreements are read and checked, the review stops once. One card holds every judgement it needs. A person with a role allowed to make them (Contracts Manager, Category Manager, Procurement Manager or Commercial Manager) chooses an option for each item, with a reason, and gives their full name. The card starts on the review's recommendation for each item, with its reason; the person keeps or changes each, and the record says which. The card is recorded whole or not at all, and nothing is counted until every item is decided.

| Item | Options | What it changes |
|---|---|---|
| **What "off contract" means** | **A** · every purchase with no contract reference / **B** · only where a contract exists for the category / **Refer it on** | Off-contract spend |
| **Each agreement the spend quotes that isn't in the folder** | **Rely on the contract register** / **Treat as uncontracted until filed** / **Refer it on** | Whether the category's purchases with no reference count under definition B |
| **Each rate rise outside its agreement's terms** | **Claim a credit note** / **Accept the rise** / **Refer it on** | Whether it's valued as a recovery and drafted as a rate query |

## What "off contract" means

| Definition | Counts | Why it matters |
|---|---|---|
| **A** | Every purchase with no contract reference | Includes categories no contract covers, which could never have been bought on contract. It overstates the problem |
| **B** | Purchases with no contract reference **in a category a contract covers**: other purchases in the category quote an agreement read in this review, or one a person decided to count on the contract register | Counts only what could have been bought on contract. The recommended reading |
| **Refer** | Nothing: the question goes to the category owner | Off-contract spend isn't counted; renewals and rate rises still are |

Off-contract spend is then shown by category and by site. The three largest categories are the **hotspots** in the referral note.

*Plain explanation:* "A purchase counts as off contract when a contract existed for that category and the purchase didn't use it."

## Agreements not in the folder

A contract reference the spend quotes whose agreement isn't among the documents. The purchases that quote it are its entry on the contract register, but its term, renewal date and rates can't be read or checked.
- **Rely on the contract register:** the category counts as contracted, so under definition B its purchases with no reference count as off contract. Buying on contract may be valued, and says the agreement isn't on file.
- **Treat as uncontracted until filed:** under definition B, its purchases with no reference aren't counted. Buying on contract isn't valued.
- **Refer it on:** as uncontracted for the figures, and listed for a decision elsewhere.
- Under definition A the choice changes no figure: A counts every purchase with no reference anyway.
- Unless it's referred, a request for the signed agreement is drafted, and its year of spend is shown as at stake.

## The renewal calendar

- Each agreement runs for its initial term from the commencement date, then renews automatically for each renewal period unless notice is given. The agreements' terms differ: read each one's own.
- **Notice deadline** = the end of the period running on the review date, less the notice days the agreement requires.
- The **review date** is the day the review starts. Every deadline is counted from it for the whole review, so the calendar doesn't move while the review runs.
- **Passed:** the deadline for the current period has gone, so the agreement **will** renew automatically when the period ends. **Due within 60 days:** the deadline falls within 60 days of the review date, and a notice of non-renewal is drafted. **Later:** more than 60 days away.

*Plain explanation:* "The last day to give notice is the end of the current period less the notice the agreement requires. Miss it and the agreement renews for another period."

## Rate rises

An agreement's rate-adjustment clause allows a rise **once a year, from the anniversary** of the commencement date, by **no more than the annual change in headline CPI for the second month before the month in which notice is given**, as published by Statistics South Africa, and only after the written notice the agreement requires has been **delivered to the contracts office**, as its notices clause says. An agreement that fixes its rates allows no rise.

The CPI the review applies is Statistics South Africa's published headline CPI, annual change, by the month it measures: a notice dated in October is allowed August's figure. With no notice, the month is counted from the first invoice at the new rate. Each rise shows the month and the figure used, on its page and in the evidence pack.

For each agreement, the rate on the earliest invoice is the starting rate. Each invoice line at a new rate is checked in this order:

| Result | When | Charged above the terms, per line |
|---|---|---|
| **No notice** | No notice of the new rate was received | The whole rise |
| **Notice outside the terms** | A notice exists, but it wasn't delivered to the contracts office (for example, an email to a buyer) | The whole rise |
| **Late notice** | The line was charged before the notice period had run | The whole rise |
| **Before the anniversary** | The line was charged before the anniversary | The whole rise |
| **Above CPI** | Notice in time, from the anniversary, but the new rate is more than CPI allows | Only the part above the allowed rate |
| **Within the terms** | Notice in time, from the anniversary, within CPI | Nothing |
| **Fixed rates** | The rate didn't change on an agreement that fixes it | Nothing |

Charged above the terms = (rate charged − rate allowed) × quantity, invoice line by invoice line, where the rate allowed is the old rate until the rise may apply, then the starting rate plus CPI. Each rise shows the date its notice gave as effective and the date it was first invoiced, separately.

- **Claim a credit note:** the amount is to recover, and a rate query is drafted giving the CPI used and the rate allowed.
- **Accept the rise:** it's listed as accepted, with nothing to recover.
- **Refer it on:** it's listed in the referral note for a decision elsewhere, and not valued.

## The drafts

- A **notice of non-renewal** for each agreement whose deadline is due within 60 days, addressed to its panel suppliers, dated, with a signature block.
- A **rate query** to each supplier whose rise was claimed, listing the invoices, the rate allowed and the credit asked for.
- A **request for the agreement** for each agreement not on file, unless it was referred on.
- A **referral note** with the three off-contract hotspots (unless the definition was referred), the agreements to obtain, and anything referred on.

All are drafts for a person to review, sign and send. Nothing is sent.

## Recommendations and what they're worth

After the findings, Claude analyses each **item** and recommends which of its **levers** to act on, with an owner. There's one item per agreement or category, so each appears once: an agreement read in this review (its renewal, its rate rise and its category's off-contract spend together), an agreement not on file, or, under definition A, a category no contract covers. The rules, not Claude, value each lever:

| Lever | Offered when | Worth |
|---|---|---|
| **Claim a credit note** | A rise outside the terms, claimed | The amount charged above the terms, recovered once |
| **Pay only the rate the agreement allows** | A claimed rise above CPI, still charged on the latest invoice | The overcharge ÷ the calendar months from its first overcharged invoice to its last, each month |
| **Pay the old rate until a proper notice has run** | A claimed rise within CPI, still charged, where only the notice was wrong | One notice period of it, once: a proper notice lets the rise apply after that |
| **Renegotiate or give notice** | The notice deadline is within 60 days | Not counted as a gain: the agreement's annual spend is shown as at stake |
| **Renegotiate the terms before the renewal** | The notice deadline passed, so the agreement will renew | Not counted as a gain: the agreement's annual spend is shown as at stake |
| **Obtain the signed agreement** | An agreement not on file, not referred | Not counted as a gain: a year of the spend that quotes it is shown as at stake |
| **Buy on the agreement, at an assumed 5% saving** | Off-contract spend in a contracted category | The category's off-contract spend each month × 5% |
| **Put an agreement in place** | Off-contract spend in a category no contract covers (definition A only) | Not counted as a gain: 12 months of it is shown as at stake |

- An agreement's **annual spend** is what was bought under its contract reference over the months the spend history covers, carried to 12 months.
- **The 5% is an assumption, not a measurement.** The review assumes that buying on contract costs 5% less than buying the same thing off it. It's the review's stated planning assumption, shown wherever it's used: every such action says "at an assumed 5% saving", and the projected gain is always split into **measured** (credit notes and paying the agreed rate) and **assumed**. This review doesn't compare prices.
- Where the agreement's own renewal is still to be decided, the value of buying on it says so: it assumes the category stays on an agreement.
- **Over the next 12 months**, each change is phased in over its first three months (a quarter, a half, then three quarters of its monthly value, then all of it), so a monthly lever is worth 10.5 months of its run-rate, and a one-off is counted once, in the third month. The projection assumes the next 12 months look like the period reviewed.
- Claude may quote only the review's own figures: the review checks every figure in the analysis before accepting it, and the release approves the analysis with the findings.

*Plain explanation:* "Each recommendation is valued by the review's own rules: an overcharge recovered once, an overcharge that stops, or 5% of the spend moved onto contract, which is an assumption. A renewal's spend is shown as at stake, never counted as a saving."

## The approvals

- The **card** is decided by one named person in a deciding role, with a reason for each item, before anything is counted.
- The **release** is approved by a *second* person, by full name, in a release role (Chief Procurement Officer, Financial Controller, Commercial Director or Chief Financial Officer), who confirms: "I have reviewed the findings, the decisions and the recommendations." No one who made a decision may approve it, and no deciding role may.
- The release is tied to a fingerprint of the approved figures and decisions, and another of the recommendations. If either changed after approval, it can't be released without approving again.
- Every step is kept in a tamper-evident record: each entry carries the fingerprint of the one before it, so any change shows. The release ends it with a fingerprint of every file filed.

## What this review never does

It sends nothing, cancels nothing and changes nothing in any system. It produces evidence, drafts and recommendations for people to act on. Its projections are its own rules applied to the period reviewed and carried forward 12 months, with moving spend onto contract valued at the stated 5% assumption; it makes no other claim about savings.
