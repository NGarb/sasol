# The project folder

Every project works from a folder with the same numbered structure. It syncs with OneDrive, so anything filed there reaches SharePoint and the team.

| In the folder | Holds | What happens to it |
|---|---|---|
| `00 Read me.md` | What the folder is and its rules | Read it if asked |
| `01 Documents/` | Source documents, such as the agreements | Read only |
| `02 Data/` | Source data: the spreadsheets | Read only |
| `03 Outputs/<review>/` | The released files, one folder per review: `Report/` (the dashboard report, the management briefing, the presentation and the one-page summary), `Evidence/` (the evidence pack, the audit trail and the data) and, where the review drafts any, `Actions/` (letters, notes, change requests) | Written by `publish`, after approval |
| `04 Records/` | One tamper-evident record per review | Written by `publish`, after approval |

## Rules

- Never change, move, rename or delete anything in `01 Documents` or `02 Data`.
- Write nothing to `03 Outputs` or `04 Records` before the release is approved. Only `publish` files there.
- Never put working files, notes or copies in the folder. The review keeps its working files in its own working space.
- Refer to places in the folder by their names ("in 03 Outputs"), never by full paths.

## Starting from the folder

Run `start --folder "<path>"`, where the path is where the project folder appears in this session: the folder that holds `00 Read me.md`, `01 Documents` and `02 Data`.

When `start` can't find the files there, or the project folder can only be reached with the file tools, work from a copy:
1. Copy the files in `01 Documents` and `02 Data` into a working folder outside the project folder, keeping those two subfolder names. Copy nothing else.
2. Run `start --folder "<that copy>" --copy`.

The review then reads the copy, and never files anything into it. Don't mention the copy.

## Filing the released results

`publish` files the results itself when it can, and reports what happened in `filed`:

- **`saved_in_folder` is true:** everything is in place. The released files are in `filed.outputs` and the record is at `filed.record`.
- **`saved_in_folder` is false:** `filed.save_to` lists each file to save and where, as [file, place in the project folder]. Save each file to its place in the project folder with the file tools, creating `03 Outputs/<review>` and its `Report`, `Evidence` and `Actions` subfolders as needed. Save nothing else. This always happens after starting from a copy.

## Checking a record later

Run `verify --file "<the project folder>/04 Records/<record file>"` and say the `tamper_check` sentence. If the project folder can only be reached with the file tools, copy the record into the working folder first and check the copy.
