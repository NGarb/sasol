# Data dictionary: contract-leakage review

## Spend history (Excel, one sheet: Spend)

| Column | Meaning |
|---|---|
| PO ID | The purchase order number |
| Vendor ID / Vendor Name | The supplier it was raised against |
| Category | What was bought |
| Site | Delivery site |
| PO Date | The order date |
| Amount Excl VAT | Order value in rand, excluding VAT |
| Contract Reference | The panel agreement it was raised under, by the agreement's own reference, or blank if none |
| Payment Date | When it was paid, blank if not yet paid. This review doesn't use it |

A contract reference whose agreement isn't among the documents is still a reference: the contract register says it exists, and the review asks whether to rely on it.

## Invoice lines (Excel, two sheets)

**Invoice lines:** the invoice lines under the panel agreements, one row each.

| Column | Meaning |
|---|---|
| Agreement Reference | The panel agreement, by its reference |
| Supplier | The panel supplier that invoiced |
| Invoice ID / Invoice Date | The invoice and its date |
| Item | The scheduled item or service |
| Quantity / Unit Rate / Line Amount | Units, the rate charged per unit, and quantity × rate, in rand |

**Rate notices:** written notices of adjusted rates.

| Column | Meaning |
|---|---|
| Agreement Reference / Supplier | Who gave notice, under which agreement |
| Notice Date | When the notice was received |
| Effective Date | When the supplier said the new rate would apply |
| Previous Unit Rate / New Unit Rate | The rate before and after |
| Received By | How it arrived. A notice counts only when it reached the contracts office, as the agreements' notices clause requires |

## Panel agreements (Word, one per category)

Each agreement gives its reference, the panel and its category, the delivery site and the commencement date, then its clauses. Agreements are numbered and laid out in their own ways: find each term by what it says, not by where it usually sits. The terms the review uses:

| Term | What the agreement says |
|---|---|
| Rates | Fixed; or adjusted once a year from the anniversary, by no more than headline CPI for the month the clause names, after written notice |
| Term and renewal | The initial term, the length of each automatic renewal, and the **notice needed to stop renewal**: each agreement's own |
| Notices | How notices must be given, and where they must be delivered, such as the contracts office |
| Payment period | Not used in this review |

## What the review files, at release

In `03 Outputs/<review>/`:

| Folder | File | Contents |
|---|---|---|
| Report | Dashboard report (HTML) | The dashboard as it stood at release, every page, with the data and the audit trail to download |
| Report | Management briefing (Word) and Presentation (PowerPoint) | The results for the next meeting, in the Sasol Design System |
| Report | One-page summary (PDF) | The findings, the decisions and who made them, and the recommended actions, with the gain split into measured and assumed |
| Evidence | Evidence pack (Excel) | Summary; off contract by category and every off-contract purchase; the agreements not on file; the renewal calendar; every rate change and every line charged above the terms; the recommendations, each with its owner, what the rules value it at and how; each agreement's terms with the clause quoted; the decisions; the record |
| Evidence | Audit trail (Excel) | Every step and decision, who made it and why, how each figure was worked out, the inputs and the controls |
| Evidence | Data (Excel) | Every row read, and every row-level result: how each purchase was counted, and each invoice line against the rate allowed |
| Actions | Draft letters (Word) | Notices of non-renewal and rate queries, on the letterhead, for a person to review, sign and send |
| Actions | Referral note (Word) | The off-contract hotspots, the agreements to obtain, and anything referred on |

The record of the review goes to `04 Records`: every step in order, each linked to the one before it; the tamper check confirms nothing changed.
