# Writing the analysis

After the findings, the step prints `analysis`: the brief. It lists the review's headline facts and, for each of its items, the facts the rules found and its **levers**: the actions the rules can value, each with what it's worth over the next 12 months and how that's worked out. Read it the way an experienced category and contract manager would, then write `claude-analysis.json` in the working folder and run `analysis --file claude-analysis.json`.

The analysis is where judgement shows. The rules have counted everything; say what it means and what to do about it.

## What good looks like

- **Explain, don't restate.** The dashboard already shows the numbers. Say what the pattern means and its most likely cause, and say so plainly when it's a likely cause rather than a fact.
- **Recommend what's worth doing.** Choose from that item's levers only, at most three, the most valuable or most urgent first. Leave out a lever that isn't worth the effort, and say why in the insight. A lever marked `risk` is never counted as a gain: it shows what's at stake, or has no rand value at all. Recommend it when the risk matters.
- **Write each action so it stands on its own:** start with a verb, name the item, and keep it to one line, for example the actions in the example below.
- **Give each action an owner** from `owners`: a team, never a person.
- **The overview** is for the executive who reads nothing else: a one-sentence headline, a short summary of what the review says about the business and where to start, and your priorities, the lever ids you recommended, most important first.
- **The voice is the project's.** Plain English, calm and specific. Never promise an outcome: say what a change *would* save, on the review's figures.
- **The release.** End with your recommendation to the approver: `approve` when every decision is recorded with its reason, the analysis stands on the review's own figures, and nothing is left unresolved; `return` when something should be reworked first, and say what. The approval card starts on it, with your reason in the box, and the approver keeps it or changes it, then names themselves and confirms the review. Write the reason as one an approver could sign: one or two sentences, 5 words or more and up to 360 characters, saying what they're approving and why it's ready. Items referred on don't stop a release: they're listed for someone with authority.

## Figures: the rule that matters

Use only figures that are in the brief: that item's facts and levers, or the review's headline facts. Quote them as given, or rounded: R4,062,118.50 as "R4.1 million", R248,610.40 as "R249,000", 41.6% as "42%". Counts and days exactly as given.

Never add, subtract, average or estimate a figure. The review totals your recommendations itself and shows the total beside your headline. Write dates as the brief writes them.

## The file

```json
{
  "overview": {
    "headline": "One sentence, up to 140 characters",
    "summary": "Up to 640 characters",
    "priorities": ["<lever id>", "<lever id>"]
  },
  "release": {
    "recommendation": "approve",
    "confidence": "high",
    "reason": "One or two sentences, up to 360 characters"
  },
  "items": {
    "<ref>": {
      "insight": "Up to 480 characters",
      "recommendations": [{"lever": "<lever id>", "action": "Up to 120 characters", "owner": "<one of owners>"}]
    }
  }
}
```

- Every item with a lever needs an insight. One without levers needs nothing.
- `priorities` holds one to five lever ids, each one you recommended.
- `release` is your recommendation for the release: `recommendation` is `approve` or `return`, `confidence` is `high`, `medium` or `low`, and `reason` is the sentence the approval card starts on, for example *"Every decision is recorded with its reason and every figure in the analysis is the review's own, so the findings are ready to release."*
- If `analysis` answers *"Fix and run again"*, correct exactly what it names and run it again, without mentioning it. It never needs a different figure than the brief has.

## Example

One item's entry, as it reads in a finished analysis. The agreement, its supplier and its figures are made up, to show the shape; the brief for each review gives its own. Here the brief gives Example Engineering's rise from R10,000.00 to R10,800.00 (8.0%) where CPI for the month its rate clause names allowed 3.5%, up to R10,350.00; R99,000.00 charged above the terms on 22 invoice lines and still charged; the decision to claim a credit note; R2,450,000.00 bought off contract in the category, all of it from suppliers outside the panel; and three levers, `AGR-0100:credit`, `AGR-0100:hold-rate` and `AGR-0100:on-contract`:

```json
"AGR-0100": {
  "insight": "Example Engineering raised its rate by 8.0% where CPI allowed 3.5%, and it is still charging R10,800.00 a unit against the R10,350.00 allowed: about R9,000 a month. Its notice was in time, so this is a pricing breach, not a paperwork one. All of the R2,450,000.00 bought off contract went to suppliers outside the panel.",
  "recommendations": [
    {"lever": "AGR-0100:hold-rate", "action": "Pay Example Engineering no more than R10,350.00 a unit on AGR-0100 invoices from now on", "owner": "Accounts payable"},
    {"lever": "AGR-0100:credit", "action": "Claim the R99,000.00 credit note from Example Engineering under AGR-0100", "owner": "Accounts payable"},
    {"lever": "AGR-0100:on-contract", "action": "Bring off-panel orders in the category onto AGR-0100 (valued at an assumed 5% saving)", "owner": "Category management"}
  ]
}
```

The items are the agreements, by reference (such as `AGR-0100`), each covering its renewal, its rate rise and its category's off-contract spend; the agreements not on file, by reference; and, under definition A only, the categories no contract covers, by name. Use the keys exactly as the brief lists them. The insight explains the pattern and its likely cause, and connects what the brief says about the item: here, a rise the supplier notified correctly but priced wrongly. "About R9,000 a month" is the lever's own monthly value, rounded; nothing is added up.

- **An action that moves spend onto contract must say it's valued at an assumed 5% saving**, as above: that value rests on the review's planning assumption, not a measurement, and the review sends back any action that doesn't say so.
- **Speak only of this review:** off-contract buying, agreements renewing, rate rises and agreements not on file. An agreement whose notice deadline has passed *will* renew; don't say it has renewed.
- **An agreement not on file** can't be checked: say so, and never write as if its terms were read.
- A lever marked `risk`, such as a renewal's spend at stake or an agreement to obtain, adds nothing to the projected gain but may matter most, because a notice deadline can't be moved. An item you recommend nothing for still needs its insight, saying why.
