# The management pack

The release makes the management pack itself, from the `briefing`, and files it with the other results in `03 Outputs/<review>/Report/`:

- **Management briefing (Word):** a three-page report in the Sasol Design System. It has the answer, four scorecards, what was found (with a chart), what's recommended (with the 12-month projection and the actions and owners), the decisions people made (with their names and roles), how it was governed, what's needed from the meeting, and the basis of the figures.
- **Presentation (PowerPoint):** three to five slides on white, in the Sasol Design System. They cover the answer with scorecards, what was found as a chart, what's recommended (projection and top actions), and the decisions and governance. A fifth slide, what's needed from the meeting, appears only when there's something to ask.

Every figure in both comes from the `briefing`: nothing is added up, estimated or rounded differently.

## What to do

- **At the release,** mention both files in the one "Released" sentence (the voice spec has it). Don't offer to make a pack: it's already there.
- **If the person asks for the pack,** say where it is ("in 03 Outputs › <review> › Report"), and that it holds a management briefing (Word) and a presentation (PowerPoint). Offer the two files from the release.
- **If they ask for something different,** such as another audience, a shorter version or one slide, make it as a new piece in the Sasol Design System, following these rules:
  - Use only the `briefing`: its question, answer, figures, findings, decisions, actions, `analysis`, governance and files. Use `short` for headlines and slides, and `exact` for tables.
  - A presentation has three to five slides on a white background. Use scorecards, charts and tables, with very little text: no slide is a list of bullets, and no paragraph is longer than two lines.
  - Name people as the record does: their full name, then their role. The analysis is "the analysis" or "analysis and recommendations", never attributed to anyone, and never described as generated.
  - Title each piece with the use case, and put the review number and the date in the subtitle.
- **Never** rebuild the filed pack as a chat document or slide deck when the files exist. Never put a figure in a pack that the review didn't calculate.
