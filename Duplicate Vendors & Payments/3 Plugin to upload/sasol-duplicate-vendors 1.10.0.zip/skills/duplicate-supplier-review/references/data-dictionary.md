# Data dictionary: duplicate-supplier review

## Supplier list (Excel, one sheet: Vendor Master)

| Column | Meaning |
|---|---|
| Vendor ID | The supplier record's number, as the supplier list gives it |
| Vendor Name | The trading name |
| Registered Name | The registered company name |
| Tax Number | The tax (VAT) number |
| Bank Account | The account payments go to |
| City | Where the supplier is based |
| Primary Category | What the supplier mainly provides |
| Created Date | When the record was created |
| Status | Active or Blocked |
| Blocked Date | When a blocked record was blocked; blank for an active one |

## Spend history (Excel, one sheet: Spend)

Purchase orders, one row each, over the period the history covers.

| Column | Meaning |
|---|---|
| PO ID | The purchase order number |
| Vendor ID / Vendor Name | The supplier record it was raised against |
| Category | What was bought |
| Site | Delivery site |
| PO Date | The order date |
| Amount Excl VAT | Order value in rand, excluding VAT |
| Contract Reference | The agreement it was raised under, if any |
| Payment Date | When it was paid; blank if not yet paid when the history was taken |

## What the review produces

Filed in `03 Outputs/<review>/` once a second person approves the release:

| Output | Contents |
|---|---|
| Dashboard report (HTML), in Report | The dashboard as it stood at release, every page, with the data and the audit trail to download as Excel |
| Management briefing (Word) and Presentation (PowerPoint), in Report | The results for the next meeting, with charts, the decisions with names and roles, and how it was governed |
| One-page summary (PDF), in Report | What was found, the decisions, the recommended actions, and what was deliberately not done |
| Evidence pack (Excel), in Evidence | Every scored pair with both records; the queued pairs' evidence field by field; every order on their records; the same-amount orders; the assessments; the decisions with names and roles; the recommendations, each with its owner and how the rules value it; the record |
| Audit trail (Excel), in Evidence | Every step and decision in order, who made it and why, how each figure was worked out, the inputs' fingerprints, and every control re-checked |
| Data (Excel), in Evidence | The supplier list and the spend history as read, every pair compared, and every pair of same-amount orders with what it counted as |
| Change request (Excel), in Actions | A draft for the supplier-list owner: one row per pair in the queue, naming both records, what the evidence shows, the requested action, and who decided and approved it |
| Draft recovery letters (Word), in Actions | Only where a payment was made twice: a draft letter to each supplier paid twice, on the letterhead, for a person to check and send |
| Record of the review, in `04 Records` | Every step in order, with the tamper check, ending with a fingerprint of every file released |
