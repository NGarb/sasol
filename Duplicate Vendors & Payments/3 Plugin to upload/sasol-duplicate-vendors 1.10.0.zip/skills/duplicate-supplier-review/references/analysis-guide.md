# Writing the analysis

After the findings, the step prints `analysis`: the brief. It lists the review's headline facts and, for each of its pairs, the facts the rules found and its **levers**: the actions the rules can value, each with what it's worth over the next 12 months and how that's worked out. Read it the way an experienced vendor master-data and fraud-risk manager would, then write `claude-analysis.json` in the working folder and run `analysis --file claude-analysis.json`.

The analysis is where judgement shows. The rules have counted everything; say what it means and what to do about it.

## What good looks like

- **Explain, don't restate.** The dashboard already shows the numbers. Say what the pattern means and its most likely cause, and say so plainly when it's a likely cause rather than a fact.
- **Recommend what's worth doing.** Choose from that pair's levers only, at most three, the most valuable or most urgent first. Leave out a lever that isn't worth the effort, and say why in the insight. A lever marked `risk` is never counted as a gain: it shows what's at stake, or has no rand value at all. Recommend it when the risk matters.
- **Write each action so it stands on its own:** start with a verb, name the pair, and keep it to one line, for example the actions in the example below.
- **Give each action an owner** from `owners`: a team, never a person.
- **The overview** is for the executive who reads nothing else: a one-sentence headline, a short summary of what the review says about the business and where to start, and your priorities, the lever ids you recommended, most important first.
- **The voice is the project's.** Plain English, calm and specific. Never promise an outcome: say what a change *would* save, on the review's figures.
- **The release.** End with your recommendation to the approver: `approve` when every decision is recorded with its reason, the analysis stands on the review's own figures, and nothing is left unresolved; `return` when something should be reworked first, and say what. The approval card starts on it, with your reason in the box, and the approver keeps it or changes it, then names themselves and confirms the review. Write the reason as one an approver could sign: one or two sentences, 5 words or more and up to 360 characters, saying what they're approving and why it's ready. Items referred on don't stop a release: they're listed for someone with authority.

## Figures: the rule that matters

Use only figures that are in the brief: that pair's facts and levers, or the review's headline facts. Quote them as given, or rounded: R4,062,118.50 as "R4.1 million", R248,610.40 as "R249,000", 41.6% as "42%". Counts and days exactly as given.

Never add, subtract, average or estimate a figure. The review totals your recommendations itself and shows the total beside your headline. Write dates as the brief writes them.

## The file

```json
{
  "overview": {
    "headline": "One sentence, up to 140 characters",
    "summary": "Up to 640 characters",
    "priorities": ["<lever id>", "<lever id>"]
  },
  "release": {
    "recommendation": "approve",
    "confidence": "high",
    "reason": "One or two sentences, up to 360 characters"
  },
  "pairs": {
    "<ref>": {
      "insight": "Up to 480 characters",
      "recommendations": [{"lever": "<lever id>", "action": "Up to 120 characters", "owner": "<one of owners>"}]
    }
  }
}
```

- Every pair with a lever needs an insight. One without levers needs nothing.
- `priorities` holds one to five lever ids, each one you recommended.
- `release` is your recommendation for the release: `recommendation` is `approve` or `return`, `confidence` is `high`, `medium` or `low`, and `reason` is the sentence the approval card starts on, for example *"Every decision is recorded with its reason and every figure in the analysis is the review's own, so the findings are ready to release."*
- If `analysis` answers *"Fix and run again"*, correct exactly what it names and run it again, without mentioning it. It never needs a different figure than the brief has.

## Example

One pair's entry, as it reads in a finished analysis. The pair, its supplier and its dates are made up, to show the shape; the brief for each review gives its own:

```json
"V999998|V999999": {
  "insight": "The close corporation's record took orders until 12 May 2024 and the (Pty) Ltd record from 2 June 2024, on the same bank account, which looks like a conversion to a company. The decision to refer it on differs from the assessment, which read them as one supplier: the tax numbers differ, so the conversion and the account should be confirmed with the supplier before either record is paid again.",
  "recommendations": [
    {"lever": "V999998|V999999:verify-bank", "action": "Confirm Example Supplies' bank account and conversion with the supplier before paying either record again", "owner": "Internal audit"}
  ]
}
```

The insight explains the pattern and its likely cause from the pair's own facts (when each record took orders, and on which account), and names the decision that differs from the assessment, as the brief's facts say. It recommends the pair's one lever, a risk whose combined spend is at stake rather than a gain, because the risk matters, and its owner is a team. It never says who wrote it.
