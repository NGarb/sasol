# Business rules: duplicate-supplier review

Every figure comes from these rules, applied the same way every time. Use them to explain a figure in one or two plain sentences.

## Which pairs are compared

Comparing every supplier with every other grows with the square of the list, and almost every comparison would be pointless. The review compares only **plausible pairs**: records that share a tax number, a bank account or the first word of their name.

## The match score (0 to 1)

| Evidence | Weight | Why |
|---|---|---|
| Same tax number | 0.45 | Identifies a legal entity |
| Same bank account | 0.35 | Says where money goes, not who owns it |
| Near-identical names (92% similar or more) | up to 0.15 | Similar names are common in a region; alone they prove little |
| Same city | 0.05 | Adds a little weight |

## The policy line: 0.35

Every pair at or above **0.35** goes to a person, which is the same as saying any shared tax number or bank account is reviewed. Raising the line means fewer reviews, but a shared bank account goes unreviewed. Lowering it queues look-alike names that share nothing else. Where the line sits is a policy choice, and the dashboard's what-if shows the trade-off without changing the review.

## The evidence a person sees

For each pair in the queue: the two records field by field (a blocked record shows the date it was blocked), each record's orders and spend, and **any orders for the same amount on both records**, to the cent, within 30 days of each other, with the date each was paid. These are shown **before** the decision, on the card and on the pair's page, so no one decides without them.

## The decisions

One person decides every pair in the queue on one card. The card starts on the assessment's recommendation for each pair, with its reason; the person keeps or changes each, and gives their full name and their role. The record says whether each decision followed the recommendation. The card is recorded whole or not at all.

| Option | Means | What it does to the figures |
|---|---|---|
| **The same supplier** | The two records are one supplier | Same-amount orders on the pair, both paid, count as **paid twice** |
| **Different suppliers** | Two suppliers that happen to share a tax number or a name | Nothing is counted. Recording it stops the pair being queued again |
| **Different suppliers · bank details verified** | Offered instead of the plain option where the pair shares a bank account but not a tax number: the person confirms each supplier's bank details were checked | Nothing is counted. The confirmation stays on both records: a shared account is never simply recorded as distinct |
| **Refer it on** | The evidence can't settle it | Nothing is counted. Shared bank details go to **forensic review**, not a verdict |

Only the roles in the delegation of authority can decide: Vendor Master Data Manager, Creditors Manager, Procurement Manager or Supplier Risk Manager. A second person, who made none of the decisions, approves the release in a senior role: Financial Controller, Head of Internal Control, Chief Risk Officer or Chief Financial Officer. They confirm they reviewed the findings, the decisions and the recommendations.

## Paid twice, and possible duplicates

- **Paid twice:** for a pair a person confirmed as one supplier, an order on each record for the same amount, to the cent, within 30 days of each other, **both paid**. It's reported as an amount to recover, with both order numbers, their dates and when each was paid.
- **Possible duplicate:** the same match on a pair that was referred on ("pending forensic review"), decided as different suppliers, or not yet paid. It's listed with its status, and **never** counted as paid twice. While one is open, the review never says nothing was paid twice.

## Recommendations and what they're worth

After the findings, the analysis looks at each pair in the review queue and recommends which of its **levers** to act on, with an owner. The rules, not the analysis, value each lever, from the pair's own orders over the months the spend history covers:

| Lever | Offered when | Worth |
|---|---|---|
| **Recover the amount paid twice** | A confirmed pair was paid twice | The amount paid twice, recovered once (counted in the third month) |
| **Merge the two records into one** | A pair is confirmed as one supplier | Where it was paid twice: the amount paid twice as a monthly run-rate, since one record means the same order can't be paid to both. Where it wasn't: the pair's combined spend is at stake, not valued |
| **Confirm each supplier's bank details** | A pair sharing a bank account is referred on | Not valued: the combined spend is at stake until each supplier confirms its bank details independently |
| **Confirm each supplier's registration and tax number** | A pair sharing only a tax number is referred on | Not valued: the combined spend is at stake until both are confirmed |
| **Hold the possible duplicate** | A referred pair has same-amount orders | Not valued: the matched amount is at stake until the forensic review concludes |
| **Keep the bank confirmation on both records** | A shared bank account is decided as different suppliers, bank details verified | Not valued: the combined spend through the shared account is at stake |
| **Record that the two are different suppliers** | A pair sharing a tax number or a name is decided as different suppliers | Not valued: it stops the pair being queued again |
| **Confirm the orders were separate work** | A pair decided as different suppliers has same-amount orders | Not valued: the matched amount is at stake until someone confirms it |

**Over the next 12 months**, each recurring change is phased in over its first three months (a quarter, a half, then three quarters of its monthly value, then all of it), so it's worth 10.5 months of its run-rate. The projection assumes the next 12 months look like the period reviewed. An amount at stake is shown, never counted as a gain; with nothing to gain, the review says so: "No gain is projected: these actions protect R… at stake." The analysis may quote only the review's own figures: the review checks every figure in it before accepting it, and the release approves the analysis with the findings. Where a decision differs from the assessment, the analysis says so.

**Plain explanation:** "Each recommendation is valued by the review's own rules: what was paid twice is recovered once, and merging the records stops it recurring at the pace of the period reviewed, phased in over the first three months. Where nothing was paid twice, the spend on the pair is shown as at stake, not as a saving."

## The scope of the figures

The figures cover only the supplier records and the orders in the project folder, over the period the spend history covers, in rand excluding VAT. They are not group totals.

## What this review never does

It never merges, blocks or recovers anything, and never changes a supplier record. The change request and the recovery letters are **drafts** for the owners of those processes, and the recommendations are for people to act on. Its projections are its own rules applied to the period reviewed and carried forward 12 months; it makes no other claim about savings. It never uses the word "fraud".
