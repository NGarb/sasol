# Assessing a pair: what to write

For each pair in the review queue, you write a short assessment that a person reads before deciding. The card starts on your recommendation, with your assessment in the reason box, and the person keeps it or changes it: so write it as a reason a person could sign, plain and specific. You may cite **only the fields in that pair's evidence**. Don't use outside knowledge, and don't guess about the companies.

## The file you write: `assessment.json`

```json
{"pairs": [
  {"pair": "V999998|V999999",
   "recommendation": "refer",
   "confidence": "low",
   "assessment": "Only the bank account is shared; the tax numbers, names and cities all differ, so the evidence can't show they are one company.",
   "cites": ["Bank Account", "Tax Number", "Vendor Name", "City"]}
]}
```

One entry for **every pair in the queue**. The example is illustrative. Its fields:

| Field | Write |
|---|---|
| `pair` | The pair's number exactly as the evidence gives it (`first|second`) |
| `recommendation` | `same` (one supplier), `different` (two suppliers) or `refer` (the evidence can't settle it) |
| `confidence` | `high`, `medium` or `low` |
| `assessment` | One or two plain sentences, 60 words at most, naming the fields that matter |
| `cites` | The evidence fields you relied on, spelled as the evidence spells them: Vendor Name, Registered Name, Tax Number, Bank Account, City, Primary Category, Created Date, Status, Orders, Spend, Same-amount orders |

## How to weigh the evidence

- **A shared tax number** identifies one legal entity: strong evidence of the same supplier. When nothing else matches (names, trades, towns and bank accounts all differ, and each record has its own orders), the likelier story is a tax number captured on the wrong record: recommend `different`.
- **A trading name against a registered name**: when one record's Vendor Name is the other's Registered Name, and the tax number is the same, it's one company.
- **A shared bank account** says where money goes, not who owns it. Payment agents and group treasuries share accounts. On its own it's not enough, so recommend `refer` with `low` confidence. Two long-standing companies in different trades that share an account may be one group paid through its treasury: say so, and say it should be confirmed.
- **Related names, the same city and the same category** support a shared account, but don't prove it. That calls for medium confidence at most. A close corporation and a (Pty) Ltd with near-identical names, one taking over from the other, suggests a conversion, which carries a new tax number: it still needs confirming.
- **Names differing only by a legal suffix** ("(Pty) Ltd", "CC") are the same name.
- **A blocked record:** the Status gives the date it was blocked. A new record created soon after, with the same tax number, is a dormant duplicate: the old record should be closed, not reopened. A blocked record's bank account turning up on a new supplier is for forensic review.
- **Same-amount orders:** an order on each record for the same amount within 30 days is the strongest sign that one supplier was paid twice. Cite `Same-amount orders` and name both orders. It supports `same`, but never decide for the person.
- Never say or imply wrongdoing. Recommend, cite and state your confidence. The person decides.
