"""Duplicate-supplier review rules. Every figure the review reports comes from here.

Definitions (see references/business-rules.md):
  match score    0.45 same tax number + 0.35 same bank account + 0.15 x name similarity (only when the
                 names are near-identical, 92% or more) + 0.05 same city. Between 0 and 1, to two decimals
  review queue   every pair scoring at or above the policy threshold (0.35): a person decides each one
  same amount    for every pair in the queue, before the decision: an order on each record for the same amount, to the
                 cent, within 30 days of each other. It's evidence for the person deciding
  paid twice     a same-amount match on a pair a person confirmed as one supplier, with both orders paid. Matches on
                 pairs referred on, or decided as different suppliers, or not yet paid, are possible duplicates:
                 listed with their status, never counted as paid twice
  combined spend a pair's spend on both of its records, over the whole spend history
  bank-linked    a pair that shares a bank account but not a tax number. Deciding it's two suppliers means the bank
                 details were verified, so the option says so, and it's never simply recorded as distinct
Levers, for the analysis (valued per pair in the review queue, over the months the spend history covers):
  recover        confirmed, paid twice: the amount paid twice, recovered once
  merge          confirmed: with the two records merged, the same order can't be paid to both. Where payments were
                 made twice, worth their monthly run-rate (amount paid twice / months), assuming the next 12 months
                 look like the period reviewed; where none were, the combined spend is at stake, not valued
  verify-bank    referred, bank-linked: the combined spend is at stake until each supplier confirms its bank details
                 independently, not valued
  verify-tax     referred, sharing a tax number: the combined spend is at stake until each supplier's registration and
                 tax number are confirmed, not valued
  hold           referred, with a same-amount match: the possible duplicate is at stake until the forensic review
                 concludes, not valued
  keep-proof     decided as different suppliers with the bank details verified: the combined spend is at stake while
                 two suppliers share one account, so the confirmation stays on both records, not valued
  mark-distinct  decided as different suppliers, not bank-linked: recording that stops the pair being queued again,
                 not valued
  check-orders   decided as different suppliers, with a same-amount match: the matching orders are at stake until
                 someone confirms they were separate work, not valued
Nothing is decided here: the review scores, gathers evidence and counts. People decide.
"""
from __future__ import annotations

import datetime as dt
import difflib
import re
from collections import defaultdict
from itertools import combinations
from pathlib import Path

import ooxml

WEIGHTS = {"tax": 0.45, "bank": 0.35, "name": 0.15, "city": 0.05}
NAME_BAR = 0.92
POLICY = 0.35
FLOOR = 0.10                      # pairs below this aren't worth showing, even on the what-if
TWICE_WITHIN_DAYS = 30
VENDOR_COLUMNS = ["Vendor ID", "Vendor Name", "Registered Name", "Tax Number", "Bank Account", "City", "Primary Category", "Created Date", "Status"]
SPEND_COLUMNS = ["PO ID", "Vendor ID", "Vendor Name", "Category", "Site", "PO Date", "Amount Excl VAT", "Contract Reference"]
FIELDS = ["Vendor Name", "Registered Name", "Tax Number", "Bank Account", "City", "Primary Category", "Created Date", "Status"]
SAME_AMOUNT = "Same-amount orders"
BUNDLE_FIELDS = set(FIELDS) | {"Orders", "Spend", SAME_AMOUNT}
STOP = {"pty", "ltd", "limited", "holdings", "cc", "inc", "the"}
OPTIONS = {"same": "The same supplier", "different": "Different suppliers", "refer": "Refer it on"}
VERIFIED = "Different suppliers · bank details verified"


def _load(path: Path, columns: list[str], what: str) -> list[dict]:
    rows = ooxml.read_xlsx(path)
    missing = [c for c in columns if rows and c not in rows[0]]
    if not rows or missing:
        raise ValueError(f"The {what} doesn't have the expected columns: " + ", ".join(missing or columns))
    return rows


def load_vendors(path: Path) -> list[dict]:
    """The supplier list. A blocked record may carry the date it was blocked (Blocked Date)."""
    rows = _load(path, VENDOR_COLUMNS, "supplier list")
    for r in rows:
        r["blocked_on"] = r.get("Blocked Date") or None
    return rows


def load_spend(path: Path) -> list[dict]:
    """The spend history. An order may carry the date it was paid (Payment Date); blank means not yet paid."""
    rows = _load(path, SPEND_COLUMNS, "spend history")
    for r in rows:
        r["amount"] = round(float(r["Amount Excl VAT"]), 2)
        r["paid"] = r.get("Payment Date") or None
    return rows


def norm(name: str) -> str:
    return " ".join(w for w in re.sub(r"[^a-z0-9 ]", " ", str(name).lower()).split() if w not in STOP)


def name_similarity(a: str, b: str) -> float:
    return round(difflib.SequenceMatcher(None, norm(a), norm(b)).ratio(), 3)


def score_pair(x: dict, y: dict) -> dict:
    sim = name_similarity(x["Vendor Name"], y["Vendor Name"])
    agree = dict(tax=x["Tax Number"] == y["Tax Number"], bank=x["Bank Account"] == y["Bank Account"],
                 name=sim >= NAME_BAR, city=x["City"] == y["City"])
    score = WEIGHTS["tax"] * agree["tax"] + WEIGHTS["bank"] * agree["bank"] + (WEIGHTS["name"] * sim if agree["name"] else 0) + WEIGHTS["city"] * agree["city"]
    return dict(a=x["Vendor ID"], b=y["Vendor ID"], score=round(score, 2), similarity=sim, agree=agree)


def kind(p: dict) -> str:
    """In words: what the pair shares."""
    g = p["agree"]
    if g["tax"]:
        return "tax number and bank account" if g["bank"] else "tax number"
    if g["bank"]:
        extra = [w for w, k in (("name", "name"), ("city", "city")) if g[k]]
        return "bank account and " + " and ".join(extra) if extra else "bank account only"
    return "similar names only"


def bank_linked(p: dict) -> bool:
    """A shared bank account without a shared tax number: calling them two suppliers needs the bank details verified."""
    return p["agree"]["bank"] and not p["agree"]["tax"]


def options(p: dict) -> dict:
    """The decision's options for a pair: for a bank-linked pair, "different" means the bank details were verified."""
    return {**OPTIONS, **({"different": VERIFIED} if bank_linked(p) else {})}


def candidates(vendors: list[dict]) -> tuple[list[dict], int]:
    """Only pairs that could plausibly match are compared: sharing a tax number, a bank account or the
    first word of the name. Returns the pairs scoring at least FLOOR, best first, and how many were compared."""
    groups = defaultdict(set)
    for i, v in enumerate(vendors):
        groups["tax:" + str(v["Tax Number"])].add(i)
        groups["bank:" + str(v["Bank Account"])].add(i)
        first = norm(v["Vendor Name"]).split()
        if first:
            groups["name:" + first[0]].add(i)
    pairs = set()
    for g in groups.values():
        pairs.update(combinations(sorted(g), 2))
    scored = [score_pair(vendors[a], vendors[b]) for a, b in pairs]
    keep = sorted((p for p in scored if p["score"] >= FLOOR), key=lambda p: (-p["score"], p["a"], p["b"]))
    for p in keep:
        p["id"] = f"{p['a']}|{p['b']}"
        p["kind"] = kind(p)
    return keep, len(pairs)


def spend_by_vendor(spend: list[dict]) -> dict[str, dict]:
    out = defaultdict(lambda: dict(orders=0, value=0.0, first=None, last=None))
    for r in spend:
        s = out[r["Vendor ID"]]
        s["orders"] += 1
        s["value"] = round(s["value"] + r["amount"], 2)
        d = r["PO Date"]
        s["first"] = d if s["first"] is None or d < s["first"] else s["first"]
        s["last"] = d if s["last"] is None or d > s["last"] else s["last"]
    return out


def status(v: dict) -> str:
    """A record's status as the evidence shows it: Active, or Blocked with the date it was blocked."""
    d = v.get("blocked_on")
    return f"Blocked on {day(d)}" if v["Status"] == "Blocked" and isinstance(d, dt.date) else str(v["Status"])


def matches(spend: list[dict], a: str, b: str) -> list[dict]:
    """Orders on both records for the same amount, to the cent, within TWICE_WITHIN_DAYS: evidence for every pair in
    the queue, before anyone decides. `paid` says whether both orders were paid."""
    xa = [r for r in spend if r["Vendor ID"] == a]
    xb = [r for r in spend if r["Vendor ID"] == b]
    out = []
    for r in xa:
        for s in xb:
            gap = abs((s["PO Date"] - r["PO Date"]).days)
            if r["amount"] == s["amount"] and gap <= TWICE_WITHIN_DAYS:
                first, second = sorted((r, s), key=lambda q: (q["PO Date"], q["PO ID"]))
                out.append(dict(amount=r["amount"], orders=[first["PO ID"], second["PO ID"]], dates=[iso(first["PO Date"]), iso(second["PO Date"])],
                                paid_on=[iso(first["paid"]) if first["paid"] else "", iso(second["paid"]) if second["paid"] else ""],
                                paid=bool(first["paid"] and second["paid"]), records=[first["Vendor ID"], second["Vendor ID"]],
                                days_apart=gap, category=first["Category"], site=first["Site"]))
    return sorted(out, key=lambda d: -d["amount"])


def bundle(pair: dict, by_id: dict[str, dict], spend_ix: dict[str, dict], spend: list[dict]) -> dict:
    """The evidence for one pair, field by field, with any same-amount orders. The assessment may cite only these fields."""
    x, y = by_id[pair["a"]], by_id[pair["b"]]
    rows = []
    for f in FIELDS:
        va, vb = x[f], y[f]
        if f in ("Vendor Name", "Registered Name"):
            s = name_similarity(va, vb)
            rows.append(dict(field=f, a=va, b=vb, agrees=s >= NAME_BAR, note=f"{round(s * 100)}% similar"))
        elif f == "Status":
            rows.append(dict(field=f, a=status(x), b=status(y), agrees=va == vb, note=""))
        else:
            rows.append(dict(field=f, a=str(va), b=str(vb), agrees=va == vb, note=""))
    sa, sb = spend_ix.get(pair["a"], {}), spend_ix.get(pair["b"], {})
    for label, key in (("Orders", "orders"), ("Spend", "value")):
        rows.append(dict(field=label, a=sa.get(key, 0), b=sb.get(key, 0), agrees=None, note=""))
    found = matches(spend, pair["a"], pair["b"])
    side = lambda m, k: f"{m['orders'][k]}, {day(m['dates'][k])}, R{m['amount']:,.2f}, " + (f"paid {day(m['paid_on'][k])}" if m["paid_on"][k] else "not yet paid")
    mine = lambda m, rec: m["records"].index(rec)
    rows.append(dict(field=SAME_AMOUNT, a="; ".join(side(m, mine(m, pair["a"])) for m in found) or "None within 30 days",
                     b="; ".join(side(m, mine(m, pair["b"])) for m in found) or "None within 30 days", agrees=None,
                     note="; ".join(f"{m['days_apart']} days apart" for m in found)))
    return dict(pair=pair["id"], a=pair["a"], b=pair["b"], names=[x["Vendor Name"], y["Vendor Name"]], score=pair["score"], shares=pair["kind"],
                bank_linked=bank_linked(pair), agree=pair["agree"], fields=rows, matches=found)


def combined(spend_ix: dict[str, dict], a: str, b: str) -> float:
    """A pair's spend on both of its records, over the whole spend history."""
    return round(spend_ix.get(a, {}).get("value", 0) + spend_ix.get(b, {}).get("value", 0), 2)


STATUS = {"refer": "pending forensic review", "different": "decided as different suppliers", "unpaid": "not yet paid"}


def consequences(spend: list[dict], queue: list[dict], decisions: dict[str, str], spend_ix: dict[str, dict]) -> dict:
    """After every decision: payments made twice, for confirmed pairs with both orders paid; every other same-amount match
    is a possible duplicate with its status, never counted as paid twice. Referrals and clearances listed."""
    confirmed, referred, cleared, twice, possible = [], [], [], [], []
    for p in queue:
        d, found, both = decisions[p["id"]], matches(spend, p["a"], p["b"]), combined(spend_ix, p["a"], p["b"])
        if d == "same":
            paid = [m for m in found if m["paid"]]
            twice += [dict(m, pair=p["id"]) for m in paid]
            possible += [dict(m, pair=p["id"], status=STATUS["unpaid"]) for m in found if not m["paid"]]
            confirmed.append(dict(pair=p["id"], combined=both, paid_twice=round(sum(m["amount"] for m in paid), 2), count=len(paid)))
        elif d == "refer":
            possible += [dict(m, pair=p["id"], status=STATUS["refer"]) for m in found]
            referred.append(dict(pair=p["id"], shares=p["kind"], combined=both))
        else:
            possible += [dict(m, pair=p["id"], status=STATUS["different"]) for m in found]
            cleared.append(dict(pair=p["id"], shares=p["kind"], combined=both, verified=bank_linked(p)))
    return dict(confirmed=confirmed, referred=referred, cleared=cleared, paid_twice=twice,
                total_twice=round(sum(t["amount"] for t in twice), 2), orders_twice=len(twice),
                possible=possible, total_possible=round(sum(t["amount"] for t in possible), 2))


def headline(c: dict) -> dict:
    """Only what's needed to fingerprint the release."""
    return dict(confirmed=sorted(x["pair"] for x in c["confirmed"]), referred=sorted(x["pair"] for x in c["referred"]),
                cleared=sorted(x["pair"] for x in c["cleared"]), total_twice=c["total_twice"], orders_twice=c["orders_twice"],
                possible=sorted(f"{t['pair']}:{'+'.join(t['orders'])}:{t['status']}" for t in c["possible"]), total_possible=c["total_possible"])


def iso(d) -> str:
    return d.isoformat() if isinstance(d, (dt.date, dt.datetime)) else str(d)


def day(d) -> str:
    """A date as the evidence shows it: 9 Mar 2026."""
    d = d if isinstance(d, dt.date) else dt.date.fromisoformat(str(d)[:10])
    return f"{d.day} {d:%b %Y}"


# ------------------------------------------------------------------ for the analysis
def period_months(spend: list[dict]) -> int:
    """How many calendar months the spend history covers, by purchase-order date."""
    first, last = min(r["PO Date"] for r in spend), max(r["PO Date"] for r in spend)
    return (last.year - first.year) * 12 + last.month - first.month + 1


def levers(decision: str, pair: dict, twice: float, possible: float, spend_both: float, months: int) -> list[tuple[str, str, float]]:
    """A pair's levers, valued by the rules in the docstring: (key, kind, amount). A recurring amount is a monthly
    run-rate; a one-off is recovered once; a risk is the amount at stake, never counted as a gain."""
    if decision == "same":
        if twice:
            return [("recover", "one-off", twice), ("merge", "recurring", twice / months)]
        return [("merge", "risk", spend_both)]
    if decision == "refer":
        out = [("verify-bank" if pair["agree"]["bank"] else "verify-tax", "risk", spend_both)]
        return out + ([("hold", "risk", possible)] if possible else [])
    out = [("keep-proof", "risk", spend_both)] if bank_linked(pair) else [("mark-distinct", "risk", 0.0)]
    return out + ([("check-orders", "risk", possible)] if possible else [])
