"""The review's own files, written when the release is published: the evidence pack and the change request (Excel),
draft recovery letters (Word, on the letterhead, only where a payment was made twice) and the one-page summary (PDF).
Only ever called through Review.publish(), which refuses unless the release was approved (the findings and the
recommendations together). Nothing here merges, blocks or recovers anything: every file is a draft or a request for a
person. Every sheet names both records of each pair, with its own header row."""
from __future__ import annotations

import datetime as dt
from pathlib import Path

import logic
import office
import ooxml
import pdf
import skillkit as kit

HERE = Path(__file__).resolve().parent
day = lambda iso: logic.day(iso) if iso else ""


def write(out: Path, review, c: dict, pairs: list, evidence: list, assessment: dict, vendors: list, spend: list,
          advice: list[list], totals: dict, labels: dict) -> list[str]:
    st = review.state
    rid, rel = st["review_id"], st.get("release") or {}
    by_id = {v["Vendor ID"]: v for v in vendors}
    name = lambda i: by_id[i]["Vendor Name"] if i in by_id else i
    decisions = {k.split(":", 1)[1]: v for k, v in st["decisions"].items()}
    ev = {b["pair"]: b for b in evidence}
    s = st["summary"]
    deciders = "; ".join(sorted({kit.by(d) for d in decisions.values()}))
    summary = [["Review", rid], ["Supplier records", s["vendors"]], ["Purchase orders", s["lines"]], ["Spend (R, excluding VAT)", s["value"]],
               ["Pairs compared", st.get("compared", 0)], [f"Pairs scoring {logic.FLOOR} or more", len(pairs)], ["Policy line", logic.POLICY],
               ["Pairs in the review queue", len(evidence)], ["Pairs with same-amount orders, shown before the decisions", sum(bool(b["matches"]) for b in evidence)],
               ["Confirmed as the same supplier", len(c["confirmed"])], ["Referred on", len(c["referred"])], ["Decided as different suppliers", len(c["cleared"])],
               ["Paid twice (R)", c["total_twice"]], ["Payments made twice", c["orders_twice"]], ["Possible duplicates, not counted (R)", c["total_possible"]],
               ["Projected gain from the recommendations, 12 months (R)", totals["gain12"]], ["At stake (R)", totals["at_risk"]],
               ["Decided by", deciders], ["Approved by", kit.by(rel)], ["Approver's confirmation", rel.get("reviewed", "")],
               ["Scoring", "0.45 same tax number + 0.35 same bank account + 0.15 x name similarity (names 92% alike or more) + 0.05 same city"],
               ["Paid twice", "Orders on both records of a pair confirmed as one supplier, for the same amount to the cent, within 30 days, both paid"]]
    pair_cols = lambda pid: [pid.split("|")[0], name(pid.split("|")[0]), pid.split("|")[1], name(pid.split("|")[1])]
    scored = [[*pair_cols(p["id"]), p["score"], p["kind"], "Yes" if p["score"] >= logic.POLICY else "No", (decisions.get(p["id"]) or {}).get("label", "")] for p in pairs]
    ev_rows = [[*pair_cols(b["pair"]), x["field"], logic.iso(x["a"]), logic.iso(x["b"]), "" if x["agrees"] is None else ("Agrees" if x["agrees"] else "Differs"), x["note"]]
               for b in evidence for x in b["fields"]]
    other = {}
    for b in evidence:
        for m in b["matches"]:
            other[m["orders"][0]], other[m["orders"][1]] = m["orders"][1], m["orders"][0]
    orders = [[b["pair"], o["Vendor ID"], o["Vendor Name"], o["PO ID"], o["PO Date"], o["Site"], o["Category"], o["amount"], o["Contract Reference"] or "",
               o["paid"] or "", other.get(o["PO ID"], "")]
              for b in evidence for o in sorted((o for o in spend if o["Vendor ID"] in (b["a"], b["b"])), key=lambda o: (o["Vendor ID"], o["PO Date"], o["PO ID"]))]
    counted = {t["orders"][0]: "Paid twice" for t in c["paid_twice"]} | {t["orders"][0]: "Possible duplicate, " + t["status"] for t in c["possible"]}
    same = [[*pair_cols(b["pair"]), m["amount"], m["orders"][0], m["dates"][0], m["paid_on"][0], m["records"][0], m["orders"][1], m["dates"][1], m["paid_on"][1],
             m["records"][1], m["days_apart"], counted.get(m["orders"][0], "")] for b in evidence for m in b["matches"]]
    ass = [[*pair_cols(pid), logic.OPTIONS[a["recommendation"]], a["confidence"], a["assessment"], ", ".join(a["cites"])] for pid, a in assessment.items()]
    decs = [[*pair_cols(pid), d["label"], d["reason"], d.get("name", ""), d["role"], _when(d["at"]), d["shown"][:16],
             "" if (assessment.get(pid) or {}).get("recommendation") == d["option"] else "Yes: the assessment recommended " + logic.OPTIONS[assessment[pid]["recommendation"]].lower()]
            for pid, d in decisions.items()]
    record = [[e["seq"], *_when(e["at"]).rsplit(" ", 1), kit.event_label(e, labels), "The review" if e["actor"] == "system" else e["actor"],
               (e.get("data") or {}).get("role", "") if e["actor"] != "system" else "", e["fingerprint"][:16]] for e in review.entries()]
    record.append(["", "", "", "Continued in the audit trail: publishing and a fingerprint of every file released", "", "", ""])
    pack = out / f"Evidence pack {rid}.xlsx"
    ooxml.write_xlsx(pack, [
        {"name": "Summary", "headers": ["Item", "Value"], "rows": summary, "widths": [52, 110]},
        {"name": "Scored pairs", "headers": ["First record", "First supplier", "Second record", "Second supplier", "Score", "Shares", "In the queue", "Decision"],
         "rows": scored, "widths": [12, 36, 12, 36, 8, 30, 12, 40]},
        {"name": "Evidence", "headers": ["First record", "First supplier", "Second record", "Second supplier", "Field", "First", "Second", "Result", "Note"],
         "rows": ev_rows, "widths": [12, 34, 12, 34, 20, 44, 44, 10, 16]},
        {"name": "Orders on the queued pairs", "headers": ["Pair", "Record", "Supplier", "Order", "Order date", "Site", "Category", "Amount excl VAT",
                                                           "Contract reference", "Payment date", "Same amount on the other record"],
         "rows": orders, "money": {"Amount excl VAT"}, "widths": [18, 10, 36, 12, 12, 11, 28, 16, 14, 13, 20]},
        {"name": "Same-amount orders", "headers": ["First record", "First supplier", "Second record", "Second supplier", "Amount", "First order", "First order date",
                                                   "First paid", "First order's record", "Second order", "Second order date", "Second paid", "Second order's record",
                                                   "Days apart", "Counted as"],
         "rows": same, "money": {"Amount"}, "widths": [12, 30, 12, 30, 14, 12, 13, 12, 12, 12, 13, 12, 12, 10, 40]},
        {"name": "Assessments", "headers": ["First record", "First supplier", "Second record", "Second supplier", "Recommendation", "Confidence", "Assessment",
                                            "Fields cited"], "rows": ass, "widths": [12, 30, 12, 30, 20, 11, 80, 40]},
        {"name": "Decisions", "headers": ["First record", "First supplier", "Second record", "Second supplier", "Decision", "Reason", "Name", "Role",
                                          "When (SAST)", "Fingerprint of the evidence shown", "Differs from the assessment"],
         "rows": decs, "widths": [12, 30, 12, 30, 34, 50, 22, 28, 18, 20, 44]},
        {"name": "Recommendations", "headers": ["Pair", "Suppliers", "Recommended action", "Owner", "Kind", "Projected gain, 12 months", "At stake",
                                                "How the rules value it", "Analysis of the pair"],
         "rows": advice or [], "money": {"Projected gain, 12 months", "At stake"}, "widths": [18, 50, 50, 20, 11, 16, 14, 70, 90]},
        {"name": "Record", "headers": ["#", "Date", "Time (SAST)", "Step", "By", "Role", "Fingerprint"], "rows": record, "widths": [5, 12, 12, 46, 26, 28, 20]},
    ])
    written = [pack.name]
    change = out / f"Change request {rid}.xlsx"
    ooxml.write_xlsx(change, [{"name": "Change request", "headers": ["Request", "First record", "First supplier", "First status", "Second record", "Second supplier",
                                                                      "Second status", "What the evidence shows", "Requested action", "Decided by", "Decider's role",
                                                                      "Approved by", "Approver's role", "State"],
                               "rows": _requests(c, ev, by_id, decisions, rel), "widths": [30, 10, 32, 22, 10, 32, 22, 44, 70, 20, 26, 20, 22, 8]}])
    written.append(change.name)
    if c["paid_twice"]:
        written.append(_letters(out / f"Draft recovery letters {rid}.docx", rid, c, by_id, decisions))
    _summary(out / f"One-page summary {rid}.pdf", st, c, evidence, decisions, name, advice or [], totals)
    written.append(f"One-page summary {rid}.pdf")
    return written


def _when(at: str) -> str:
    """A recorded moment in South African time: 26 Sep 2026 10:42."""
    t = dt.datetime.fromisoformat(at).astimezone(kit.SAST)
    return f"{t.day} {t:%b %Y %H:%M}"


def _requests(c: dict, ev: dict, by_id: dict, decisions: dict, rel: dict) -> list[list]:
    """The change request: one row per pair in the queue, naming both records, for the owner of the supplier list."""
    rows = []
    for pid, d in decisions.items():
        b, (x, y) = ev[pid], (by_id[i] for i in pid.split("|"))
        shows = logic.kind(b) + ("; same-amount orders on both" if b["matches"] else "")
        if d["option"] == "same":
            blocked = [v for v in (x, y) if v["Status"] == "Blocked"]
            keep = next(v for v in (x, y) if v not in blocked) if blocked else None
            want, action = "Keep one record: the same supplier", (
                f"Keep {keep['Vendor ID']}; close {blocked[0]['Vendor ID']}, blocked since {logic.day(blocked[0]['blocked_on'])}, for good" if blocked and keep
                else "Review the two records and keep one, following the supplier-master procedure; move open orders to the record kept")
            if any(t["pair"] == pid for t in c["paid_twice"]):
                action += ". Recover the amount paid twice first (see the draft recovery letters)"
        elif d["option"] == "refer":
            want, action = (("Forensic review of the shared bank details", "Confirm the bank account with each supplier independently before paying either again; "
                                                                          "change neither record until the review concludes") if b["agree"]["bank"] else
                            ("Confirm the registration", "Confirm each supplier's registration and tax number before paying either again; change neither record until then"))
        elif logic.bank_linked(b):
            want, action = "Keep the bank confirmation", "File the bank confirmation on both records, and flag the shared account for checks before each payment"
        else:
            want, action = "Correct the tax number", "Correct the tax number on the record that carries it wrongly, and record that the two are different suppliers"
        rows.append([want, x["Vendor ID"], x["Vendor Name"], logic.status(x), y["Vendor ID"], y["Vendor Name"], logic.status(y), shows, action,
                     d.get("name", ""), d["role"], rel.get("name", ""), rel.get("role", ""), "Draft"])
    return rows


def _letters(path: Path, rid: str, c: dict, by_id: dict, decisions: dict) -> str:
    """One draft recovery letter per pair paid twice, each on the letterhead, for a person to check and send."""
    blocks, by_pair = [], {}
    for t in c["paid_twice"]:
        by_pair.setdefault(t["pair"], []).append(t)
    for i, (pid, ts) in enumerate(by_pair.items()):
        x, y = (by_id[r] for r in pid.split("|"))
        d, total = decisions[pid], round(sum(t["amount"] for t in ts), 2)
        to = x["Registered Name"] + (f" and {y['Registered Name']}" if y["Registered Name"] != x["Registered Name"] else "")
        blocks += [("pagebreak",)] if i else []
        blocks += [("title", "Request to recover a duplicate payment"),
                   ("p", f"**To:** {to}, supplier records {x['Vendor ID']} ({x['Vendor Name']}) and {y['Vendor ID']} ({y['Vendor Name']})"),
                   ("p", "Our records show purchase orders for the same amount, each paid, against two supplier records that our review has confirmed belong to one supplier:"),
                   ("table", ["Order", "Order date", "Paid", "Supplier record", "Amount excl VAT"],
                    [[t["orders"][k], day(t["dates"][k]), day(t["paid_on"][k]), f"{t['records'][k]} {by_id[t['records'][k]]['Vendor Name']}", kit.rand(t["amount"])]
                     for t in ts for k in (0, 1)]),
                   ("p", f"Please confirm the duplicate and issue a credit note or refund of **{kit.rand(total)}** excluding VAT, with the VAT charged on it, "
                         "within 14 days, quoting the order numbers."),
                   ("p", "If you believe the orders were for separate goods or services, please send the delivery evidence for each, and we'll review it."),
                   ("small", f"Prepared from review {rid}. The decision that these records are one supplier was made by {kit.by(d)}, and is on the record of the review.")]
    logo = HERE.parent / "assets" / "sasol-logo.png"
    office.write_document(path, blocks, {"title": "Request to recover a duplicate payment", "subtitle": f"Draft for review before sending · review {rid}",
                                         "footer": f"Duplicate Vendors & Payments · review {rid} · draft"}, logo.read_bytes() if logo.exists() else None)
    return path.name


def _summary(path: Path, st: dict, c: dict, evidence: list, decisions: dict, name, advice: list[list], totals: dict) -> None:
    d = pdf.Pdf()
    d.rect(0, 0, pdf.PAGE_W, 104, fill=pdf.NAVY)
    d.rect(0, 104, pdf.PAGE_W, 3, fill=pdf.CYAN)
    d.text(40, 44, "Duplicate supplier review", 22, True, pdf.WHITE)
    d.text(40, 72, f"One-page summary · review {st['review_id']}", 11, False, (0.89, 0.92, 0.95))
    s, rel = st["summary"], st.get("release") or {}
    fourth = (("Possible duplicates", f"R{c['total_possible']:,.2f}", "not counted as paid twice") if c["possible"]
              else ("Supplier records", f"{s['vendors']:,}", f"{s['lines']:,} orders"))
    tiles = [("Paid twice", f"R{c['total_twice']:,.2f}", f"{c['orders_twice']} payments"), ("Confirmed pairs", str(len(c["confirmed"])), "the same supplier"),
             ("Referred on", str(len(c["referred"])), "for review"), fourth]
    x = 40
    for label, value, sub in tiles:
        d.rect(x, 124, 122, 74, fill=pdf.PALE, stroke=pdf.LINE)
        d.text(x + 10, 142, label.upper(), 7.5, True, pdf.MUTE)
        d.text(x + 10, 166, value, 13, True, pdf.CORP)
        d.text(x + 10, 184, sub, 8.5, False, pdf.MUTE)
        x += 130
    y = 226
    d.text(40, y, "What the review found", 13, True, pdf.CORP)
    y += 18
    lines = [f"{s['vendors']:,} supplier records and {s['lines']:,} purchase orders worth R{s['value']:,.2f} were reviewed; {st.get('compared', 0):,} plausible pairs "
             f"were compared, and {len(evidence)} reached the policy line of {logic.POLICY}."]
    by_pair = {}
    for t in c["paid_twice"]:
        by_pair.setdefault(t["pair"], []).append(t)
    lines += [f"R{sum(t['amount'] for t in ts):,.2f} was paid twice on {' and '.join(name(i) for i in pid.split('|'))} ("
              + "; ".join(f"{t['orders'][0]} and {t['orders'][1]}, {t['days_apart']} days apart" for t in ts) + ")." for pid, ts in by_pair.items()]
    lines += [f"R{t['amount']:,.2f} on {' and '.join(name(i) for i in t['pair'].split('|'))} is a possible duplicate, {t['status']}: not counted as paid twice."
              for t in c["possible"]]
    for ln in lines:
        y = d.paragraph(52, y, "• " + ln, 500, 9.5)
    y += 8
    d.text(40, y, "Decisions", 13, True, pdf.CORP)
    y += 18
    for pid, v in decisions.items():
        y = d.paragraph(52, y, f"• {' / '.join(name(i) for i in pid.split('|'))}: {v['label'].lower().replace(' · ', ', with the ')}. \"{v['reason']}\"", 500, 9)
    who = "; ".join(sorted({kit.by(v) for v in decisions.values()}))
    y = d.paragraph(52, y + 2, f"Decided by {who}." + (f" Release {rel['status']} by {kit.by(rel)}: \"{rel.get('reason')}\"." if rel.get("name") else ""), 500, 9, color=pdf.MUTE)
    letters = " and the recovery letters" if c["paid_twice"] else ""
    closing = (f"Nothing was merged, blocked or recovered. The change request{letters} {'are' if letters else 'is a'} draft{'s' if letters else ''} for the owners of those "
               "processes, and shared bank details go to forensic review.")
    tall = lambda text, width, size: len(pdf.wrap(text, width, size)) * size * 1.35
    bottom = 772 - tall(closing, 515, 9.5)                       # the recommendations go in only where they fit above it
    gain, stake = totals["gain12"], totals["at_risk"]
    note = ("Recommended in the analysis and approved with the findings. Each value comes from the review's own rules: the next 12 months at the pace "
            "of the period reviewed, each change phased in over three months. An amount at stake is shown, never counted as a gain." if gain else
            f"No gain is projected: these actions protect R{stake:,.2f} at stake. Recommended in the analysis and approved with the findings.")
    rows = []
    for ref, pair, action, owner, kind, g, risk, *_ in advice[:6]:
        text = action if pair.split()[0].lower() in action.lower() else f"{pair}: {action}"
        rows.append(f"• {text} · {owner} · " + (f"R{g:,.2f}" if g else f"R{risk:,.2f} at stake" if risk else "stops repeat flags"))
    if rows and y + 40 + tall(rows[0], 500, 9.5) + tall(note, 500, 8.5) <= bottom:
        y += 10
        d.text(40, y, "Recommended actions", 13, True, pdf.CORP)
        if gain:
            d.text(555, y, f"R{gain:,.2f} over the next 12 months", 10, True, pdf.CORP, "right")
        y += 18
        for ln in rows:
            if y + tall(ln, 500, 9.5) + tall(note, 500, 8.5) + 10 > bottom:
                break
            y = d.paragraph(52, y, ln, 500, 9.5)
        y = d.paragraph(52, y + 2, note, 500, 8.5, color=pdf.MUTE)
    y += 8
    d.paragraph(40, max(y, bottom - 6), closing, 515, 9.5, color=pdf.MUTE)
    d.line(40, 790, 555, 790)
    d.text(40, 808, "Nothing was changed in any system. The evidence pack and the audit trail hold the full detail.", 8.5, False, pdf.MUTE)
    d.save(path)
