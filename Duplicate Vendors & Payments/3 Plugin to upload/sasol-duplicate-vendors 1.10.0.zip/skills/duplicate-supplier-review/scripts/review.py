#!/usr/bin/env python3
"""The duplicate-supplier review. Claude runs one step at a time; each prints plain-English JSON.

  ready                         the dashboard before any files arrive (for a pre-warmed chat)
  start     [--folder F] [--copy] [--files …]   check the supplier list and the spend history, and open the review
  match                         score every plausible pair of suppliers; the policy threshold sets the review queue
  evidence                      print the evidence for each pair in the queue, for the assessment
  gate      --assessment FILE   check the assessment, open a decision for each pair and give the card, set to the recommendations
  decide    --name --role --file FILE   record the card's decisions, all of them or none ({"decisions": [{"item", "option", "reason"}]})
  decide    --name --role --pair P --option O --reason R   or one pair's decision
  findings                      payments made twice, and possible duplicates (after every decision); the brief for the analysis
  analysis  --file FILE         check the analysis against the review's own figures, then ask for release
  release   --approve|--return --reason --name --role --reviewed   (a different person, in a role allowed to release)
  publish   [--folder F]        file the report, the management pack, the evidence, the audit trail, the data, the drafts and the record
  verify    [--file RECORD]     tamper check on this review's record, or on a downloaded copy
  dashboard                     rewrite the dashboard for the current stage
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import analysis  # noqa: E402
import logic  # noqa: E402
import skillkit as kit  # noqa: E402
from governance import Review, ReviewError, verify_record  # noqa: E402

WORK = kit.work_dir()
TEMPLATE = HERE.parent / "assets" / "dashboard.html"
CARD = HERE.parent / "assets" / "decision-card.html"
KIND = "supplier records"                                            # the kind of decision, in the delegation of authority
LABELS = {"stage-matched": "Suppliers matched", "stage-evidence": "Evidence gathered", "stage-assessed": "Assessment checked",
          analysis.EVENT: analysis.LABEL}
NOT_STARTED = "The review hasn't started yet. It begins by reading the supplier list and the spend history in the project folder."
NOT_MATCHED = "The suppliers haven't been matched yet, so there's nothing to assess."
NOT_CALCULATED = "The findings haven't been calculated yet."


def rv() -> Review:
    return Review(WORK)


def saved(name: str):
    p = WORK / name
    return json.loads(p.read_text()) if p.exists() else None


def save(name: str, obj) -> None:
    (WORK / name).write_text(json.dumps(obj, indent=1, default=str))


def vendors() -> list[dict]:
    return logic.load_vendors(Path(rv().state["files"]["vendors"]))


def spend() -> list[dict]:
    return logic.load_spend(Path(rv().state["files"]["spend"]))


def queue() -> list[dict]:
    return [p for p in saved("pairs.json") or [] if p["score"] >= logic.POLICY]


def label(pid: str, names: dict) -> str:
    """A pair as people name it: "Example Motors and Example Motors Group"."""
    return " and ".join(names.get(x, x) for x in pid.split("|"))


def short(pid: str, names: dict) -> str:
    """A pair as a chart labels it: "Example" for two records of one name, "Example / Sample" for two names."""
    a, b = (names.get(x, x).split()[0] for x in pid.split("|"))
    return a if a == b else f"{a} / {b}"


def about(st: dict) -> dict:
    """What each file the review read is, for the Data page and the audit trail."""
    f = st.get("files") or {}
    return {Path(f["vendors"]).name: "The supplier list: every supplier record, with its tax number, bank account and status",
            Path(f["spend"]).name: "The spend history: every order over the period it covers, with its payment date"} if f else {}


# ------------------------------------------------------------------ dashboard data
def ready_run() -> dict:
    return dict(title="Duplicate Vendors & Payments", tagline="Supplier records and the payments made to them", id="New review",
                stages=kit.STAGES, stage=0, awaiting=False, ready=True, focus="overview")


def build_run() -> dict:
    r = rv()
    st = r.state
    stage = {"received": 0, "matched": 1, "evidence": 1, "assessed": 1, "awaiting-decision": 2, "decided": 2, "calculated": 3,
             "awaiting-release": 4, "returned": 4, "released": 4, "published": 5}.get(st["stage"], 0)
    run = dict(title="Duplicate Vendors & Payments", tagline="Supplier records and the payments made to them", id=st["review_id"],
               stages=kit.STAGES, stage=stage, awaiting=st["stage"] in ("awaiting-decision", "awaiting-release"),
               policy=logic.POLICY, floor=logic.FLOOR, data={k: v for k, v in st["summary"].items() if k != "names"}, focus="overview")
    pairs, names = saved("pairs.json"), st["summary"].get("names", {})
    if pairs is not None:
        g = lambda p: "".join(k[0] if p["agree"][k] else "-" for k in ("tax", "bank", "name", "city"))
        run["match"] = dict(compared=st.get("compared", 0), pairs=[[p["a"], p["b"], p["score"], p["kind"], g(p), round(p["similarity"] * 100)] for p in pairs])
    ev, assess = saved("evidence.json"), saved("assessment.json") or {}
    if ev:                                                              # the queue is sent once; its decisions come separately (decs)
        run["queue"] = [dict(id=b["pair"], a=b["a"], b=b["b"], score=b["score"], shares=b["shares"], bl=int(b["bank_linked"]),
                             f=[[logic.iso(x["a"]), logic.iso(x["b"]), x["agrees"], x["note"]] for x in b["fields"] if x["field"] != logic.SAME_AMOUNT],   # in FL's order
                             m=[[m["amount"], m["orders"], m["dates"], m["paid_on"], m["days_apart"], m["records"]] for m in b["matches"]],
                             rec=(a := assess.get(b["pair"])) and dict(r=a["recommendation"], c=a["confidence"], t=a["assessment"])) for b in ev]
        run["decs"] = {k.split(":", 1)[1]: dict(o=d["option"], label=d["label"], reason=d["reason"], name=d.get("name"), role=d["role"], at=kit.hhmm(d["at"]),
                                                fp=d["shown"][:8]) for k, d in st["decisions"].items()} or None
    c = saved("consequences.json")
    if c:                                                               # what the pages need of the findings
        t = lambda x: dict(amount=x["amount"], orders=x["orders"], dates=x["dates"], records=x["records"], days_apart=x["days_apart"], pair=x["pair"],
                           **({"status": x["status"]} if x.get("status") else {}))
        run["conseq"] = dict(confirmed=[dict(pair=x["pair"], combined=x["combined"]) for x in c["confirmed"]], referred=[dict(pair=x["pair"]) for x in c["referred"]],
                             cleared=[dict(pair=x["pair"]) for x in c["cleared"]], paid_twice=[t(x) for x in c["paid_twice"]], possible=[t(x) for x in c["possible"]],
                             total_twice=c["total_twice"], orders_twice=c["orders_twice"], total_possible=c["total_possible"])
    acc = saved("analysis.json")
    if acc:
        run["an"] = analysis.run_view(acc, saved("analysis-brief.json"), review_date())
    run["names"] = names
    run["inputs"] = kit.inputs_view(r, about(st), {Path(st["files"]["vendors"]).name: st["summary"]["vendors"],
                                                   Path(st["files"]["spend"]).name: st["summary"]["lines"]})
    run["release"] = kit.release_view(st.get("release"))
    run["record"] = kit.record_view(r, LABELS)
    run["downloads"] = st.get("downloads", [])
    run["filed"] = st.get("filed")
    return {k: v for k, v in run.items() if v is not None}


def write_dashboard() -> dict:
    return kit.fill_dashboard(TEMPLATE, build_run(), WORK / "dashboard.html")


# ------------------------------------------------------------------ steps
def cmd_ready(a):
    WORK.mkdir(parents=True, exist_ok=True)
    kit.emit(dict(ok=True, **kit.fill_dashboard(TEMPLATE, ready_run(), WORK / "dashboard.html")))


def cmd_start(a):
    folder = kit.check_folder(a.folder)
    books = kit.find_files(a.files, (".xlsx",), folder)
    vend = [b for b in books if "vendor" in b.name.lower() or "supplier" in b.name.lower()]
    spnd = [b for b in books if "spend" in b.name.lower() or "order" in b.name.lower() or "payment" in b.name.lower()]
    if not vend or not spnd:
        kit.fail(f"The project folder needs the supplier list and the spend history (both Excel) in {kit.DATA}." if folder
                 else "I need the supplier list and the spend history (both Excel). Please add both.")
    try:
        vs, sp = logic.load_vendors(vend[0]), logic.load_spend(spnd[0])
    except ValueError as e:
        kit.fail(str(e))
    r = rv()
    try:
        r.start("duplicate-vendors", kit.review_id("DV"), [vend[0], spnd[0]], version=kit.plugin_version())
    except ReviewError as e:
        kit.fail(str(e))
    dates = [s["PO Date"] for s in sp]
    sites = sorted({s["Site"] for s in sp}, key=lambda x: -sum(s["amount"] for s in sp if s["Site"] == x))
    summary = dict(vendors=len(vs), active=sum(v["Status"] == "Active" for v in vs), blocked=sum(v["Status"] != "Active" for v in vs),
                   ordering=len({s["Vendor ID"] for s in sp}), cities=len({v["City"] for v in vs}), lines=len(sp), value=round(sum(s["amount"] for s in sp), 2),
                   unpaid=sum(not s["paid"] for s in sp), period=f"{min(dates):%b %Y} to {max(dates):%b %Y}", first=min(dates).isoformat(),
                   last=max(dates).isoformat(), sites=sites, names={},
                   bySite=[[site, round(sum(s["amount"] for s in sp if s["Site"] == site), 2)] for site in sites])
    st = r.put(files={"vendors": str(vend[0]), "spend": str(spnd[0])}, folder=folder, folder_copy=bool(folder and a.copy), summary=summary)
    kit.emit(dict(ok=True, review=st["review_id"], source="the project folder" if folder else "the files shared in the chat",
                  suppliers=summary["vendors"], active=summary["active"], blocked=summary["blocked"], orders=summary["lines"], spend=summary["value"],
                  period=summary["period"], **write_dashboard()))


def cmd_match(a):
    kit.needs(WORK, "review-state.json", message=NOT_STARTED)
    vs = vendors()
    pairs, compared = logic.candidates(vs)
    save("pairs.json", pairs)
    r = rv()
    names = {v["Vendor ID"]: v["Vendor Name"] for v in vs if any(v["Vendor ID"] in (p["a"], p["b"]) for p in pairs)}
    st = r.state
    st["summary"]["names"] = names
    r.put(summary=st["summary"], compared=compared)
    q = [p for p in pairs if p["score"] >= logic.POLICY]
    r.set_stage("matched", {"compared": compared, "scored": len(pairs), "queued": len(q)}, about=[[p["id"], p["score"], p["kind"]] for p in pairs])
    missed_at = sorted({p["score"] for p in q})
    kit.emit(dict(ok=True, pairs_compared=compared, policy_threshold=logic.POLICY, review_queue=len(q),
                  queue=[dict(pair=p["id"], suppliers=[names[p["a"]], names[p["b"]]], score=p["score"], shares=p["kind"]) for p in q],
                  look_alikes_below_policy=sum(p["score"] < logic.POLICY for p in pairs),
                  a_higher_threshold_misses=[dict(above=s, pair=p["id"], shares=p["kind"]) for s in missed_at[:-1] for p in q if p["score"] == s]))


def cmd_evidence(a):
    kit.needs(WORK, "pairs.json", message=NOT_MATCHED)
    vs, sp = vendors(), spend()
    by_id = {v["Vendor ID"]: v for v in vs}
    ix = logic.spend_by_vendor(sp)
    ev = [logic.bundle(p, by_id, ix, sp) for p in queue()]
    save("evidence.json", ev)
    rv().set_stage("evidence", {"pairs": len(ev), "with_same_amount_orders": sum(bool(b["matches"]) for b in ev)}, about=ev)
    kit.emit(dict(ok=True, instruction="Assess each pair as references/assessment-guide.md describes, citing only its fields.",
                  pairs=[dict(pair=b["pair"], suppliers=b["names"], score=b["score"], shares=b["shares"],
                              fields=[dict(field=x["field"], first=logic.iso(x["a"]), second=logic.iso(x["b"]), agrees=x["agrees"], note=x["note"]) for x in b["fields"]])
                         for b in ev]))


def check_assessment(path: str, ev: list[dict]) -> dict:
    """The assessment of each pair: a recommendation, a confidence and a short reason citing only the evidence."""
    try:
        data = json.loads(Path(path).read_text())
        items = data.get("pairs", data) if isinstance(data, dict) else data      # the review keeps its own copy keyed by pair
        by = {i.get("pair"): i for i in items} if isinstance(items, list) else {k: dict(v, pair=k) for k, v in items.items()}
    except (OSError, KeyError, TypeError, ValueError, AttributeError):
        kit.fail('Fix and run again: the assessment must be a JSON file with a "pairs" list, one entry per pair, each with its "pair".')
    out = {}
    for b in ev:
        i = by.get(b["pair"])
        if not i:
            kit.fail(f"Fix and run again: the pair {b['pair']} hasn't been assessed.")
        if i.get("recommendation") not in logic.OPTIONS or i.get("confidence") not in ("high", "medium", "low"):
            kit.fail(f"Fix and run again: {b['pair']} needs a recommendation (same, different or refer) and a confidence (high, medium or low).")
        stray = [c for c in i.get("cites", []) if c not in logic.BUNDLE_FIELDS]
        if not i.get("cites") or stray:
            kit.fail(f"Fix and run again: {b['pair']} must cite only its evidence fields" + (f"; not {', '.join(stray)}." if stray else "."))
        words = len(str(i.get("assessment", "")).split())
        if not 5 <= words <= 60:
            kit.fail(f"Fix and run again: keep the assessment of {b['pair']} to one or two sentences (60 words at most).")
        out[b["pair"]] = dict(recommendation=i["recommendation"], confidence=i["confidence"], assessment=i["assessment"].strip(), cites=i["cites"])
    return out


def evidence_line(b: dict) -> str:
    """The card's one-line summary of a pair's evidence: what it shares, how alike the names are, what's blocked, the
    combined spend, and any orders for the same amount on both records (shown before anyone decides)."""
    x, g = {f["field"]: f for f in b["fields"]}, b["agree"]
    shares = ("Same tax number and bank account" if g["tax"] and g["bank"] else "Same tax number, different bank accounts" if g["tax"]
              else f"Same bank account{' and town' if g['city'] else ''}, different tax numbers")
    parts = [shares, f"names {x['Vendor Name']['note'].replace(' similar', '')} alike"]
    parts += [f"{n} {s[0].lower() + s[1:]}" for n, s in zip(b["names"], (x["Status"]["a"], x["Status"]["b"])) if s.startswith("Blocked")]
    parts.append(f"{kit.rand_spoken(float(x['Spend']['a']) + float(x['Spend']['b']))} combined spend")
    parts += [f"{kit.rand(m['amount'])} ordered on both, {m['days_apart']} days apart" for m in b["matches"]]
    return " · ".join(parts)


def cmd_gate(a):
    kit.needs(WORK, "evidence.json", message=NOT_MATCHED)
    ev = saved("evidence.json")
    if not ev:
        kit.emit(dict(ok=True, decision_needed=False, message="No pair of suppliers reaches the policy threshold. No decision is needed."))
        return
    r = rv()
    if r.state["decisions"]:
        kit.fail("The decisions on the supplier pairs have already been made.")
    assess = check_assessment(a.assessment, ev)
    names, roles = r.state["summary"]["names"], kit.roles()["decide"][KIND]
    if not r.state["open"]:                                             # asked once; running the step again only redraws the card
        save("assessment.json", assess)
        r.set_stage("assessed", {"pairs": len(assess), **Counter(x["recommendation"] for x in assess.values())}, about=assess)
        try:
            for b in ev:
                x = assess[b["pair"]]
                r.open_decision(f"pair:{b['pair']}", f"Are {label(b['pair'], names)} the same supplier?", logic.options(b),
                                dict(pair=b["pair"], fields=b["fields"], score=b["score"], matches=b["matches"], assessment=x), roles,
                                recommended=dict(option=x["recommendation"], reason=x["assessment"], confidence=x["confidence"]))
        except ReviewError as e:
            kit.fail(str(e))
    assess = saved("assessment.json")
    items = []
    for b in ev:
        n, opts = label(b["pair"], names), logic.options(b)
        x = assess[b["pair"]]
        items.append(dict(title=n, sub=evidence_line(b), options=[[k, v] for k, v in opts.items()],
                          rec=dict(option=x["recommendation"], reason=x["assessment"], confidence=x["confidence"]),
                          sentence={"same": f"{n}: the same supplier.", "refer": f"{n}: refer it on.",
                                    "different": f"{n}: different suppliers, bank details verified." if b["bank_linked"] else f"{n}: different suppliers."}))
    card = kit.decision_card(CARD, WORK / "decision-card.html", kicker="Your decision · supplier pairs", title=f"Are these the same supplier? {len(ev)} pairs need a person",
                             lead="Decisions on the supplier pairs.", items=items, roles=roles)
    kit.emit(dict(ok=True, decision_needed=True, roles=roles,
                  pairs=[dict(pair=b["pair"], suppliers=[names[b["a"]], names[b["b"]]], score=b["score"], shares=b["shares"], evidence=evidence_line(b),
                              options=list(logic.options(b).values()), your_recommendation=assess[b["pair"]]["recommendation"],
                              confidence=assess[b["pair"]]["confidence"]) for b in ev],
                  decision_card=card, **write_dashboard()))


def which(item: str, ev: list[dict], names: dict) -> str | None:
    """The pair a decision names: its number (V…|V…), either record's number, its place on the card (1, 2, …) or its names."""
    item, ids = str(item).strip(), [b["pair"] for b in ev]
    if item in ids:
        return item
    hits = [i for i in ids if item in i.split("|")] or ([ids[int(item) - 1]] if item.isdigit() and 0 < int(item) <= len(ids) else [])
    flat = lambda s: re.sub(r"[^a-z0-9]", "", s.lower())
    hits = hits or [i for i in ids if flat(item) in (flat(label(i, names)), flat(label("|".join(reversed(i.split("|"))), names)))]
    return hits[0] if len(hits) == 1 else None


def option_key(text: str) -> str:
    """An option as Claude may write it: its key (same, different, refer) or its words on the card."""
    t = str(text).strip().lower()
    return t if t in logic.OPTIONS else "same" if "same" in t else "different" if "different" in t else "refer" if "refer" in t else t


def cmd_decide(a):
    ev = saved("evidence.json")
    if not ev or not (WORK / "assessment.json").exists():
        kit.fail("There's no decision waiting right now.")
    r = rv()
    names = r.state["summary"]["names"]
    if a.file:
        rows = kit.read_decisions(a.file)
    elif a.pair and a.option:
        rows = [(a.pair, a.option, a.reason or "")]
    else:
        kit.fail("Fix and run again: give the card's decisions with --file, or one pair's with --pair, --option and --reason.")
    items = []
    for item, option, reason in rows:
        pid = which(item, ev, names)
        if not pid:
            kit.fail(f"Fix and run again: \"{item}\" isn't one of the pairs from the gate. Name each by its pair, for example {ev[0]['pair']}.")
        items.append((f"pair:{pid}", option_key(option), reason))
    try:
        done = r.decide_many(items, a.name, a.role)
    except ReviewError as e:
        kit.fail(str(e))
    left = [b["pair"] for b in ev if f"pair:{b['pair']}" not in r.state["decisions"]]
    kit.emit(dict(ok=True, recorded=[dict(pair=d["key"].split(":", 1)[1], suppliers=label(d["key"].split(":", 1)[1], names), decision=d["label"],
                                          reason=d["reason"]) for d in done],
                  name=done[-1]["name"], role=done[-1]["role"], at=kit.hhmm(done[-1]["at"]), still_to_decide=left))


def cmd_findings(a):
    kit.needs(WORK, "evidence.json", message=NOT_MATCHED)
    r = rv()
    if r.state.get("release"):
        kit.fail("The findings have already been calculated and sent for release.")
    decisions = {}
    for p in queue():
        try:
            decisions[p["id"]] = r.require(f"pair:{p['id']}")["option"]
        except ReviewError as e:
            kit.fail(str(e))
    sp = spend()
    c = logic.consequences(sp, queue(), decisions, logic.spend_by_vendor(sp))
    save("consequences.json", c)
    r.set_stage("calculated", logic.headline(c), about=c)
    b = analysis_brief(c)
    save("analysis-brief.json", b)
    names = r.state["summary"]["names"]
    kit.emit(dict(ok=True, confirmed_same=[label(x["pair"], names) for x in c["confirmed"]], referred=[label(x["pair"], names) for x in c["referred"]],
                  different=[label(x["pair"], names) for x in c["cleared"]],
                  paid_twice=[dict(amount=t["amount"], orders=t["orders"], dates=t["dates"], paid=t["paid_on"], days_apart=t["days_apart"],
                                   suppliers=[names[x] for x in t["records"]]) for t in c["paid_twice"]],
                  total_paid_twice=c["total_twice"],
                  possible_duplicates=[dict(amount=t["amount"], orders=t["orders"], dates=t["dates"], days_apart=t["days_apart"],
                                            suppliers=[names[x] for x in t["records"]], status=t["status"]) for t in c["possible"]],
                  total_possible_duplicates=c["total_possible"], combined_spend_of_confirmed=[x["combined"] for x in c["confirmed"]],
                  analysis=analysis.for_claude(b)))


def review_date() -> dt.date:
    """The day the review started, in South African time: the projection starts the month after."""
    return dt.datetime.fromisoformat(rv().entries()[0]["at"]).astimezone(kit.SAST).date()


LEVER_WORDS = {"recover": "Recover the amount paid twice", "merge": "Merge the two records into one",
               "verify-bank": "Confirm each supplier's bank details before paying either again",
               "verify-tax": "Confirm each supplier's registration and tax number before paying either again",
               "hold": "Hold the possible duplicate for the forensic review", "keep-proof": "Keep the bank confirmation on both records",
               "mark-distinct": "Record that the two are different suppliers", "check-orders": "Confirm the orders for the same amount were separate work"}
NOTES = {"mark-distinct": "Stops repeat flags"}


def analysis_brief(c: dict) -> dict:
    """What the analysis is written from: each pair's facts and levers, every figure from the rules."""
    st, sp, ev, R, day = rv().state, spend(), saved("evidence.json"), kit.rand, kit.day
    by_id = {v["Vendor ID"]: v for v in vendors()}
    names, assess = st["summary"]["names"], saved("assessment.json") or {}
    decided = {k.split(":", 1)[1]: v for k, v in st["decisions"].items()}
    ix, months = logic.spend_by_vendor(sp), logic.period_months(sp)
    sites = defaultdict(Counter)
    for s in sp:
        sites[s["Vendor ID"]][s["Site"]] += 1
    twice, possible = defaultdict(list), defaultdict(list)
    for t in c["paid_twice"]:
        twice[t["pair"]].append(t)
    for t in c["possible"]:
        possible[t["pair"]].append(t)
    letters = {t["pair"] for t in c["paid_twice"]}                       # the pairs a draft recovery letter is written for

    def record(v: str, x: dict, side: str) -> str:
        """One record: its status, when it was created, and its orders (when, and for which sites)."""
        s, where = ix.get(v), sorted(sites[v].items(), key=lambda kv: (-kv[1], kv[0]))
        use = "no orders in the spend history"
        if s:
            use = (f"1 order worth {R(s['value'])}, on {day(s['first'])}" if s["orders"] == 1 else
                   f"{s['orders']} orders worth {R(s['value'])}, from {day(s['first'])} to {day(s['last'])}")
            use += " (" + (", ".join(f"{n} for {site}" for site, n in where) if len(where) > 1 else ("all " if s["orders"] > 1 else "") + f"for {where[0][0]}") + ")"
        blocked = by_id[v].get("blocked_on")
        now = f"blocked on {day(blocked)}" if by_id[v]["Status"] == "Blocked" and blocked else by_id[v]["Status"].lower()
        return f"{names[v]} ({v}): {now}, created {day(x['Created Date'][side])}; {use}"

    def order(t: dict, k: int) -> str:
        return f"{t['orders'][k]} ({names[t['records'][k]]}, {day(t['dates'][k])}" + (f", paid {day(t['paid_on'][k])})" if t["paid_on"][k] else ", not yet paid)")

    def facts(b: dict, x: dict, d: dict) -> list[str]:
        """What the pair shares and doesn't, each record's use, the same-amount orders, the decision and its consequence."""
        shared = [f"the {w}" + (f" ({x[k]['a']})" if k in ("City", "Primary Category") else "") for w, k in
                  (("tax number", "Tax Number"), ("bank account", "Bank Account"), ("city", "City"), ("category", "Primary Category")) if x[k]["agrees"]]
        differ = "; ".join([*(["different tax numbers"] if not x["Tax Number"]["agrees"] else []), *(["different bank accounts"] if not x["Bank Account"]["agrees"] else []),
                            f"names {x['Vendor Name']['note']}", f"registered as {x['Registered Name']['a']} and {x['Registered Name']['b']}",
                            *[f"{w} {x[k]['a']} and {x[k]['b']}" for w, k in (("cities", "City"), ("categories", "Primary Category")) if not x[k]["agrees"]]])
        out = [f"Match score {b['score']:.2f} (the policy line is {logic.POLICY}): shares "
               + (" and ".join([", ".join(shared[:-1]), shared[-1]]) if len(shared) > 1 else f"only {shared[0]}" if shared else "nothing but a similar name"),
               differ[0].upper() + differ[1:], record(b["a"], x, "a"), record(b["b"], x, "b"),
               f"Combined spend on both records: {R(logic.combined(ix, b['a'], b['b']))} across "
               f"{plural(sum(ix.get(v, {}).get('orders', 0) for v in (b['a'], b['b'])), 'order', 'orders')} over {months} months"]
        out += ([f"Ordered on both records for the same amount within {logic.TWICE_WITHIN_DAYS} days, shown before the decision: {R(t['amount'])} on "
                 f"{order(t, 0)} and {order(t, 1)}, {t['days_apart']} days apart" for t in b["matches"]] or
                [f"No order on one record matches an order on the other to the cent within {logic.TWICE_WITHIN_DAYS} days"])
        out.append(f"Decided by {kit.by(d)}: {d['label'].lower().replace(' · ', ', with the ')}" + (" (forensic review)" if d["option"] == "refer" and b["bank_linked"] else "")
                   + f", because \"{d['reason']}\"")
        mine = assess.get(b["pair"])
        if mine:
            out.append(f"The assessment before the decision: {logic.OPTIONS[mine['recommendation']].lower()}, {mine['confidence']} confidence: \"{mine['assessment']}\"")
            if mine["recommendation"] != d["option"]:
                out.append(f"The decision differs from the assessment, which recommended {logic.OPTIONS[mine['recommendation']].lower()}")
        if d["option"] == "same":
            out += [f"Paid twice: {R(t['amount'])}, both orders paid" for t in twice[b["pair"]]]
            out += [f"Not counted as paid twice: {R(t['amount'])} on both records, {t['status']}" for t in possible[b["pair"]]]
            if not b["matches"]:
                out.append("Nothing was paid twice on this pair")
            if len(twice[b["pair"]]) > 1:
                out.append(f"Paid twice on this pair in all: {R(sum(t['amount'] for t in twice[b['pair']]))} across {len(twice[b['pair']]) * 2} orders")
        elif b["matches"]:
            out += [f"A possible duplicate, not counted as paid twice: {R(t['amount'])}, {t['status']}" for t in possible[b["pair"]]]
        else:
            out.append("Not counted for payments made twice: only pairs confirmed as one supplier are")
        return out

    def levers(b: dict, x: dict, d: dict) -> list[dict]:
        """The pair's levers, valued by the rules (logic.levers), each with the words that say how."""
        both = logic.combined(ix, b["a"], b["b"])
        paid = round(sum(t["amount"] for t in twice[b["pair"]]), 2)
        maybe = round(sum(t["amount"] for t in possible[b["pair"]]), 2)
        out = []
        for key, kind, amount in logic.levers(d["option"], b, paid, maybe, both, months):
            if key == "recover":
                why = ("; ".join(f"{t['orders'][0]} on {day(t['dates'][0])} and {t['orders'][1]} on {day(t['dates'][1])}, {t['days_apart']} days apart, "
                                 f"were each for {R(t['amount'])} and both were paid" for t in twice[b["pair"]])
                       + f". Recovering the {R(paid)} paid twice is a one-off; the draft recovery letter asks the supplier for a credit note or refund")
            elif key == "merge" and kind == "recurring":
                why = (f"{R(paid)} was paid twice over {months} months ({R(amount)} a month). With the two records merged, the same order can't be paid to both. "
                       "The projection assumes the next 12 months look like the period reviewed")
            elif key == "merge":
                why = (f"{R(both)} of orders over {months} months went to one supplier through two records, and every order on two records is a chance to pay twice. "
                       "Nothing was paid twice in the period reviewed, so this is at stake, not a gain")
            elif key == "verify-bank":
                why = (f"{R(both)} of orders over {months} months went to one bank account under two tax numbers. "
                       "Confirm the bank details with each supplier independently before paying either again")
            elif key == "verify-tax":
                why = f"{R(both)} of orders over {months} months went to two records under one tax number. Confirm each supplier's registration before paying either again"
            elif key == "hold":
                why = f"{R(maybe)} was ordered and paid on both records within {logic.TWICE_WITHIN_DAYS} days. It stays a possible duplicate until the forensic review concludes"
            elif key == "keep-proof":
                why = (f"A person decided these are different suppliers with the bank details verified. {R(both)} of orders over {months} months went to the account "
                       "they share, so the confirmation stays on both records and payments to that account are watched")
            elif key == "check-orders":
                why = f"{R(maybe)} was ordered on both records within {logic.TWICE_WITHIN_DAYS} days, although a person decided these are different suppliers"
            else:
                why = "A person decided these are different suppliers. Recording that on both records stops the pair being queued again in the next review"
            out.append(analysis.lever(b["pair"], key, LEVER_WORDS[key], kind, amount, why, note=NOTES.get(key)))
        return out

    items = []
    for b in ev:
        x, d = {f["field"]: f for f in b["fields"]}, decided[b["pair"]]
        items.append(dict(ref=b["pair"], name=label(b["pair"], names), facts=facts(b, x, d), levers=levers(b, x, d)))
    items.sort(key=lambda i: (-sum(l["gain12"] for l in i["levers"]), -sum(l["amount"] for l in i["levers"] if l["kind"] == "risk")))
    s = st["summary"]
    review = [f"{s['vendors']:,} supplier records and {s['lines']:,} purchase orders worth {R(s['value'])}, over {months} months ({s['period']})",
              f"{st.get('compared', 0):,} plausible pairs compared; {len(ev)} reached the policy line of {logic.POLICY} and went to a person",
              f"Decided: {len(c['confirmed'])} confirmed as one supplier, {len(c['referred'])} referred on, {len(c['cleared'])} decided as different suppliers",
              f"Spend through the {len(ev)} pairs in the queue: {R(round(sum(logic.combined(ix, b['a'], b['b']) for b in ev), 2))} "
              f"across {sum(ix.get(v, {}).get('orders', 0) for b in ev for v in (b['a'], b['b']))} orders",
              (f"Paid twice: {R(c['total_twice'])} across {c['orders_twice'] * 2} orders on {len({t['pair'] for t in c['paid_twice']})} pairs, "
               "found only on pairs confirmed as one supplier" if c["paid_twice"] else "Nothing was confirmed as paid twice"),
              *([f"Possible duplicates, not counted as paid twice: {R(c['total_possible'])}"] if c["possible"] else [])]
    return analysis.brief("pairs", items, review, review_date())


def cmd_analysis(a):
    kit.needs(WORK, "consequences.json", "analysis-brief.json", message=NOT_CALCULATED)
    r = rv()
    if r.state.get("release"):
        kit.fail("The analysis has already been checked and sent for release.")
    try:
        draft = json.loads(Path(a.file).read_text())
    except (OSError, ValueError):
        kit.fail("Fix and run again: the analysis must be a JSON file, as references/analysis-guide.md shows.")
    b = saved("analysis-brief.json")
    acc, problems = analysis.accept(draft, b)
    if problems:
        kit.fail(analysis.fix_message(problems))
    save("analysis.json", acc)
    analysis.record(r, acc)
    roles = kit.roles()["release"]
    r.request_release(logic.headline(saved("consequences.json")), acc, roles=roles, recommended=acc["release"])     # the release approves both
    card = kit.release_card(CARD, r, WORK / "release-card.html", roles=roles)
    first = [dict(pair=i["name"], does=l["does"]) for i in b["pairs"] for l in i["levers"] if l["id"] in acc["overview"]["priorities"][:1]]
    kit.emit(dict(ok=True, headline=acc["overview"]["headline"], recommendations=acc["recommendations"],
                  projected_gain_12_months=kit.rand_spoken(acc["totals"]["gain12"]), at_stake=kit.rand_spoken(acc["totals"]["at_risk"]),
                  **({"first_priority": first[0]} if first else {}), roles=roles, release_card=card, **write_dashboard()))


def cmd_release(a):
    if (WORK / "consequences.json").exists() and not (WORK / "analysis.json").exists():
        kit.fail("Fix and run again: write the analysis and run analysis first; it asks for the release.")
    try:
        rel = rv().decide_release(a.approve, a.reason, a.name, a.role, reviewed=a.reviewed)
    except ReviewError as e:
        kit.fail(str(e))
    kit.emit(dict(ok=True, status=rel["status"], name=rel["name"], role=rel["role"], at=kit.hhmm(rel["at"]),
                  **(write_dashboard() if rel["status"] == "returned" else {})))


def cmd_publish(a):
    r = rv()
    c = saved("consequences.json")
    if not c:
        kit.fail("There are no findings to release yet.")
    out = kit.outputs_dir()
    try:
        written = r.publish(logic.headline(c), lambda: write_outputs(out, c), saved("analysis.json"))
    except ReviewError as e:
        write_dashboard()
        kit.fail(str(e))
    folder = str(Path(a.folder)) if a.folder else r.state.get("folder")
    acc, b = saved("analysis.json"), saved("analysis-brief.json")
    done = kit.complete_release(r, out, written=written, own=own_rows(c), folder=folder,
                                into_copy=bool(r.state.get("folder_copy") and folder == r.state.get("folder")),     # a working copy is never filed into
                                template=TEMPLATE, build_run=build_run, briefing_for=lambda places: briefing(r, c, places),
                                pack_extra=pack_extra(r, c, acc, b), data=data_sheets(r, c), trace=trace(r, c, acc), labels=LABELS, about_inputs=about(r.state))
    kit.emit(dict(ok=True, **done, **write_dashboard()))


def own_rows(c: dict) -> list[list[str]]:
    """The review's own documents, as the dashboard lists them."""
    return [["Change request (Excel)", "Draft requests for the supplier-list owner, naming both records of each pair. Nothing is merged or blocked"],
            *([["Draft recovery letters (Word)", "A draft request to each supplier paid twice, for a person to send"]] if c["paid_twice"] else [])]


def pack_extra(r, c: dict, acc: dict, b: dict) -> dict:
    """The management pack's hero, scope, basis note, asks and charts, all from the review's own figures."""
    st, names = r.state, r.state["summary"]["names"]
    s, n, twice = st["summary"], len(queue()), c["total_twice"]
    both = sum(x["combined"] for x in c["confirmed"])
    hero = (dict(value=kit.rand_spoken(twice), label="Paid twice", note=f"{c['orders_twice']} payments on pairs confirmed as one supplier") if twice else
            dict(value=kit.rand_spoken(both), label="Combined spend on the confirmed pairs", note="at stake while each supplier sits on two records"))
    spend_of = {x["pair"]: x["combined"] for x in c["confirmed"] + c["referred"] + c["cleared"]}
    rows = sorted(queue(), key=lambda p: -spend_of.get(p["id"], 0))
    twice_of = defaultdict(float)
    for t in c["paid_twice"]:
        twice_of[t["pair"]] += t["amount"]
    chart = dict(title="Combined spend and paid twice, by pair", kind="hbar", money=True, labels=[short(p["id"], names) for p in rows],
                 series=[dict(label="Combined spend", data=[spend_of.get(p["id"], 0) for p in rows]),
                         *([dict(label="Paid twice", data=[round(twice_of.get(p["id"], 0), 2) for p in rows])] if twice else [])])
    asks = ([f"Agree that Accounts payable sends the recovery requests for the {kit.rand_spoken(twice)} paid twice"] if twice else [])
    asks += [f"Agree that the supplier-list owner consolidates the {len(c['confirmed'])} pairs confirmed as one supplier"] if c["confirmed"] else []
    asks += ([f"Note the {len(c['referred'])} {'pair' if len(c['referred']) == 1 else 'pairs'} referred on for review of the shared details"] if c["referred"] else [])
    sites = kit.places(s["sites"])
    scope = " · ".join(x for x in (f"{s['vendors']:,} supplier records", f"{s['lines']:,} orders", kit.rand_spoken(s["value"]), s["period"], sites) if x)
    basis = (f"Figures cover only the {s['vendors']:,} supplier records and {s['lines']:,} orders in this review{', at ' + sites if sites else ''}, "
             f"from {kit.day(s['first'])} to {kit.day(s['last'])} (rand excluding VAT), and are not group totals.")
    return dict(hero=hero, scope=scope, basis_note=basis,
                asks=asks[:3], charts=kit.pack_charts(analysis.chart_series(acc, b, review_date()), chart))


def data_sheets(r, c: dict) -> list[dict]:
    """The Data workbook: every record and every order as read, every pair above the floor, and the same-amount orders."""
    st, vs, sp = r.state, vendors(), spend()
    names, decided = st["summary"]["names"], {k.split(":", 1)[1]: v for k, v in st["decisions"].items()}
    status = {t["pair"] + t["orders"][0]: "Paid twice" for t in c["paid_twice"]} | {t["pair"] + t["orders"][0]: "Possible duplicate, " + t["status"] for t in c["possible"]}
    d = lambda v: v if isinstance(v, dt.date) else (v or "")
    return [
        dict(name="Supplier list", about="Every supplier record as the review read it", headers=[*logic.VENDOR_COLUMNS, "Blocked Date"],
             rows=[[d(v.get(k)) for k in (*logic.VENDOR_COLUMNS, "Blocked Date")] for v in vs], widths=[11, 38, 42, 13, 14, 16, 30, 13, 10, 13]),
        dict(name="Spend history", about="Every order as the review read it", headers=[*logic.SPEND_COLUMNS, "Payment Date"],
             rows=[[d(s.get(k)) for k in (*logic.SPEND_COLUMNS, "Payment Date")] for s in sp], money={"Amount Excl VAT"}, widths=[13, 11, 38, 30, 12, 12, 17, 20, 14]),
        dict(name="Pairs compared", about=f"Every pair scoring {logic.FLOOR} or more, with its score, what it shares and, for the queue, the decision",
             headers=["First record", "First supplier", "Second record", "Second supplier", "Score", "Shares", "Same tax number", "Same bank account",
                      "Names alike (%)", "Same city", "In the review queue", "Decision"],
             rows=[[p["a"], names.get(p["a"], ""), p["b"], names.get(p["b"], ""), p["score"], p["kind"], *("Yes" if p["agree"][k] else "No" for k in ("tax", "bank")),
                    round(p["similarity"] * 100), "Yes" if p["agree"]["city"] else "No", "Yes" if p["score"] >= logic.POLICY else "No",
                    (decided.get(p["id"]) or {}).get("label", "")] for p in saved("pairs.json")], widths=[12, 34, 12, 34, 8, 28, 10, 10, 10, 10, 12, 34]),
        dict(name="Payments made twice", about="Each pair of orders for the same amount on both records of a pair in the queue, within 30 days, and what it counts as",
             headers=["Pair", "Amount", "First order", "First date", "First paid", "First record", "Second order", "Second date", "Second paid", "Second record",
                      "Days apart", "Counted as"],
             rows=[[label(t["pair"], names), t["amount"], t["orders"][0], t["dates"][0], t["paid_on"][0], t["records"][0], t["orders"][1], t["dates"][1],
                    t["paid_on"][1], t["records"][1], t["days_apart"], status.get(t["pair"] + t["orders"][0], "")] for t in c["paid_twice"] + c["possible"]],
             money={"Amount"}, widths=[50, 14, 12, 12, 12, 12, 12, 12, 12, 12, 10, 40])]


def trace(r, c: dict, acc: dict) -> list[dict]:
    """How each released figure was worked out, from which file and rows, at which step of the record."""
    st, names = r.state, r.state["summary"]["names"]
    s, f = st["summary"], {k: Path(v).name for k, v in st["files"].items()}
    step = lambda ev: next((f"#{e['seq']}" for e in r.entries() if e["event"] == ev), "")
    decided = [e for e in r.entries() if e["event"] == "decision-recorded"]
    seqs = f"#{decided[0]['seq']} to #{decided[-1]['seq']}" if decided else ""
    orders = "; ".join(f"{label(t['pair'], names)}: {' and '.join(t['orders'])}" for t in c["paid_twice"]) or "none"
    return [dict(figure="Supplier records", value=f"{s['vendors']:,}", how="Every row of the supplier list", source=f"{f['vendors']}, every row", step=step("review-started")),
            dict(figure="Orders and spend", value=f"{s['lines']:,} orders, {kit.rand(s['value'])}", how="Every order in the spend history and the sum of Amount Excl VAT",
                 source=f"{f['spend']}, every row", step=step("review-started")),
            dict(figure="Pairs compared", value=f"{st.get('compared', 0):,}", how="Every pair of records sharing a tax number, a bank account or the first word of the name",
                 source=f"{f['vendors']}: Tax Number, Bank Account, Vendor Name", step=step("stage-matched")),
            dict(figure="Pairs in the review queue", value=str(len(queue())), how=f"Pairs scoring {logic.POLICY} or more: 0.45 tax number, 0.35 bank account, "
                 "0.15 x name similarity at 92% or more, 0.05 city", source=f"{f['vendors']}: the two records of each pair", step=step("stage-matched")),
            dict(figure="Decisions", value=f"{len(c['confirmed'])} the same supplier, {len(c['referred'])} referred on, {len(c['cleared'])} different suppliers",
                 how="A person's decision on each pair in the queue, with the reason, name and role", source="The decision card", step=seqs),
            dict(figure="Paid twice", value=kit.rand(c["total_twice"]), how="Orders on both records of a pair confirmed as one supplier, for the same amount to the cent, "
                 "within 30 days, both paid", source=f"{f['spend']}: {orders}", step=step("stage-calculated")),
            dict(figure="Possible duplicates", value=kit.rand(c["total_possible"]), how="The same match on a pair referred on, decided as different suppliers, "
                 "or not yet paid: listed, never counted as paid twice", source=f"{f['spend']}: " + ("; ".join(" and ".join(t["orders"]) for t in c["possible"]) or "none"),
                 step=step("stage-calculated")),
            dict(figure="Projected gain, next 12 months", value=kit.rand(acc["totals"]["gain12"]), how="The recommended levers, valued by the review's rules: "
                 "a recovery once, a recurring change phased in over three months", source="The analysis brief, from the findings", step=step(analysis.EVENT)),
            dict(figure="At stake", value=kit.rand(acc["totals"]["at_risk"]), how="The spend or orders the recommended actions protect; never counted as a gain",
                 source="The analysis brief, from the findings", step=step(analysis.EVENT))]


def plural(n: int, one: str, many: str) -> str:
    return f"{n} {one if n == 1 else many}"


def briefing(r, c: dict, filed: dict) -> dict:
    """What the management pack may say: this review's released figures, decisions and record, already formatted."""
    st, names = r.state, r.state["summary"].get("names", {})
    twice, possible = c["paid_twice"], c["possible"]
    acc, b = saved("analysis.json"), saved("analysis-brief.json")
    gain, at_risk = acc["totals"]["gain12"], acc["totals"]["at_risk"]
    decisions = kit.decisions_view(r, lambda k, d: f"Are {label(k.split(':', 1)[1], names)} the same supplier?")
    figures = [kit.figure("Paid twice", c["total_twice"], "money", f"{c['orders_twice']} payments"),        # the scorecards follow the hero, in this order
               kit.figure("Pairs decided", len(queue()), note="by a person"), kit.figure("Confirmed duplicates", len(c["confirmed"]), note="the same supplier"),
               kit.figure("Referred on", len(c["referred"]), note="for forensic review"),
               *([kit.figure("Projected gain", gain, "money", "over the next 12 months")] if gain else []),
               *([kit.figure("Possible duplicates", c["total_possible"], "money", "not counted as paid twice")] if possible else []),
               kit.figure("Supplier records", st["summary"]["vendors"]), kit.figure("Pairs compared", st.get("compared", 0))]
    findings = [f"{st.get('compared', 0):,} plausible supplier pairs were compared; {len(queue())} reached the policy line and went to a person.",
                f"{plural(len(c['confirmed']), 'pair was', 'pairs were')} confirmed as one supplier, {len(c['referred'])} referred on and "
                f"{len(c['cleared'])} decided as different suppliers."]
    if twice:
        findings.append(f"{kit.rand_spoken(c['total_twice'])} was paid twice across {plural(len({t['pair'] for t in twice}), 'pair', 'pairs')} of records: "
                        + "; ".join(f"{kit.rand_spoken(t['amount'])} to {label(t['pair'], names)}, {t['days_apart']} days apart" for t in twice) + ".")
    if possible:
        findings.append("Possible duplicates, not counted as paid twice: " + "; ".join(f"{kit.rand_spoken(t['amount'])} on {label(t['pair'], names)}, {t['status']}" for t in possible) + ".")
    if not twice and not possible:
        findings.append("No order was paid twice across the pairs confirmed as one supplier.")
    actions = analysis.actions(acc, b)
    chosen = {x["lever"] for v in acc["pairs"].values() for x in v["recommendations"]}
    for x in c["confirmed"]:                                 # money paid twice is always asked back, recommended or not
        if x["paid_twice"] and f"{x['pair']}:recover" not in chosen:
            actions.append(dict(action=f"Send the request to recover the {kit.rand(x['paid_twice'])} paid twice to {label(x['pair'], names)}", owner="Accounts payable"))
    for x in c["referred"]:                                  # a referral always goes to the people who review it
        mine = (acc["pairs"].get(x["pair"]) or {}).get("recommendations", [])
        if not any(m["lever"].endswith((":verify-bank", ":verify-tax")) for m in mine):
            actions.append(dict(action=f"Review the shared details of {label(x['pair'], names)} before paying either again", owner="Internal audit"))
    worth = (f", which the review's own rules value at {kit.rand_spoken(gain)} over the next 12 months." if gain
             else f". No gain is projected: these actions protect {kit.rand_spoken(at_risk)} at stake.")
    letters = " and the recovery letters" if twice else ""
    answer = (f"{kit.rand_spoken(c['total_twice'])} was paid twice to {plural(len({t['pair'] for t in twice}), 'supplier', 'suppliers')}, each held on two records "
              "that a person confirmed are one supplier."
              if twice else f"Nothing is confirmed as paid twice; {kit.rand_spoken(c['total_possible'])} is a possible duplicate, {possible[0]['status']}." if possible
              else f"{plural(len(c['confirmed']), 'pair was', 'pairs were')} confirmed as one supplier; no order was paid twice.")
    return kit.briefing(r, use_case="Duplicate Vendors & Payments", question="Is anyone in our supplier list twice, and have we paid anyone twice?",
                        answer=answer, figures=figures, findings=findings, decisions=decisions, actions=actions, filed=filed, analysis=analysis.briefing(acc),
                        ai_help=dict(assist=f"The evidence for each of the {len(queue())} pairs that reached the policy line was assessed, citing only the two records, "
                                            f"and the change request{letters} were drafted.",
                                     augment=f"A person decided each pair with the evidence and the assessment in front of them, and each pair was then analysed: "
                                             f"{plural(acc['recommendations'], 'action was', 'actions were')} recommended{worth}",
                                     automate=f"Fixed rules compared {st.get('compared', 0):,} plausible pairs of suppliers and looked for orders paid twice, and the evidence, "
                                              "the drafts and a tamper-evident record were filed in the project folder."))


def write_outputs(out: Path, c: dict) -> list[str]:
    import publish_pack
    acc, r = saved("analysis.json"), rv()
    return publish_pack.write(out, r, c, saved("pairs.json"), saved("evidence.json"), saved("assessment.json"), vendors(), spend(),
                              analysis.rows(acc, saved("analysis-brief.json")), acc["totals"], LABELS)


def cmd_verify(a):
    ok, msg = verify_record(a.file) if a.file else rv().verify()
    kit.emit(dict(ok=ok, tamper_check=msg))


def cmd_dashboard(a):
    kit.needs(WORK, "review-state.json", message=NOT_STARTED)
    kit.emit(dict(ok=True, **write_dashboard()))


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("ready", "match", "evidence", "findings", "dashboard"):
        sub.add_parser(name)
    st = sub.add_parser("start")
    st.add_argument("--folder", help="the project folder: its 01 Documents and 02 Data hold the review's files")
    st.add_argument("--copy", action="store_true", help="the folder is a working copy of the project folder's 01 Documents and 02 Data")
    st.add_argument("--files", nargs="*")
    sub.add_parser("publish").add_argument("--folder", help="the project folder to file the released results in")
    sub.add_parser("gate").add_argument("--assessment", required=True)
    sub.add_parser("analysis").add_argument("--file", required=True, help="the analysis, as references/analysis-guide.md describes")
    d = sub.add_parser("decide")
    d.add_argument("--file", help='the card\'s decisions: {"decisions": [{"item", "option", "reason"}]}')
    d.add_argument("--pair", help="one pair's decision: the pair as the gate printed it, first|second")
    d.add_argument("--option", help="same, different or refer")
    d.add_argument("--reason")
    d.add_argument("--name", required=True, help="the full name of the person deciding")
    d.add_argument("--role", required=True, help="their role, one of those the gate printed")
    rl = sub.add_parser("release")
    grp = rl.add_mutually_exclusive_group(required=True)
    grp.add_argument("--approve", action="store_true")
    grp.add_argument("--return", dest="approve", action="store_false")
    rl.add_argument("--reason", required=True)
    rl.add_argument("--name", required=True, help="the approver's full name")
    rl.add_argument("--role", required=True, help="the approver's role, one of those the analysis step printed")
    rl.add_argument("--reviewed", action="store_true", help="the approver confirmed they reviewed the findings, the decisions and the recommendations")
    sub.add_parser("verify").add_argument("--file", help="a downloaded record to check instead of this review's")
    return p


if __name__ == "__main__":
    kit.main(parser(), {n[4:]: f for n, f in globals().items() if n.startswith("cmd_")})
