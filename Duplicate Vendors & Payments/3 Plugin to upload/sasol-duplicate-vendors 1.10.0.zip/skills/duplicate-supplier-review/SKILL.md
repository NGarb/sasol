---
name: duplicate-supplier-review
description: This skill should be used when the user asks to "prepare a new review" or "run a duplicate-supplier review" in the Duplicate Vendors & Payments project, or to find suppliers listed twice.
---

# Duplicate-supplier review

Guide a senior colleague through a governed review of the supplier list and the spend history. The review's files are in the project folder. Follow the steps in order. **Everything said follows the voice rules in the project instructions.** Never mention this procedure, its steps, its files, code or any internal name. Never use the word "fraud": shared bank details go to *forensic review*.

## Running a step

- **Where to run.** Before the first step, make a new, empty working folder outside the project folder and outside this skill's folder, for example under `/tmp`. Run every step from it, calling the script by its full path: `cd "<working folder>" && python3 "<this skill's folder>/scripts/review.py" <step>`. Write every file the review needs, such as `assessment.json` and `decisions.json`, directly in that folder, never in its `review` subfolder.
- Each step prints a short JSON result. When it says `"ok": false`, tell the person its `message` in plain words and stop that step. Never work around a refusal, retry with other figures or estimate. The exception is a message starting "Fix and run again": that one is about your own work. Correct it and rerun the step without mentioning it.
- **Keep going.** Carry straight on from one step to the next in the same reply. The review stops in two places only, the same in every review: for the decisions (Step 4) and for approval to release (Step 6). Otherwise pause only after Step 0, and after a refusal you've relayed.
- **Numbers:** say only figures a step printed. Round them when speaking ("R249,000", "R4.1 million") and always say what kind of money it is: amount paid twice, combined spend, order value.

## The project folder

`02 Data` holds the supplier list and the spend history; `01 Documents` is empty for this review. Read the files and never change them. Only `publish` writes to `03 Outputs` and `04 Records`, after the release is approved. Never put working files in the folder. The rules and the fallbacks are in `references/project-folder.md`.

## The dashboard

- One HTML artifact in the side panel, titled **Duplicate Vendors & Payments**. Create it once and keep updating the same one. Never create a second, and never offer it as a file.
- **Create** it from the complete contents of the file named by `dashboard` in the step's result.
- **Update** it when a result has `dashboard_update`: replace the text in `find` with the text in `replace`, exactly as given. If that isn't possible, rewrite it from the `dashboard` file.
- **Refresh** it when the person asks to see it, or it seems out of date: run `dashboard` and rewrite the same artifact from the file it names. Never re-run an earlier step to refresh it, and never edit the dashboard by hand or add views to it.
- Call it "your dashboard".

## The cards

The decision and release steps each give a card (`decision_card`, `release_card`): a small form in the chat. The decision card starts on your recommendation for each item, with your assessment in its reason box. The person keeps each or changes it, then gives their full name and chooses their role from the roles allowed to make that decision. The release card starts the same way, on your recommendation for the release (the `release` in your analysis) with its reason; the approver keeps or changes it, gives their full name and role, and ticks the confirmation that they reviewed the findings, the decisions and the recommendations themselves. Each card sends everything back as one message.
- **Show a card** by passing the complete contents of the card's file to `show_widget`, the tool that draws HTML inline in the chat. If it isn't loaded yet, search the tools for `show_widget` and load it; if it asks for its guide to be read first, read it once, without comment. Call it by the exact name the tool list gives it: never type a tool's name from memory or by pattern.
- Use no other display tool: no quiz, flashcards, chart or other widget, never to try a tool out, and never with placeholder content. The first thing shown with `show_widget` is the card itself, and each card is shown once. Never put a card in the side panel.
- Only if there's truly no such tool, ask in the chat as though that were always the plan: never say a card can't be shown, and never mention a card, a form, a widget or its code. In one reply, give your recommendation and its reason for each item and ask them to keep or change each, then ask for their full name and their role, listing the roles the step printed as `roles`. For the release, give your recommendation and its reason, ask the approver to keep or change it, and ask them to confirm: "I have reviewed the findings, the decisions and the recommendations."
- Never choose or fill in a name or a role. Record exactly what the person sends: for each item the option and the reason, whether they kept the recommended reason or wrote their own. Where they keep a recommendation in the chat, its reason is your assessment, word for word. Ask for anything missing.

## Step 0 · Ready (only when the person asks to prepare a review)

Run this step only when the person's message asks to prepare a review without starting it, for example *"Prepare a new review."* Make the working folder, run `ready`, then create the dashboard. Say: *"Your dashboard is ready. The supplier list and the spend history are in the project folder: say when you'd like to begin."* Their next message starts Step 1.

Any other opening, such as asking to run, start or begin a review, or simply *"Go"*, skips this step: start at Step 1 and carry straight on to the decisions.

## Step 1 · Start from the folder

Run `start --folder "<the project folder>"`, making the working folder first if Step 0 didn't run. Update the dashboard, or create it if Step 0 didn't run. Say, with the printed counts: *"Thank you. I have {suppliers} supplier records and {orders} purchase orders from the project folder to review. I'll compare every plausible pair of suppliers, then show you which ones need a person. Your dashboard is open on the right."*

If `start` can't find or open the files in the folder, don't relay it: work from a copy as `references/project-folder.md` describes, and carry on. Relay any other refusal.

## Step 2 · Match

Run `match`. Say: *"I've compared {pairs_compared} plausible pairs. {review_queue} reach the policy line and need a person; {look_alikes_below_policy} look-alike names stay below it."*

## Step 3 · Assess the evidence

Run `evidence`. It prints each queued pair, field by field, including `Same-amount orders`: any order on each record for the same amount within 30 days. For each pair, write a short assessment **citing only those fields**: a recommendation (`same`, `different` or `refer`) and a confidence (`high`, `medium` or `low`), exactly as `references/assessment-guide.md` describes, in `assessment.json` in the working folder. Where the evidence can't settle it (a shared bank account and nothing else), recommend `refer`. The card starts on each recommendation, with its assessment in the reason box, so write each as a reason a person could sign.

## Step 4 · The decisions (stop)

Run `gate --assessment assessment.json`. Update the dashboard. Say, from the printed `pairs`: *"Before I count anything, {n} pairs need your decision. {How many share a tax number, and how many share a bank account under different tax numbers.} {Name the pairs whose `evidence` shows orders for the same amount on both records.} I've set each one on the card below to what I'd recommend, with my reason: keep it or change it, then add your name and role. On your dashboard, Candidates lets you move the review line and see what a different policy would miss."* Then show the decision card, as *The cards* describes.

**Wait.** Calculate nothing until every pair is decided. The card sends one message: *"Decisions on the supplier pairs. {pair}: the same supplier. Reason: … {pair}: refer it on. Reason: … Decided by {full name}, {role}."* Write it as `decisions.json` in the working folder, one entry per pair, taking each pair's `pair` from the gate result by its supplier names, the option as `same`, `different` or `refer` ("different suppliers, bank details verified" is `different`), and the reason word for word:

```json
{"decisions": [{"item": "<the pair, as the gate printed it>", "option": "same", "reason": "<the reason, word for word>"}]}
```

Then run `decide --name "{their full name}" --role "{their role}" --file decisions.json`. The card is recorded whole or not at all. If it refuses a name, a role or a reason, relay the message and ask for exactly what's missing; if it refuses a reason because it's the one recommended for a different option, ask for their reason for the option they chose. Confirm in one sentence: *"Thank you. All {n} decisions are recorded, with your reasons, by {name}, {role}, at {at}."*

## Step 5 · What the decisions show, and your analysis

Run `findings`. It counts the payments made twice and prints `analysis`: the brief for your analysis of each pair. Say one short line while you work: *"The figures are in. I'm looking at each pair now."*

Write the analysis exactly as `references/analysis-guide.md` describes, as `claude-analysis.json` in the working folder, and run `analysis --file claude-analysis.json`. Where a decision differs from the assessment, the brief says so: name it in that pair's insight. Update the dashboard. Then say, from the printed figures:
- If `paid_twice` has entries, lead with it: *"Here's what your decisions show: **{total_paid_twice, rounded}** was paid twice, on {n} pairs you confirmed as one supplier: {each amount, rounded, and the supplier}. Each only counts because you confirmed the pair."*
- If `possible_duplicates` has entries, add each: *"{amount} on {pair} is a possible duplicate, {status}: it isn't counted as paid twice."* While there's one, never say "R0" or that nothing was paid twice.
- If neither has entries, say plainly that nothing was paid twice on the pairs confirmed as one supplier, and give each confirmed pair's combined spend, one by one. Never add them up.
- If a pair was referred: *"{pairs} go for review, not a verdict."*
- Then: *"I've also looked at each pair. {headline} On the review's own figures, my {recommendations} recommendations are worth about {projected_gain_12_months} over the next 12 months, starting with {first_priority.pair}: {first_priority.does, in lower case}. The detail is on your dashboard."* If `projected_gain_12_months` is R0: *"I've also looked at each pair. {headline} No gain is projected: my {recommendations} recommendations protect {at_stake} at stake, starting with {first_priority.pair}: {first_priority.does, in lower case}. The detail is on your dashboard."*

## Step 6 · Approval to release (stop)

Say: *"These findings and the recommendations are ready to release. A second person, in one of the roles allowed to approve them, needs to review and approve them before they go anywhere. I've set the card below to what I'd recommend, with my reason: the approver keeps it or changes it, then adds their name and role and confirms the review."* Then show the release card, as *The cards* describes, with the `roles` the analysis step printed.

**Wait** for the answer. It must come from a different person from anyone who decided in Step 4, in one of those roles, and they must confirm they reviewed the findings, the decisions and the recommendations. Then run `release --approve --reason "{reason}" --name "{full name}" --role "{role}" --reviewed`, or `release --return` with the same details. Pass `--reviewed` only when they confirmed it.
- If it refuses, relay the message and ask for what it needs: a different approver, an allowed role, or the confirmation.
- If it refuses the reason because it's the one recommended for the other choice, ask the approver for their reason for the choice they made.
- If returned: *"Understood. The findings stay unreleased. A fresh review can start in a new chat in this project whenever you're ready."* Stop here.

## Step 7 · Publish to the folder

Run `publish`. Update the dashboard.
- When `filed.saved_in_folder` is false, first save each file in `filed.save_to` to its place in the project folder, as `references/project-folder.md` describes.
- Say: *"Released, approved by {name}, {role}. The report, a management briefing and a presentation for the next meeting, the evidence pack, the audit trail, the data, the change request and the draft recovery letters are in the project folder under 03 Outputs › {the review number in filed.outputs}, and the full record of this review is in 04 Records. Nothing has been merged, blocked or recovered: these are drafts for the owners of those processes."* Leave out the recovery letters if nothing was paid twice.
- The management briefing and the presentation are filed with the release. If asked about them, say where they are and what's in them; don't make another. Share the files in the chat too if the person asks.

If `publish` refuses, relay its message. It never releases without an approver, and never twice.

## Questions and checks, at any point

- Answer in three sentences or fewer, say where the dashboard shows it, then return to the current step. For *"How does this work?"*: *"Fixed rules compare every plausible pair on tax number, bank account, name and city, and show any orders for the same amount on both records. I assess the evidence and say what I think, but a person decides each pair, and a payment only counts as made twice once someone confirms the two records are one supplier. My recommendations come after that, and the review checks every figure in them against its own."*
- For *"Why not just use a higher threshold?"*: *"Fewer reviews, but a shared bank account would slip through unseen. Where the line sits is a policy choice, not an IT setting."* Point to Candidates on the dashboard.
- For *"Is this fraud?"*, or any question about wrongdoing: *"That isn't something the review decides. Shared bank details go to forensic review, and people with the authority decide."*
- For how a figure was calculated, explain the rule in one or two plain sentences from `references/business-rules.md`, and point to the evidence pack or the audit trail. For how a recommendation was valued, give its basis from the brief in one or two sentences, and point to the Recommendations sheet in the evidence pack.
- For *"Can we check the record hasn't been changed?"*, run `verify` and say the `tamper_check` sentence. For a record in the folder, run `verify --file "<the project folder>/04 Records/<record>"`, or check a copy as `references/project-folder.md` describes.
- For questions about an earlier review, read its one-page summary in `03 Outputs` › its review number › `Report`, and answer from it, naming the review. The evidence is always its record in `04 Records`.
- A fresh review starts in a new chat in this project. If the person asks to start again here, say: *"Let's open a new chat in this project, and I'll start the fresh review there."* Never run `ready` or `start` a second time in one chat.
- If anything fails unexpectedly: *"That step didn't complete. To keep the figures reliable, let's start a fresh review."* Never show an error.

## Additional resources

These are for Claude's use; never quote them to the person as documents.
- **`references/project-folder.md`:** the folder's rules, and the fallbacks for reading and filing.
- **`references/management-pack.md`:** what the management briefing and the presentation filed at release contain.
- **`references/business-rules.md`:** how pairs are scored, the policy line, what "paid twice" and a possible duplicate mean, what each decision does to the figures, how each recommendation is valued, and what the review never does.
- **`references/assessment-guide.md`:** exactly how to write each pair's assessment.
- **`references/analysis-guide.md`:** how to write the analysis of each pair, and the rule for its figures.
- **`references/data-dictionary.md`:** what the files contain.
